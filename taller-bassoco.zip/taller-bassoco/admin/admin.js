/* ==========================================================
   Panel de administración
   Usa la API REST de GitHub (Contents API) para leer y escribir
   data/vehicles.json directamente como commits en el repositorio.
   El token vive guardado en este dispositivo (localStorage) hasta que cierres sesión.

   Modelo de datos por vehículo:
     - servicio_actual: el servicio que se está realizando ahora mismo
       (o null si no hay ninguno). Tiene su propia etapa (recibido /
       en_proceso / listo) y fotos/documentos separados por etapa.
       Es editable hasta que se marca como finalizado.
     - servicios: historial de servicios ya finalizados (solo lectura,
       con fotos/documentos ya fusionados).
   ========================================================== */

(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);

  /* ---------------- Lightbox (ver foto ampliada) ---------------- */

  let lightboxEl, lightboxImg, lightboxCounter, lightboxPhotos = [], lightboxIndex = 0, lightboxJustOpened = false;

  function initLightbox() {
    lightboxEl = $("lightbox");
    if (!lightboxEl) return;
    lightboxImg = $("lightbox-img");
    lightboxCounter = $("lightbox-counter");

    let lightboxRetryTimer = null;
    function updateLightbox() {
      if (lightboxRetryTimer) { clearTimeout(lightboxRetryTimer); lightboxRetryTimer = null; }
      delete lightboxImg.dataset.retryN;
      delete lightboxImg.dataset.baseSrc;
      lightboxEl.classList.remove("img-retrying", "img-fallback-shown");
      lightboxImg.src = lightboxPhotos[lightboxIndex];
      const multi = lightboxPhotos.length > 1;
      $("lightbox-prev").style.display = multi ? "flex" : "none";
      $("lightbox-next").style.display = multi ? "flex" : "none";
      lightboxCounter.style.display = multi ? "block" : "none";
      lightboxCounter.textContent = `${lightboxIndex + 1} / ${lightboxPhotos.length}`;
    }
    function openLightbox(photos, index) {
      lightboxPhotos = photos;
      lightboxIndex = index;
      updateLightbox();
      lightboxEl.classList.remove("hidden");
      // En móviles, el mismo toque que abre la foto a veces genera un "clic
      // fantasma" o un touchend rezagado que aterriza sobre el fondo recién
      // revelado. Este candado ignora cualquier clic en el fondo durante los
      // primeros instantes tras abrir, sin importar de dónde venga.
      lightboxJustOpened = true;
      setTimeout(() => { lightboxJustOpened = false; }, 600);
    }
    function closeLightbox() {
      if (lightboxRetryTimer) { clearTimeout(lightboxRetryTimer); lightboxRetryTimer = null; }
      lightboxEl.classList.add("hidden");
      lightboxImg.src = "";
    }
    lightboxImg.addEventListener("error", () => {
      const n = Number(lightboxImg.dataset.retryN) || 0;
      if (n >= IMG_RETRY_DELAYS.length) {
        lightboxEl.classList.add("img-fallback-shown");
        return;
      }
      lightboxImg.dataset.retryN = String(n + 1);
      lightboxEl.classList.add("img-retrying");
      const base = lightboxImg.dataset.baseSrc || lightboxImg.src.split("?")[0];
      lightboxImg.dataset.baseSrc = base;
      lightboxRetryTimer = setTimeout(() => { lightboxRetryTimer = null; lightboxImg.src = base + "?r=" + n + "-" + Date.now(); }, IMG_RETRY_DELAYS[n]);
    });
    lightboxImg.addEventListener("load", () => {
      if (lightboxRetryTimer) { clearTimeout(lightboxRetryTimer); lightboxRetryTimer = null; }
      lightboxEl.classList.remove("img-retrying", "img-fallback-shown");
    });
    $("lightbox-close").addEventListener("click", closeLightbox);
    $("lightbox-prev").addEventListener("click", () => {
      lightboxIndex = (lightboxIndex - 1 + lightboxPhotos.length) % lightboxPhotos.length;
      updateLightbox();
    });
    $("lightbox-next").addEventListener("click", () => {
      lightboxIndex = (lightboxIndex + 1) % lightboxPhotos.length;
      updateLightbox();
    });
    lightboxEl.addEventListener("click", (e) => {
      if (e.target === lightboxEl && !lightboxJustOpened) closeLightbox();
    });
    document.addEventListener("keydown", (e) => {
      if (lightboxEl.classList.contains("hidden")) return;
      if (e.key === "Escape") closeLightbox();
      if (e.key === "ArrowLeft") $("lightbox-prev").click();
      if (e.key === "ArrowRight") $("lightbox-next").click();
    });
    document.addEventListener("click", (e) => {
      if (e.target.closest("button")) return; // no abrir si el clic fue en el botón de quitar (×)
      const thumb = e.target.closest("[data-lightbox-group]");
      if (!thumb) return;
      e.stopPropagation();
      const photos = JSON.parse(thumb.dataset.lightboxGroup.replace(/&quot;/g, '"'));
      openLightbox(photos, Number(thumb.dataset.lightboxIndex));
    });
  }

  const DATA_PATH = "data/vehicles.json";
  const SESSION_KEY = "taller_nfc_admin_session";
  const DEFAULT_OWNER = "Blaze151";
  const DEFAULT_REPO = "taller-bassoco";
  const DEFAULT_BRANCH = "main";
  const MAX_PDF_MB = 8;

  const ESTADOS_SERVICIO = () => ({
    recibido: { label: t("estado_recibido"), icon: "📥" },
    diagnostico: { label: t("estado_diagnostico"), icon: "🔍" },
    en_proceso: { label: t("estado_en_proceso"), icon: "🔧" },
    listo: { label: t("estado_listo"), icon: "✅" },
    recogido: { label: t("estado_entregado"), icon: "🚗" },
  });
  const ORDEN_ESTADOS_SERVICIO = ["recibido", "diagnostico", "en_proceso", "listo", "recogido"];

  const PAGO_INFO = () => ({ icon: "💳", label: t("pago_comprobante") });
  const PAGO_ESTADOS = () => ({
    no_pagado: { label: t("pago_no_pagado"), icon: "🕓" },
    pagado: { label: t("pago_pagado"), icon: "✅" },
    a_deber: { label: t("pago_a_deber"), icon: "⚠️" },
  });
  const ATTACH_STAGES = [...ORDEN_ESTADOS_SERVICIO, "pago"];

  // Hoja de recepción: inventario del vehículo que el cliente debe revisar y aceptar.
  const INVENTARIO_EXTERIORES = [
    ["antena", "antena_item"], ["espejo_lateral", "espejo_lateral_item"], ["cristales", "cristales_item"],
    ["emblema", "emblema_item"], ["tapon_ruedas", "tapon_ruedas_item"], ["molduras_completas", "molduras_completas_item"],
    ["tapon_gasolina", "tapon_gasolina_item"],
  ];
  const INVENTARIO_ACCESORIOS = [
    ["gato", "gato_item"], ["maneral_gato", "maneral_gato_item"], ["llave_ruedas", "llave_ruedas_item"],
    ["estuche_herramientas", "estuche_herramientas_item"], ["triangulo_seguridad", "triangulo_seguridad_item"],
    ["llanta_refaccion", "llanta_refaccion_item"], ["extinguidor", "extinguidor_item"],
  ];
  // Folio consecutivo por servicio: A001, A002, ... A999, B001, B002, ...
  // 8 caracteres al azar (sin 0/O/1/I para no confundirlos al leer) — mucho
  // más difícil de adivinar que un ID consecutivo como X1, X2, X3...
  function generarIdSugerido() {
    const alfabeto = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    let out = "";
    for (let i = 0; i < 8; i++) out += alfabeto[Math.floor(Math.random() * alfabeto.length)];
    return out;
  }

  // Marca la fecha y hora exacta en que el servicio activo entró a una
  // etapa — permite saber cuánto duró cada una, en vez de depender de un
  // solo campo "actualizado" que se pisa con cada cambio.
  function marcarFechaEtapa(estado) {
    if (!svcActual) return;
    if (!svcActual.fechas_etapa) svcActual.fechas_etapa = {};
    svcActual.fechas_etapa[estado] = new Date().toISOString();
  }

  // Mientras se está guardando, bloquea los controles que podrían generar
  // una segunda acción encimada (cambiar de etapa, finalizar o cancelar el
  // servicio, o presionar Guardar otra vez) — evita commits duplicados o
  // confusos si el admin toca algo mientras la subida sigue en curso.
  // Progreso real de subida: en vez de varios avisos sueltos ("Subiendo 3
  // fotos...", "Subiendo 2 documentos..." sin relación entre sí), se cuenta
  // el total de archivos pendientes ANTES de empezar y se va actualizando
  // un solo contador visible en el botón de guardar mientras se sube cada
  // uno, sin importar de cuál de las 3 fases venga.
  let uploadProgress = { done: 0, total: 0 };

  function countPendingUploads(vehicle) {
    let n = 0;
    if (vehicle._pendingFotoPerfil) n += 1;
    const vp = vehicle._pendingDocumentosVehiculo;
    if (vp) n += vp.fotos.length + vp.documentos.length;
    const activeP = vehicle.servicio_actual && vehicle.servicio_actual._pendingAdjuntos;
    if (activeP) {
      Object.values(activeP).forEach((g) => { n += (g.fotos || []).length + (g.documentos || []).length; });
    }
    (vehicle.servicios || []).forEach((s) => {
      if (s._pendingAdjuntos) {
        Object.values(s._pendingAdjuntos).forEach((g) => { n += (g.fotos || []).length + (g.documentos || []).length; });
      }
    });
    return n;
  }

  function bumpUploadProgress() {
    if (uploadProgress.total <= 0) return;
    uploadProgress.done++;
    const btn = $("btn-save");
    if (btn) btn.textContent = t("subiendo_progreso_btn").replace("{actual}", uploadProgress.done).replace("{total}", uploadProgress.total);
  }

  // Plantillas de servicios comunes — llenan tipo, descripción y conceptos
  // de cotización de un jalón, para no escribir lo mismo cada vez.
  const SERVICE_TEMPLATES = {
    "Cambio de aceite": {
      descripcion: "Cambio de aceite y filtro de aceite. Revisión de niveles.",
      conceptos: [{ concepto: "Aceite de motor", costo_unitario: null }, { concepto: "Filtro de aceite", costo_unitario: null }, { concepto: "Mano de obra", costo_unitario: null }],
    },
    "Afinación": {
      descripcion: "Afinación mayor: bujías, filtros (aire, aceite, gasolina), revisión de niveles y puntos de seguridad.",
      conceptos: [{ concepto: "Bujías", costo_unitario: null }, { concepto: "Filtro de aire", costo_unitario: null }, { concepto: "Filtro de aceite", costo_unitario: null }, { concepto: "Filtro de gasolina", costo_unitario: null }, { concepto: "Mano de obra", costo_unitario: null }],
    },
    "Frenos": {
      descripcion: "Revisión y servicio de frenos.",
      conceptos: [{ concepto: "Balatas", costo_unitario: null }, { concepto: "Rectificado de discos/tambores", costo_unitario: null }, { concepto: "Mano de obra", costo_unitario: null }],
    },
    "Diagnóstico": {
      descripcion: "Diagnóstico general del vehículo.",
      conceptos: [{ concepto: "Diagnóstico", costo_unitario: null }],
    },
    "Suspensión": {
      descripcion: "Revisión y servicio de suspensión.",
      conceptos: [{ concepto: "Amortiguadores", costo_unitario: null }, { concepto: "Terminales/rótulas", costo_unitario: null }, { concepto: "Mano de obra", costo_unitario: null }],
    },
  };

  function aplicarPlantillaServicio(nombre) {
    const plantilla = SERVICE_TEMPLATES[nombre];
    if (!plantilla || !svcActual) return;
    svcActual.tipo = nombre;
    if (!svcActual.descripcion) svcActual.descripcion = plantilla.descripcion;
    // Solo llena la cotización si está vacía — para no borrar conceptos que
    // el admin ya haya capturado a mano.
    const cotVacia = !svcActual.cotizacion || !(svcActual.cotizacion.items || []).some((it) => (it.concepto || "").trim());
    if (cotVacia) {
      if (!svcActual.cotizacion) svcActual.cotizacion = emptyCotizacion();
      svcActual.cotizacion.items = plantilla.conceptos.map((c) => ({ concepto: c.concepto, cantidad: 1, costo_unitario: c.costo_unitario }));
    }
    hasUnsavedChanges = true;
    updateUnsavedIndicator();
    renderActiveServiceCard();
  }

  // Borrador automático local: cada 12s, si hay cambios sin guardar, se
  // guarda una copia en el navegador (localStorage) — así, si se cierra la
  // pestaña por accidente o se pierde la conexión, no se pierde el trabajo.
  // Los archivos (fotos/documentos) NO se pueden guardar así, solo el texto.
  let draftIntervalId = null;

  // Los archivos pendientes de subir (foto de perfil, documentos, fotos por
  // etapa) nunca se pueden guardar como borrador — al convertir a JSON, cada
  // File dentro de un arreglo queda como "null" (no se puede simplemente
  // "quitar" un elemento de un arreglo JSON), lo que dejaría arreglos
  // corruptos tipo [null, null] en el borrador. Se eliminan por completo en
  // vez de intentar conservarlos.
  function limpiarPendientesParaBorrador(vehicle) {
    delete vehicle._pendingFotoPerfil;
    delete vehicle._pendingDocumentosVehiculo;
    if (vehicle.servicio_actual) delete vehicle.servicio_actual._pendingAdjuntos;
    (vehicle.servicios || []).forEach((s) => { delete s._pendingAdjuntos; });
    return vehicle;
  }

  function draftKeyFor(id) {
    return "draft_" + (id || "new");
  }

  function guardarBorradorLocal() {
    if (!hasUnsavedChanges) return;
    if (!currentVehicleId && !isNewVehicle) return;
    let vehicle;
    try {
      vehicle = buildVehicleFromForm();
    } catch (err) {
      return; // sin ID todavía no hay nada válido que guardar como borrador
    }
    try {
      const json = JSON.stringify(vehicle, (k, v) => (v instanceof File ? undefined : v));
      const limpio = limpiarPendientesParaBorrador(JSON.parse(json));
      localStorage.setItem(draftKeyFor(isNewVehicle ? null : currentVehicleId), JSON.stringify({ vehicle: limpio, savedAt: new Date().toISOString(), esNuevo: isNewVehicle }));
    } catch (err) { /* localStorage puede fallar (espacio lleno, modo privado) — no es crítico */ }
  }
  function leerBorradorLocal(id) {
    try {
      const raw = localStorage.getItem(draftKeyFor(id));
      return raw ? JSON.parse(raw) : null;
    } catch (err) { return null; }
  }
  function borrarBorradorLocal(id) {
    try { localStorage.removeItem(draftKeyFor(id)); } catch (err) {}
  }

  // Pregunta qué hacer con un borrador encontrado: recuperarlo, descartarlo
  // de una vez, o dejarlo intacto para decidir después (sin obligar a elegir
  // entre solo 2 opciones, ya que "no" en un confirm() normal se sentía como
  // "descartar" aunque el admin solo quisiera pensarlo).
  function preguntarQueHacerConBorrador(fechaTexto) {
    return new Promise((resolve) => {
      const overlay = document.createElement("div");
      overlay.className = "wa-prompt-overlay";
      overlay.innerHTML = `
        <div class="card wa-prompt-card" style="max-width:420px;">
          <div class="card-title">${esc(t("borrador_encontrado_titulo"))}</div>
          <p style="font-size:12.5px;color:var(--text-dim);">${esc(t("borrador_encontrado_desc").replace("{fecha}", fechaTexto))}</p>
          <div class="actions-row" style="flex-direction:column;gap:8px;">
            <button class="btn btn-sm btn-block" id="borrador-btn-recuperar">${esc(t("borrador_btn_recuperar"))}</button>
            <button class="btn btn-outline btn-sm btn-block" id="borrador-btn-mantener">${esc(t("borrador_btn_mantener"))}</button>
            <button class="btn btn-outline btn-danger btn-sm btn-block" id="borrador-btn-descartar">${esc(t("borrador_btn_descartar"))}</button>
          </div>
        </div>`;
      document.body.appendChild(overlay);
      const cerrar = (resultado) => { overlay.remove(); resolve(resultado); };
      overlay.querySelector("#borrador-btn-recuperar").addEventListener("click", () => cerrar("recuperar"));
      overlay.querySelector("#borrador-btn-mantener").addEventListener("click", () => cerrar("mantener"));
      overlay.querySelector("#borrador-btn-descartar").addEventListener("click", () => cerrar("descartar"));
    });
  }

  // Línea de tiempo con la fecha y hora exacta en que el servicio entró a
  // cada etapa — ya se guardaba en fechas_etapa pero no se mostraba en
  // ningún lado.
  function renderCronologiaEtapas() {
    if (!svcActual || !svcActual.fechas_etapa) return "";
    const items = ORDEN_ESTADOS_SERVICIO
      .filter((stage) => svcActual.fechas_etapa[stage])
      .map((stage) => {
        const info = ESTADOS_SERVICIO()[stage];
        const fecha = new Date(svcActual.fechas_etapa[stage]).toLocaleString("es-MX", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
        return `<div style="display:flex;justify-content:space-between;padding:3px 0;"><span>${info.icon} ${esc(info.label)}</span><span style="color:var(--text-faint);">${esc(fecha)}</span></div>`;
      });
    if (!items.length) return "";
    return `<div style="background:rgba(255,255,255,0.03);border-radius:10px;padding:8px 12px;margin-bottom:10px;font-size:11.5px;">
      <div style="font-weight:700;color:var(--text-dim);margin-bottom:2px;">${esc(t("cronologia_titulo"))}</div>
      ${items.join("")}
    </div>`;
  }

  let lastSavedAt = null;
  function textoGuardadoHaceRato() {
    if (!lastSavedAt) return "";
    const minutos = Math.round((Date.now() - lastSavedAt) / 60000);
    if (minutos < 1) return t("guardado_justo_ahora_txt");
    if (minutos === 1) return t("guardado_hace_1min_txt");
    if (minutos < 60) return t("guardado_hace_min_txt").replace("{n}", minutos);
    const horas = Math.round(minutos / 60);
    return horas === 1 ? t("guardado_hace_1h_txt") : t("guardado_hace_horas_txt").replace("{n}", horas);
  }
  function updateUnsavedIndicator() {
    const el = $("unsaved-indicator");
    if (!el) return;
    if (hasUnsavedChanges) {
      el.style.display = "block";
      el.style.color = "var(--yellow)";
      el.innerHTML = `<span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:var(--yellow);margin-right:6px;vertical-align:middle;"></span>${esc(t("cambios_sin_guardar_txt"))}`;
    } else if (lastSavedAt) {
      el.style.display = "block";
      el.style.color = "var(--text-faint)";
      el.innerHTML = `✓ ${esc(textoGuardadoHaceRato())}`;
    } else {
      el.style.display = "none";
    }
  }

  function setEditorControlsBusy(busy) {
    [
      "as-estado", "btn-finalize-service", "btn-cancel-service", "btn-back",
      "btn-save-visible", "btn-save-and-back", "btn-enviar-orden", "btn-enviar-cotizacion", "btn-enviar-informe-trabajo",
    ].forEach((id) => {
      const el = $(id);
      if (el) el.disabled = busy;
    });
  }

  function siguienteFolio() {
    if (!db.folio_counter) db.folio_counter = 0;
    db.folio_counter += 1;
    const n = db.folio_counter;
    const letra = String.fromCharCode(65 + Math.floor((n - 1) / 999));
    const numero = String(((n - 1) % 999) + 1).padStart(3, "0");
    return `${letra}${numero}`;
  }

  function emptyOrdenRecepcion() {
    const blank = (list) => Object.fromEntries(list.map(([k]) => [k, "no"]));
    return {
      enviado: false, aceptado: false, fecha_envio: null, fecha_aceptado: null,
      inventario: { exteriores: blank(INVENTARIO_EXTERIORES), accesorios: blank(INVENTARIO_ACCESORIOS), gasolina: 0, danos_notas: "" },
    };
  }

  function emptyCotizacion() {
    return {
      enviado: false, fecha_envio: null, pdf_path: null,
      items: [{ concepto: "", cantidad: 1, costo_unitario: null }],
      incluir_iva: true,
      observaciones: "",
      aceptado: false, fecha_aceptado: null,
    };
  }

  function emptyInformeTrabajo() {
    return { enviado: false, fecha_envio: null, pdf_path: null };
  }

  /* ---------------- Idioma (ES/EN) ---------------- */

  const LANG_KEY = "taller_nfc_lang";
  const STR = {
    es: {
      admin_titulo: "Team Bassoco — Administración",
      cerrar_sesion: "Cerrar sesión",
      login_titulo: "Conectar con el repositorio",
      login_desc_html: 'Se conecta directo a tu repositorio de GitHub usando un token personal. Los cambios que hagas aquí se guardan como commits en <code class="mono">data/vehicles.json</code>.',
      github_user_label: "Usuario u organización de GitHub",
      github_user_placeholder: "ej. hmoralesc",
      repo_label: "Repositorio",
      repo_placeholder: "ej. taller-bassoco",
      branch_label: "Rama",
      token_label: "Token de acceso personal (fine-grained, permiso Contents: Read and write)",
      btn_conectar: "Conectar",
      login_note: 'El token queda guardado en este dispositivo (no se comparte ni se sube a ningún lado) hasta que presiones "Cerrar sesión". Úsalo solo en tu celular o computadora del taller, no en equipos compartidos. Crea el token en GitHub → Settings → Developer settings → Fine-grained tokens, limitado únicamente a este repositorio.',
      ver_tablero: "📋 Ver tablero por estado",
      buscar_vehiculo_titulo: "Buscar vehículo",
      buscar_vehiculo_placeholder: "Buscar por placa, marca, modelo o cliente...",
      vehiculos_registrados: "Vehículos registrados",
      btn_agregar_vehiculo: "+ Agregar vehículo nuevo",
      volver_lista: "← Volver a la lista",
      llamar_btn: "📞 Llamar",
      whatsapp_btn: "💬 WhatsApp",
      datos_vehiculo: "Datos del vehículo",
      foto_vehiculo_label: "Foto del vehículo",
      tomar_foto: "📷 Tomar foto",
      subir_fototeca: "🖼️ Subir de la fototeca",
      id_nfc_label: "ID de la etiqueta NFC",
      id_nfc_placeholder: "ej. ABC123",
      regenerar_id_title: "Generar otro ID seguro",
      id_nfc_warning_corto: "⚠️ Este ID es corto o fácil de adivinar — cualquiera que lo intuya podría ver los datos de este cliente. Te recomendamos usar uno de los generados automáticamente.",
      placas_label: "Placas",
      numero_unidad_label: "Número de unidad",
      unidad_prefix: "Unidad",
      marca_label: "Marca",
      modelo_label: "Modelo",
      anio_label: "Año",
      version_label: "Versión / motor",
      color_label: "Color",
      combustible_label: "Combustible",
      combustible_sin_especificar: "Sin especificar",
      combustible_gasolina: "Gasolina",
      combustible_diesel: "Diesel",
      combustible_electrico: "Eléctrico",
      combustible_gas: "Gas",
      vin_label: "VIN",
      km_actual_label: "Kilometraje actual",
      cliente_label: "Cliente",
      telefono_cliente_label: "Teléfono del cliente",
      telefono_cliente_2_label: "Teléfono adicional (opcional)",
      correo_cliente_label: "Correo del cliente (opcional)",
      rfc_cliente_label: "RFC del cliente (opcional)",
      direccion_cliente_label: "Dirección del cliente (opcional)",
      documentos_vehiculo_titulo: "Documentos del vehículo",
      documentos_vehiculo_desc: "Fotos o PDF generales del vehículo (tarjeta de circulación, seguro, etc.), no ligados a un servicio en particular. Aparecen en la ficha del cliente como un desplegable.",
      fototeca_btn: "🖼️ Fototeca",
      pdf_btn: "📄 PDF",
      ficha_tecnica_titulo: "Ficha técnica",
      aceite_tipo_label: "Aceite (tipo)",
      aceite_cap_label: "Capacidad de aceite",
      presion_llantas_label: "Presión de llantas",
      bateria_label: "Batería",
      filtro_aire_label: "Filtro de aire",
      filtro_aceite_label: "Filtro de aceite",
      servicio_en_proceso_titulo: "🔧 Servicio en proceso",
      historial_titulo: "Historial de servicios (finalizados)",
      historial_desc: "Solo se puede editar mientras un servicio está en proceso. Una vez finalizado, queda como registro permanente.",
      guardar_btn: "Guardar cambios en GitHub",
      guardar_todos_btn: "💾 Guardar todos los cambios",
      guardar_y_volver_btn: "💾 Guardar y volver",
      guardado_justo_ahora_txt: "Guardado justo ahora",
      guardado_hace_1min_txt: "Guardado hace 1 minuto",
      guardado_hace_min_txt: "Guardado hace {n} minutos",
      guardado_hace_1h_txt: "Guardado hace 1 hora",
      guardado_hace_horas_txt: "Guardado hace {n} horas",
      resumen_recibidos: "Recibidos",
      resumen_diagnostico: "Diagnóstico",
      resumen_en_proceso: "En proceso",
      resumen_listos: "Listos",
      resumen_pendiente_cobro: "Pendiente de cobro",
      cambios_sin_guardar_txt: "Cambios sin guardar",
      copiar_enlace_btn: "🔗 Copiar enlace",
      msg_enlace_copiado: "✓ Enlace copiado",
      filtro_label: "Filtrar",
      filtro_todos: "Todos",
      filtro_requiere_atencion: "⚠ Requiere atención",
      filtro_recibido: "Recibidos",
      filtro_diagnostico: "Diagnóstico",
      filtro_en_proceso: "En proceso",
      filtro_listo: "Listos",
      filtro_entregados: "Entregados",
      filtro_pagados: "Pagados",
      filtro_a_deber: "A deber",
      filtro_sin_servicio: "Sin servicio activo",
      orden_label: "Ordenar",
      orden_reciente: "Más recientes",
      orden_antiguo: "Más antiguos",
      orden_etapa: "Etapa",
      orden_cliente: "Cliente",
      orden_unidad: "Número de unidad",
      orden_deuda: "Con deuda primero",
      pend_cliente_no_acepto: "Cliente no ha aceptado",
      pend_cotizacion_pendiente: "Cotización pendiente",
      pend_pago_pendiente: "Pago pendiente",
      pend_listo_para_recoger: "Listo para recoger",
      plantilla_elegir: "📋 Usar plantilla…",
      confirm_recuperar_borrador: "Encontramos un borrador sin guardar de este vehículo (guardado el {fecha}). ¿Recuperarlo? (Las fotos pendientes de subir no se pueden recuperar así, solo el texto)",
      borrador_encontrado_titulo: "📝 Encontramos un borrador",
      borrador_encontrado_desc: "Hay cambios sin guardar de este vehículo, guardados automáticamente el {fecha}. Las fotos pendientes de subir no se pueden recuperar así, solo el texto. ¿Qué quieres hacer?",
      borrador_btn_recuperar: "✅ Recuperar",
      borrador_btn_mantener: "🕓 Decidir después (no tocar nada)",
      borrador_btn_descartar: "🗑️ Descartar borrador",
      msg_edito_durante_guardado: "Guardado, pero editaste algo más mientras subía — presiona Guardar otra vez para incluir eso también.",
      confirm_retroceder_etapa: "Estás regresando el servicio a una etapa anterior — se registrará este retroceso. ¿Continuar?",
      cronologia_titulo: "🕓 Cronología del servicio",
      descripcion_visible_hint: "El cliente ve esto en su ficha.",
      nota_interna_label: "Nota interna (solo para el taller)",
      nota_interna_hint: "Esto NO lo ve el cliente — úsalo para recordatorios, detalles delicados, etc.",
      subiendo_progreso_btn: "⬆️ Subiendo… {actual} de {total}",
      guardando_btn: "Guardando…",
      guardado_btn: "Guardado",
      eliminar_btn: "Eliminar vehículo",
      panel_admin_footer: "Panel de administración",
      reportar_problema: "🛠️ Reportar un problema del sistema",
      estado_recibido: "Recibido",
      estado_diagnostico: "Diagnóstico",
      estado_en_proceso: "En proceso",
      estado_listo: "Listo para recoger",
      estado_entregado: "Entregado",
      pago_comprobante: "Comprobante de pago",
      pago_no_pagado: "No pagado",
      pago_pagado: "Pagado",
      pago_a_deber: "A deber",
      sin_servicio_activo: "Sin servicio activo",
      cambiar_tema: "Cambiar tema",
      msg_completa_campos: "Completa usuario, repositorio y token.",
      msg_conectando: "Conectando…",
      msg_no_conectar: "No se pudo conectar: ",
      msg_no_procesar_imagen: "No se pudo procesar la imagen",
      msg_no_leer_imagen: "No se pudo leer la imagen",
      board_en_esta_etapa: "En esta etapa",
      board_otras_etapas_activas: "Otras etapas activas",
      board_ningun_recibido: "Ningún vehículo recién recibido.",
      board_ningun_diagnostico: "Ningún vehículo en diagnóstico.",
      board_ningun_en_proceso: "Ningún vehículo en proceso.",
      board_ya_entregado: "Ya entregado",
      board_aun_no_entrega: "Aún no se entrega",
      board_otras_etapas: "Otras etapas",
      board_ningun_listo: "Ningún vehículo listo para recoger todavía.",
      board_pagos_titulo: "Pagos",
      board_no_hay_activos: "No hay servicios activos.",
      board_con_servicio_activo: "Con servicio activo",
      board_todos_tienen_activo: "Todos los vehículos tienen un servicio activo.",
      board_servicios_mes_titulo: "Servicios del mes",
      board_servicios_mes_sub: "servicios",
      board_sin_servicios_mes: "Todavía no hay servicios este mes.",
      board_ingresos_mes_titulo: "Ingresos cobrados del mes",
      board_ingresos_mes_sub: "cobrado",
      board_sin_ingresos_mes: "Todavía no se ha cobrado nada este mes.",
      msg_sin_vehiculos_aqui: "Sin vehículos aquí.",
      quitar_btn: "Quitar",
      servicio_generico: "Servicio",
      folio_label: "Folio",
      metodo_efectivo: "Efectivo",
      metodo_transferencia: "Transferencia",
      msg_servicio_finalizado: 'Servicio finalizado. No olvides presionar "Guardar cambios en GitHub".',
      msg_id_nfc_obligatorio: "El ID de la etiqueta NFC es obligatorio",
      msg_indica_tipo_servicio: "Indica al menos el tipo de servicio antes de finalizar",
      msg_ya_existe_id: "Ya existe un vehículo con ese ID",
      msg_cambios_guardados: "Cambios guardados en GitHub",
      msg_error_guardar: "Error al guardar: ",
      msg_error_solo_json: "Tus fotos y documentos ya se subieron correctamente — solo faltó guardar el registro. Presiona \"Guardar\" de nuevo, no hace falta volver a elegir nada.",
      msg_finalizar_no_guardado: "No se pudo guardar — el servicio NO quedó finalizado de verdad. Vuelve a intentar \"Marcar como finalizado\".",
      buscar_huerfanos_btn: "🧹 Buscar archivos huérfanos",
      orphan_buscando: "Buscando…",
      orphan_titulo: "🧹 Archivos huérfanos",
      orphan_desc: "Archivos que están subidos en el repositorio pero que ningún vehículo usa ya — se pueden borrar sin afectar nada.",
      orphan_seleccionar_todos: "Seleccionar todos",
      orphan_borrar_seleccionados: "Borrar seleccionados",
      orphan_ninguno: "✅ No se encontró ningún archivo huérfano.",
      orphan_ninguno_seleccionado: "Selecciona al menos un archivo para borrar.",
      orphan_confirmar_borrado: "¿Borrar {n} archivo(s) de forma permanente? No se puede deshacer.",
      orphan_borrados_ok: "{n} archivo(s) borrado(s).",
      msg_arbol_truncado: "El repositorio tiene demasiados archivos para listarlos de una vez — contacta soporte técnico para revisar esto manualmente.",
      msg_conflicto_reintentando: "⏳ Alguien más guardó justo antes que tú — trayendo lo más reciente y reintentando...",
      msg_conflicto_resuelto: "✅ Listo — se resolvió el conflicto y tus cambios ya se guardaron.",
      msg_conflicto_persistente: "No se pudo guardar: parece que tú y alguien más están guardando cambios casi al mismo tiempo. No se perdió nada de lo que escribiste — solo presiona \"Guardar cambios en GitHub\" una vez más.",
      msg_vehiculo_eliminado: "Vehículo eliminado",
      msg_vehiculo_eliminado_completo: "✓ Vehículo eliminado completamente ({n} archivo(s) borrado(s))",
      msg_vehiculo_eliminado_parcial: "El vehículo se eliminó, pero {n} archivo(s) no se pudieron borrar — puedes revisarlos luego con tu cuenta de GitHub.",
      eliminando_registro_btn: "Eliminando registro…",
      eliminando_archivos_btn: "Eliminando archivos… {actual} de {total}",
      msg_error_eliminar: "Error al eliminar: ",
      msg_subiendo_foto_vehiculo: "Subiendo foto del vehículo…",
      msg_foto_puede_tardar: "La foto ya se guardó. GitHub Pages a veces tarda un rato en publicarla (a veces varios minutos, incluso en este mismo celular) — la página lo reintenta sola varias veces. Si después de un rato sigue sin verse, refresca la página.",
      msg_convirtiendo_heic: "Convirtiendo {nombre} de HEIC a JPG…",
      msg_fotos_heic_omitidas: "⚠️ {n} foto(s) no se pudieron procesar y no se subieron: {nombres}. Intenta tomar la foto de nuevo o usa otra imagen.",
      msg_no_coinciden: "No hay vehículos que coincidan.",
      msg_vacio_requiere_atencion: "✅ Ningún vehículo requiere atención ahora mismo.",
      msg_vacio_recibido: "No hay vehículos recién recibidos.",
      msg_vacio_diagnostico: "No hay vehículos en diagnóstico.",
      msg_vacio_en_proceso: "No hay vehículos en proceso.",
      msg_vacio_listo: "No hay vehículos listos para recoger.",
      msg_vacio_entregados: "No hay vehículos entregados.",
      msg_vacio_pagados: "No hay vehículos pagados.",
      msg_vacio_a_deber: "No hay vehículos a deber.",
      msg_vacio_sin_servicio: "Todos los vehículos tienen un servicio activo.",
      en_historial: "en historial",
      sin_placa_texto: "sin placa",
      ver_vehiculos_txt: "Ver vehículos",
      wa_sin_telefono: "Este vehículo no tiene teléfono de cliente registrado.",
      cerrar_btn: "Cerrar",
      wa_prompt_titulo: "📲 Vehículo listo para recoger",
      wa_prompt_titulo_recibido: "📲 Vehículo recibido en el taller",
      wa_prompt_pre: "¿Quieres avisarle a",
      wa_prompt_post: "por WhatsApp?",
      enviar_whatsapp_btn: "📲 Enviar WhatsApp",
      ver_fotos_por_etapa: "Ver fotos y documentos por etapa",
      sin_servicios_finalizados: "Sin servicios finalizados todavía.",
      no_hay_servicio_proceso: "No hay ningún servicio en proceso actualmente.",
      iniciar_servicio_btn: "+ Iniciar nuevo servicio",
      tipo_servicio_label: "Tipo de servicio",
      kilometraje_label: "Kilometraje",
      costo_estimado_label: "Precio",
      tecnico_label: "Técnico",
      tiempo_entrega_label: "Tiempo de entrega aproximado",
      tiempo_entrega_placeholder: "ej. Mañana por la tarde, 2-3 días...",
      descripcion_label: "Descripción",
      etapa_actual_label: "Etapa actual",
      iniciado_txt: "Iniciado",
      actualizado_txt: "Actualizado",
      pago_titulo: "💳 Pago",
      estado_pago_label: "Estado de pago",
      metodo_pago_label: "Método de pago",
      monto_pagado_label: "Monto pagado",
      saldo_pendiente_label: "Saldo pendiente",
      msg_metodo_pago_obligatorio: "Para marcar como \"Pagado\" primero indica el método de pago.",
      confirm_pagar_sin_monto: "No hay ningún monto registrado (ni Precio ni Cotización). ¿Marcar como pagado de todas formas?",
      sin_especificar: "Sin especificar",
      orden_recepcion_titulo: "📋 Hoja de recepción",
      orden_recepcion_desc: "Inventario del vehículo y trabajo solicitado, para que el cliente lo revise y acepte.",
      inventario_exteriores: "Exteriores",
      inventario_accesorios: "Accesorios",
      antena_item: "Antena", espejo_lateral_item: "Espejo lateral", cristales_item: "Cristales",
      emblema_item: "Emblema", tapon_ruedas_item: "Tapón de ruedas (4)", molduras_completas_item: "Molduras completas",
      tapon_gasolina_item: "Tapón de gasolina",
      gato_item: "Gato", maneral_gato_item: "Maneral de gato", llave_ruedas_item: "Llave de ruedas",
      estuche_herramientas_item: "Estuche de herramientas", triangulo_seguridad_item: "Triángulo de seguridad",
      llanta_refaccion_item: "Llanta de refacción", extinguidor_item: "Extinguidor",
      inv_si: "Sí", inv_no: "No", inv_sin_marcar: "Sin marcar",
      nivel_gasolina_label: "Nivel de gasolina",
      gasolina_vacio: "Vacío", gasolina_1_4: "1/4", gasolina_1_2: "1/2", gasolina_3_4: "3/4", gasolina_lleno: "Lleno",
      danos_notas_label: "Notas de daños / observaciones",
      orden_estado_no_enviado: "No se ha enviado al cliente",
      orden_estado_pendiente: "🕓 Pendiente de aceptación — enviado el",
      orden_estado_aceptado: "✅ Aceptado por el cliente el",
      btn_enviar_aceptacion: "📤 Enviar informe de recepción",
      btn_generando_pdf: "📄 Generando PDF…",
      btn_subiendo_pdf: "⬆️ Subiendo informe…",
      msg_error_informe_pdf: "Error al generar/subir el informe: ",
      ver_pdf_enviado: "📄 Ver PDF enviado",
      cotizacion_titulo: "📝 Cotización",
      cotizacion_desc: "Arma el presupuesto de servicio para el cliente — se genera como PDF y se manda por WhatsApp.",
      cotiz_concepto_placeholder: "Concepto (ej. Cambio de balatas delanteras)",
      cotiz_cant_label: "Cant.",
      cotiz_costo_unitario_label: "Costo unitario",
      cotiz_agregar_concepto: "+ Agregar concepto",
      cotiz_incluir_iva: "Incluir IVA (16%)",
      cotiz_subtotal: "Subtotal:",
      cotiz_iva: "IVA (16%):",
      cotiz_total_general: "Total general:",
      cotiz_observaciones_label: "Notas adicionales (opcional)",
      cotiz_tiempo_entrega_auto_label: "Tiempo estimado de entrega (del campo de arriba)",
      cotiz_tiempo_entrega_sin_registrar: "Sin registrar todavía — llénalo en \"Tiempo de entrega aproximado\" más arriba",
      cotiz_observaciones_placeholder: "Algo extra que este presupuesto en particular necesite aclarar (opcional)...",
      cotiz_estado_enviada: "✅ Cotización enviada el",
      cotiz_estado_no_enviada: "No se ha enviado al cliente",
      btn_enviar_cotizacion: "📤 Enviar cotización",
      msg_indica_al_menos_un_concepto: "Agrega al menos un concepto con costo antes de enviar la cotización.",
      wa_prompt_titulo_cotizacion: "📲 Enviar cotización",
      msg_cotizacion_wa: "Hola {nombre}, aquí está la cotización de servicio para tu {marca} {modelo} (placas {placas}){unidad}: {pdf}. Cualquier duda, contáctanos por este medio.",
      informe_trabajo_titulo: "📦 Informe de trabajo",
      informe_trabajo_desc: "Genera el informe final con las fotos de todo el proceso, el trabajo realizado, y el monto cobrado — se manda por WhatsApp.",
      informe_trabajo_estado_enviado: "✅ Informe enviado el",
      informe_trabajo_estado_no_enviado: "No se ha enviado al cliente",
      btn_enviar_informe_trabajo: "📤 Enviar informe de trabajo",
      wa_prompt_titulo_informe_trabajo: "📲 Enviar informe de trabajo",
      msg_informe_trabajo_wa: "Hola {nombre}, tu {marca} {modelo} (placas {placas}){unidad} ya está listo. Aquí está el informe completo de lo que se hizo: {pdf}. {agradecimiento}",
      cliente_acepto_check: "Cliente aceptó (márcalo al recibir su confirmación)",
      cliente_ya_acepto_txt: "✅ Cliente ya aceptó",
      cliente_acepto_cotizacion_check: "Cliente acepta cotización (márcalo al recibir su confirmación)",
      cliente_ya_acepto_cotizacion_txt: "✅ Cliente ya aceptó la cotización",
      msg_paso_a_en_proceso: "✅ Cliente aceptó — el servicio pasó a \"En proceso\" automáticamente.",
      msg_paso_a_diagnostico: "✅ Cliente aceptó — el servicio pasó a \"Diagnóstico\" automáticamente.",
      msg_paso_a_en_proceso_cotiz: "✅ Cliente aceptó la cotización — el servicio pasó a \"En proceso\" automáticamente.",
      wa_prompt_titulo_orden: "📲 Enviar informe de recepción",
      orden_faltantes_label: "Marcado como faltante o dañado",
      orden_recepcion_titulo_resumen: "📋 Ver hoja de recepción",
      msg_orden_wa: "Hola {nombre}, recibimos tu vehículo {marca} {modelo} (placas {placas}){unidad}. Aquí se encuentra el informe de recepción con todos los detalles del ingreso a taller de tu vehículo, revísalo y confírmanos que estás de acuerdo: {pdf} Y en el siguiente enlace podrás checar el progreso de tu vehículo en cualquier momento: {link} Saludos.",
      marcar_finalizado_btn: "✅ Marcar como finalizado",
      cancelar_servicio_btn: "Cancelar servicio en proceso",
      confirm_cancelar_servicio: "¿Cancelar este servicio en proceso? Se perderá lo capturado que aún no se ha guardado.",
      confirm_finalizar_servicio: "¿Marcar este servicio como finalizado? Pasará al historial y ya no se podrá editar (recuerda guardar los cambios después).",
      confirm_finalizar_incompleto: "Este servicio todavía tiene pendientes:\n\n{lista}\n\n¿Finalizar de todas formas?",
      resumen_no_entregado: "El vehículo no aparece como Entregado",
      resumen_pago_pendiente: "El pago no está marcado como Pagado",
      resumen_informe_no_enviado: "El informe de trabajo no se ha enviado",
      resumen_cotizacion_no_aceptada: "La cotización no ha sido aceptada por el cliente",
      confirm_eliminar_vehiculo: "¿Eliminar este vehículo de forma permanente?",
      confirm_salir_sin_guardar: "Tienes cambios sin guardar. ¿Salir de todas formas?",
    },
    en: {
      admin_titulo: "Team Bassoco — Admin",
      cerrar_sesion: "Log out",
      login_titulo: "Connect to the repository",
      login_desc_html: 'Connects directly to your GitHub repository using a personal token. Changes you make here are saved as commits in <code class="mono">data/vehicles.json</code>.',
      github_user_label: "GitHub username or organization",
      github_user_placeholder: "e.g. hmoralesc",
      repo_label: "Repository",
      repo_placeholder: "e.g. taller-bassoco",
      branch_label: "Branch",
      token_label: "Personal access token (fine-grained, Contents: Read and write permission)",
      btn_conectar: "Connect",
      login_note: 'The token stays saved on this device (never shared or uploaded anywhere) until you press "Log out". Use it only on your own phone or shop computer, never on a shared device. Create the token on GitHub → Settings → Developer settings → Fine-grained tokens, limited to this repository only.',
      ver_tablero: "📋 View status board",
      buscar_vehiculo_titulo: "Search vehicle",
      buscar_vehiculo_placeholder: "Search by plate, make, model, or customer...",
      vehiculos_registrados: "Registered vehicles",
      btn_agregar_vehiculo: "+ Add new vehicle",
      volver_lista: "← Back to list",
      llamar_btn: "📞 Call",
      whatsapp_btn: "💬 WhatsApp",
      datos_vehiculo: "Vehicle details",
      foto_vehiculo_label: "Vehicle photo",
      tomar_foto: "📷 Take photo",
      subir_fototeca: "🖼️ Upload from gallery",
      id_nfc_label: "NFC tag ID",
      id_nfc_placeholder: "e.g. ABC123",
      regenerar_id_title: "Generate another secure ID",
      id_nfc_warning_corto: "⚠️ This ID is short or easy to guess — anyone who figures it out could see this customer's data. We recommend using one of the auto-generated ones.",
      placas_label: "License plate",
      numero_unidad_label: "Unit number",
      unidad_prefix: "Unit",
      marca_label: "Make",
      modelo_label: "Model",
      anio_label: "Year",
      version_label: "Trim / engine",
      color_label: "Color",
      combustible_label: "Fuel",
      combustible_sin_especificar: "Not specified",
      combustible_gasolina: "Gasoline",
      combustible_diesel: "Diesel",
      combustible_electrico: "Electric",
      combustible_gas: "Gas",
      vin_label: "VIN",
      km_actual_label: "Current mileage",
      cliente_label: "Customer",
      telefono_cliente_label: "Customer phone",
      telefono_cliente_2_label: "Additional phone (optional)",
      correo_cliente_label: "Customer email (optional)",
      rfc_cliente_label: "Customer tax ID / RFC (optional)",
      direccion_cliente_label: "Customer address (optional)",
      documentos_vehiculo_titulo: "Vehicle documents",
      documentos_vehiculo_desc: "General vehicle photos or PDFs (registration card, insurance, etc.), not tied to a specific service. They appear in the customer's record as a dropdown.",
      fototeca_btn: "🖼️ Gallery",
      pdf_btn: "📄 PDF",
      ficha_tecnica_titulo: "Technical specs",
      aceite_tipo_label: "Oil (type)",
      aceite_cap_label: "Oil capacity",
      presion_llantas_label: "Tire pressure",
      bateria_label: "Battery",
      filtro_aire_label: "Air filter",
      filtro_aceite_label: "Oil filter",
      servicio_en_proceso_titulo: "🔧 Service in progress",
      historial_titulo: "Service history (completed)",
      historial_desc: "Only editable while a service is in progress. Once finalized, it stays as a permanent record.",
      guardar_btn: "Save changes to GitHub",
      guardar_todos_btn: "💾 Save all changes",
      guardar_y_volver_btn: "💾 Save and go back",
      guardado_justo_ahora_txt: "Saved just now",
      guardado_hace_1min_txt: "Saved 1 minute ago",
      guardado_hace_min_txt: "Saved {n} minutes ago",
      guardado_hace_1h_txt: "Saved 1 hour ago",
      guardado_hace_horas_txt: "Saved {n} hours ago",
      resumen_recibidos: "Received",
      resumen_diagnostico: "Diagnosis",
      resumen_en_proceso: "In progress",
      resumen_listos: "Ready",
      resumen_pendiente_cobro: "Pending collection",
      cambios_sin_guardar_txt: "Unsaved changes",
      copiar_enlace_btn: "🔗 Copy link",
      msg_enlace_copiado: "✓ Link copied",
      filtro_label: "Filter",
      filtro_todos: "All",
      filtro_requiere_atencion: "⚠ Needs attention",
      filtro_recibido: "Received",
      filtro_diagnostico: "Diagnosis",
      filtro_en_proceso: "In progress",
      filtro_listo: "Ready",
      filtro_entregados: "Delivered",
      filtro_pagados: "Paid",
      filtro_a_deber: "Owing",
      filtro_sin_servicio: "No active service",
      orden_label: "Sort",
      orden_reciente: "Most recent",
      orden_antiguo: "Oldest",
      orden_etapa: "Stage",
      orden_cliente: "Customer",
      orden_unidad: "Unit number",
      orden_deuda: "Owing first",
      pend_cliente_no_acepto: "Customer hasn't accepted",
      pend_cotizacion_pendiente: "Quote pending",
      pend_pago_pendiente: "Payment pending",
      pend_listo_para_recoger: "Ready for pickup",
      plantilla_elegir: "📋 Use template…",
      confirm_recuperar_borrador: "We found an unsaved draft of this vehicle (saved on {fecha}). Recover it? (Pending photo uploads can't be recovered this way, only text)",
      borrador_encontrado_titulo: "📝 We found a draft",
      borrador_encontrado_desc: "There are unsaved changes for this vehicle, auto-saved on {fecha}. Pending photo uploads can't be recovered this way, only text. What do you want to do?",
      borrador_btn_recuperar: "✅ Recover",
      borrador_btn_mantener: "🕓 Decide later (leave it as is)",
      borrador_btn_descartar: "🗑️ Discard draft",
      msg_edito_durante_guardado: "Saved, but you changed something else while it was uploading — press Save again to include that too.",
      confirm_retroceder_etapa: "You're moving this service back to an earlier stage — this rollback will be recorded. Continue?",
      cronologia_titulo: "🕓 Service timeline",
      descripcion_visible_hint: "The customer sees this on their page.",
      nota_interna_label: "Internal note (shop only)",
      nota_interna_hint: "The customer does NOT see this — use it for reminders, sensitive details, etc.",
      subiendo_progreso_btn: "⬆️ Uploading… {actual} of {total}",
      guardando_btn: "Saving…",
      guardado_btn: "Saved",
      eliminar_btn: "Delete vehicle",
      panel_admin_footer: "Admin panel",
      reportar_problema: "🛠️ Report a system issue",
      estado_recibido: "Received",
      estado_diagnostico: "Diagnosis",
      estado_en_proceso: "In progress",
      estado_listo: "Ready for pickup",
      estado_entregado: "Delivered",
      pago_comprobante: "Payment receipt",
      pago_no_pagado: "Not paid",
      pago_pagado: "Paid",
      pago_a_deber: "Balance due",
      sin_servicio_activo: "No active service",
      cambiar_tema: "Toggle theme",
      msg_completa_campos: "Fill in username, repository, and token.",
      msg_conectando: "Connecting…",
      msg_no_conectar: "Could not connect: ",
      msg_no_procesar_imagen: "Could not process the image",
      msg_no_leer_imagen: "Could not read the image",
      board_en_esta_etapa: "At this stage",
      board_otras_etapas_activas: "Other active stages",
      board_ningun_recibido: "No vehicles just received.",
      board_ningun_diagnostico: "No vehicles in diagnosis.",
      board_ningun_en_proceso: "No vehicles in progress.",
      board_ya_entregado: "Already delivered",
      board_aun_no_entrega: "Not delivered yet",
      board_otras_etapas: "Other stages",
      board_ningun_listo: "No vehicles ready for pickup yet.",
      board_pagos_titulo: "Payments",
      board_no_hay_activos: "No active services.",
      board_con_servicio_activo: "Has an active service",
      board_todos_tienen_activo: "All vehicles have an active service.",
      board_servicios_mes_titulo: "Services this month",
      board_servicios_mes_sub: "services",
      board_sin_servicios_mes: "No services yet this month.",
      board_ingresos_mes_titulo: "Income collected this month",
      board_ingresos_mes_sub: "collected",
      board_sin_ingresos_mes: "Nothing collected yet this month.",
      msg_sin_vehiculos_aqui: "No vehicles here.",
      quitar_btn: "Remove",
      servicio_generico: "Service",
      folio_label: "Folio",
      metodo_efectivo: "Cash",
      metodo_transferencia: "Bank transfer",
      msg_servicio_finalizado: 'Service finalized. Don\'t forget to press "Save changes to GitHub".',
      msg_id_nfc_obligatorio: "The NFC tag ID is required",
      msg_indica_tipo_servicio: "Enter at least the service type before finalizing",
      msg_ya_existe_id: "A vehicle with that ID already exists",
      msg_cambios_guardados: "Changes saved to GitHub",
      msg_error_guardar: "Error saving: ",
      msg_error_solo_json: "Your photos and documents already uploaded successfully — only saving the record failed. Press \"Save\" again, no need to pick anything again.",
      msg_finalizar_no_guardado: "Couldn't save — the service was NOT actually finalized. Try \"Mark as finished\" again.",
      buscar_huerfanos_btn: "🧹 Find orphaned files",
      orphan_buscando: "Searching…",
      orphan_titulo: "🧹 Orphaned files",
      orphan_desc: "Files uploaded to the repository that no vehicle uses anymore — safe to delete without affecting anything.",
      orphan_seleccionar_todos: "Select all",
      orphan_borrar_seleccionados: "Delete selected",
      orphan_ninguno: "✅ No orphaned files found.",
      orphan_ninguno_seleccionado: "Select at least one file to delete.",
      orphan_confirmar_borrado: "Permanently delete {n} file(s)? This can't be undone.",
      orphan_borrados_ok: "{n} file(s) deleted.",
      msg_arbol_truncado: "The repository has too many files to list at once — contact technical support to check this manually.",
      msg_conflicto_reintentando: "⏳ Someone else just saved changes — fetching the latest version and retrying...",
      msg_conflicto_resuelto: "✅ Done — the conflict was resolved and your changes are saved.",
      msg_conflicto_persistente: "Couldn't save: it looks like you and someone else are saving changes at almost the same time. Nothing you wrote was lost — just press \"Save changes to GitHub\" once more.",
      msg_vehiculo_eliminado: "Vehicle deleted",
      msg_vehiculo_eliminado_completo: "✓ Vehicle deleted completely ({n} file(s) removed)",
      msg_vehiculo_eliminado_parcial: "The vehicle was deleted, but {n} file(s) couldn't be removed — you can check them later from your GitHub account.",
      eliminando_registro_btn: "Deleting record…",
      eliminando_archivos_btn: "Deleting files… {actual} of {total}",
      msg_error_eliminar: "Error deleting: ",
      msg_subiendo_foto_vehiculo: "Uploading vehicle photo…",
      msg_foto_puede_tardar: "The photo was saved. GitHub Pages sometimes takes a while to publish it (occasionally several minutes, even on this same phone) — the page retries on its own a few times. If it's still not showing after a while, refresh the page.",
      msg_convirtiendo_heic: "Converting {nombre} from HEIC to JPG…",
      msg_fotos_heic_omitidas: "⚠️ {n} photo(s) could not be processed and were not uploaded: {nombres}. Try taking the photo again or use a different image.",
      msg_no_coinciden: "No matching vehicles.",
      msg_vacio_requiere_atencion: "✅ No vehicles need attention right now.",
      msg_vacio_recibido: "No newly received vehicles.",
      msg_vacio_diagnostico: "No vehicles in diagnosis.",
      msg_vacio_en_proceso: "No vehicles in progress.",
      msg_vacio_listo: "No vehicles ready for pickup.",
      msg_vacio_entregados: "No delivered vehicles.",
      msg_vacio_pagados: "No paid vehicles.",
      msg_vacio_a_deber: "No vehicles owing.",
      msg_vacio_sin_servicio: "All vehicles have an active service.",
      en_historial: "in history",
      sin_placa_texto: "no plate",
      ver_vehiculos_txt: "View vehicles",
      wa_sin_telefono: "This vehicle has no customer phone registered.",
      cerrar_btn: "Close",
      wa_prompt_titulo: "📲 Vehicle ready for pickup",
      wa_prompt_titulo_recibido: "📲 Vehicle received at the shop",
      wa_prompt_pre: "Do you want to notify",
      wa_prompt_post: "via WhatsApp?",
      enviar_whatsapp_btn: "📲 Send WhatsApp",
      ver_fotos_por_etapa: "View photos and documents by stage",
      sin_servicios_finalizados: "No completed services yet.",
      no_hay_servicio_proceso: "There's no service in progress right now.",
      iniciar_servicio_btn: "+ Start new service",
      tipo_servicio_label: "Service type",
      kilometraje_label: "Mileage",
      costo_estimado_label: "Price",
      tecnico_label: "Technician",
      tiempo_entrega_label: "Approximate delivery time",
      tiempo_entrega_placeholder: "e.g. Tomorrow afternoon, 2-3 days...",
      descripcion_label: "Description",
      etapa_actual_label: "Current stage",
      iniciado_txt: "Started",
      actualizado_txt: "Updated",
      pago_titulo: "💳 Payment",
      estado_pago_label: "Payment status",
      metodo_pago_label: "Payment method",
      monto_pagado_label: "Amount paid",
      saldo_pendiente_label: "Balance due",
      msg_metodo_pago_obligatorio: "To mark as \"Paid\" you need to pick a payment method first.",
      confirm_pagar_sin_monto: "There's no amount on record (no Price or Quote). Mark as paid anyway?",
      sin_especificar: "Not specified",
      orden_recepcion_titulo: "📋 Reception checklist",
      orden_recepcion_desc: "Vehicle inventory and requested work, for the customer to review and accept.",
      inventario_exteriores: "Exterior",
      inventario_accesorios: "Accessories",
      antena_item: "Antenna", espejo_lateral_item: "Side mirror", cristales_item: "Windows",
      emblema_item: "Emblem", tapon_ruedas_item: "Wheel caps (4)", molduras_completas_item: "Trim complete",
      tapon_gasolina_item: "Fuel cap",
      gato_item: "Jack", maneral_gato_item: "Jack handle", llave_ruedas_item: "Lug wrench",
      estuche_herramientas_item: "Tool kit", triangulo_seguridad_item: "Warning triangle",
      llanta_refaccion_item: "Spare tire", extinguidor_item: "Fire extinguisher",
      inv_si: "Yes", inv_no: "No", inv_sin_marcar: "Not marked",
      nivel_gasolina_label: "Fuel level",
      gasolina_vacio: "Empty", gasolina_1_4: "1/4", gasolina_1_2: "1/2", gasolina_3_4: "3/4", gasolina_lleno: "Full",
      danos_notas_label: "Damage notes / remarks",
      orden_estado_no_enviado: "Not sent to the customer yet",
      orden_estado_pendiente: "🕓 Pending acceptance — sent on",
      orden_estado_aceptado: "✅ Accepted by the customer on",
      btn_enviar_aceptacion: "📤 Send reception report",
      btn_generando_pdf: "📄 Generating PDF…",
      btn_subiendo_pdf: "⬆️ Uploading report…",
      msg_error_informe_pdf: "Error generating/uploading the report: ",
      ver_pdf_enviado: "📄 View sent PDF",
      cotizacion_titulo: "📝 Quote",
      cotizacion_desc: "Build the service estimate for the customer — generated as a PDF and sent via WhatsApp.",
      cotiz_concepto_placeholder: "Item (e.g. Front brake pad replacement)",
      cotiz_cant_label: "Qty.",
      cotiz_costo_unitario_label: "Unit cost",
      cotiz_agregar_concepto: "+ Add item",
      cotiz_incluir_iva: "Include tax (16%)",
      cotiz_subtotal: "Subtotal:",
      cotiz_iva: "Tax (16%):",
      cotiz_total_general: "Grand total:",
      cotiz_observaciones_label: "Additional notes (optional)",
      cotiz_tiempo_entrega_auto_label: "Estimated delivery time (from the field above)",
      cotiz_tiempo_entrega_sin_registrar: "Not set yet — fill in \"Approximate delivery time\" above",
      cotiz_observaciones_placeholder: "Anything extra this particular quote needs to clarify (optional)...",
      cotiz_estado_enviada: "✅ Quote sent on",
      cotiz_estado_no_enviada: "Not sent to the customer yet",
      btn_enviar_cotizacion: "📤 Send quote",
      msg_indica_al_menos_un_concepto: "Add at least one item with a cost before sending the quote.",
      wa_prompt_titulo_cotizacion: "📲 Send quote",
      msg_cotizacion_wa: "Hi {nombre}, here's the service quote for your {marca} {modelo} (plates {placas}){unidad}: {pdf}. Let us know if you have any questions.",
      informe_trabajo_titulo: "📦 Work report",
      informe_trabajo_desc: "Generates the final report with photos from the whole process, the work done, and the amount charged — sent via WhatsApp.",
      informe_trabajo_estado_enviado: "✅ Report sent on",
      informe_trabajo_estado_no_enviado: "Not sent to the customer yet",
      btn_enviar_informe_trabajo: "📤 Send work report",
      wa_prompt_titulo_informe_trabajo: "📲 Send work report",
      msg_informe_trabajo_wa: "Hi {nombre}, your {marca} {modelo} (plates {placas}){unidad} is ready. Here's the full report of what was done: {pdf}. {agradecimiento}",
      cliente_acepto_check: "Customer accepted (check once they confirm)",
      cliente_ya_acepto_txt: "✅ Customer already accepted",
      cliente_acepto_cotizacion_check: "Customer accepts quote (check once they confirm)",
      cliente_ya_acepto_cotizacion_txt: "✅ Customer already accepted the quote",
      msg_paso_a_en_proceso: "✅ Customer accepted — the service automatically moved to \"In progress\".",
      msg_paso_a_diagnostico: "✅ Customer accepted — the service automatically moved to \"Diagnosis\".",
      msg_paso_a_en_proceso_cotiz: "✅ Customer accepted the quote — the service automatically moved to \"In progress\".",
      wa_prompt_titulo_orden: "📲 Send reception report",
      orden_faltantes_label: "Marked as missing or damaged",
      orden_recepcion_titulo_resumen: "📋 View reception checklist",
      msg_orden_wa: "Hi {nombre}, we received your vehicle {marca} {modelo} (plates {placas}){unidad}. Here is the reception report with all the details of your vehicle's check-in at the shop, please review it and confirm you agree: {pdf} And at the following link you can check your vehicle's progress at any time: {link} Regards.",
      marcar_finalizado_btn: "✅ Mark as finished",
      cancelar_servicio_btn: "Cancel service in progress",
      confirm_cancelar_servicio: "Cancel this service in progress? Anything not yet saved will be lost.",
      confirm_finalizar_servicio: "Mark this service as finished? It will move to history and can no longer be edited (remember to save changes afterward).",
      confirm_finalizar_incompleto: "This service still has pending items:\n\n{lista}\n\nFinish anyway?",
      resumen_no_entregado: "The vehicle isn't marked as Delivered",
      resumen_pago_pendiente: "Payment isn't marked as Paid",
      resumen_informe_no_enviado: "The work report hasn't been sent",
      resumen_cotizacion_no_aceptada: "The quote hasn't been accepted by the customer",
      confirm_eliminar_vehiculo: "Permanently delete this vehicle?",
      confirm_salir_sin_guardar: "You have unsaved changes. Leave anyway?",
    },
  };

  let currentLang = "es";
  try { currentLang = localStorage.getItem(LANG_KEY) || "es"; } catch (e) {}

  function t(key) {
    return (STR[currentLang] && STR[currentLang][key]) || STR.es[key] || key;
  }

  function applyStaticTranslations() {
    document.querySelectorAll("[data-i18n]").forEach((el) => {
      el.innerHTML = t(el.dataset.i18n);
    });
    document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
      el.placeholder = t(el.dataset.i18nPlaceholder);
    });
    document.querySelectorAll("[data-i18n-title]").forEach((el) => {
      el.title = t(el.dataset.i18nTitle);
    });
    document.querySelectorAll(".lang-btn").forEach((b) => {
      b.classList.toggle("active", b.dataset.lang === currentLang);
    });
    const themeBtn = $("theme-toggle");
    if (themeBtn) themeBtn.title = t("cambiar_tema");
  }

  function setLang(lang) {
    if (lang !== "es" && lang !== "en") return;
    currentLang = lang;
    try { localStorage.setItem(LANG_KEY, lang); } catch (e) {}
    applyStaticTranslations();
    rerenderCurrentView();
  }

  function rerenderCurrentView() {
    if (!db) return;
    if ($("view-board").style.display !== "none") { renderBoard(); return; }
    if ($("view-editor").style.display !== "none") {
      renderVehiclePhotoPreview();
      renderVehicleDocsPreview();
      renderServicesList();
      renderActiveServiceCard();
      updateClientContactLinks();
      return;
    }
    renderDashboard($("search-box") ? $("search-box").value : "");
  }

  document.querySelectorAll(".lang-btn").forEach((btn) => {
    btn.addEventListener("click", () => setLang(btn.dataset.lang));
  });

  /* ---------------- Tema claro/oscuro ---------------- */

  const THEME_KEY = "taller_nfc_theme";

  function updateThemeIcon() {
    const btn = $("theme-toggle");
    const isLight = document.documentElement.getAttribute("data-theme") === "light";
    if (btn) btn.textContent = isLight ? "☀️" : "🌙";
    const logoImg = $("brand-logo-img");
    if (logoImg) logoImg.src = logoImg.src.replace(/logo-(white|black)\.png/, isLight ? "logo-black.png" : "logo-white.png");
  }

  function toggleTheme() {
    const isLight = document.documentElement.getAttribute("data-theme") === "light";
    if (isLight) {
      document.documentElement.removeAttribute("data-theme");
      try { localStorage.setItem(THEME_KEY, "dark"); } catch (e) {}
    } else {
      document.documentElement.setAttribute("data-theme", "light");
      try { localStorage.setItem(THEME_KEY, "light"); } catch (e) {}
    }
    updateThemeIcon();
  }

  const themeToggleBtn = $("theme-toggle");
  if (themeToggleBtn) themeToggleBtn.addEventListener("click", toggleTheme);
  updateThemeIcon();
  applyStaticTranslations();

  let cfg = null;           // { owner, repo, branch, token }
  let db = null;             // contenido completo de vehicles.json
  let dbSha = null;          // sha del archivo (necesario para actualizar)
  let currentVehicleId = null;
  let isNewVehicle = false;
  let hasUnsavedChanges = false;
  // Sube cada vez que se hace un cambio real de datos. Sirve para saber, al
  // terminar un guardado, si el admin alcanzó a modificar algo MIENTRAS se
  // guardaba — en ese caso NO hay que marcar "todo guardado", porque ese
  // cambio nuevo todavía no se mandó a GitHub.
  let contadorDeEdiciones = 0;

  let pendingServices = [];       // historial (servicios finalizados) del vehículo en edición
  let svcActual = null;           // servicio en proceso del vehículo en edición (o null)
  let toolPanelOpen = {};         // qué paneles-herramienta (Hoja de recepción, Cotización) están abiertos, por etapa
  let svcActualEstadoOriginal = null;
  let svcActualPending = null;    // File[] pendientes de subir, por etapa: { recibido:{fotos,documentos}, ... }

  let currentFotoPerfil = null;      // ruta ya guardada de la foto de perfil (o null)
  let vFotoPerfilPending = null;     // File pendiente de subir como nueva foto de perfil
  let vFotoPerfilRemoved = false;    // true si el usuario quitó la foto sin reemplazarla
  let currentDocumentosVehiculo = { fotos: [], documentos: [] }; // rutas ya guardadas
  let vDocsPending = { fotos: [], documentos: [] };               // File[] pendientes de subir

  function esc(str) {
    const div = document.createElement("div");
    div.textContent = str == null ? "" : String(str);
    return div.innerHTML;
  }

  function todayISO() {
    return new Date().toISOString().slice(0, 10);
  }

  function formatFechaCorta(iso) {
    if (!iso) return "";
    const d = new Date(iso + "T00:00:00");
    if (isNaN(d)) return iso;
    return d.toLocaleDateString("es-MX", { day: "2-digit", month: "short", year: "numeric" });
  }

  function emptyPendingStruct() {
    return {
      recibido: { fotos: [], documentos: [] },
      diagnostico: { fotos: [], documentos: [] },
      en_proceso: { fotos: [], documentos: [] },
      listo: { fotos: [], documentos: [] },
      recogido: { fotos: [], documentos: [] },
      pago: { fotos: [], documentos: [] },
    };
  }

  // GitHub Pages a veces sirve un 404 en caché para un archivo recién subido
  // (mientras su CDN termina de publicarlo), y ese error puede quedar "atorado"
  // varios minutos en un dispositivo concreto. Reintentamos con pausas cada vez
  // más largas durante varios minutos antes de rendirnos definitivamente.
  const IMG_RETRY_DELAYS = [1000, 2000, 4000, 8000, 15000, 30000, 60000, 120000, 180000];
  window.__imgRetry = function (el) {
    const n = Number(el.dataset.retryN) || 0;
    if (n >= IMG_RETRY_DELAYS.length) {
      const fallback = document.createElement("div");
      fallback.className = "img-fallback";
      fallback.textContent = "🚗";
      if (el.parentElement) el.parentElement.classList.remove("img-retrying");
      el.replaceWith(fallback);
      return;
    }
    el.dataset.retryN = String(n + 1);
    if (el.parentElement) el.parentElement.classList.add("img-retrying");
    const base = el.dataset.baseSrc || el.src.split("?")[0];
    el.dataset.baseSrc = base;
    setTimeout(() => { el.src = base + "?r=" + n + "-" + Date.now(); }, IMG_RETRY_DELAYS[n]);
  };
  window.__imgLoaded = function (el) {
    if (el.parentElement) el.parentElement.classList.remove("img-retrying");
  };

  // Apuntar directo al contenido crudo del repositorio (en vez de la ruta publicada
  // por GitHub Pages) para que las fotos recién subidas aparezcan casi al instante:
  // GitHub Pages publica el sitio completo (con retraso), mientras que este contenido
  // crudo refleja el repositorio apenas se guarda el commit.
  const REPO_OWNER = "Blaze151", REPO_NAME = "taller-bassoco", REPO_BRANCH = "main";
  // Datos del taller para los PDFs y mensajes — se toman de data/vehicles.json
  // (db.taller) para que un taller nuevo solo necesite cambiar esos datos,
  // sin tocar código. Los valores de respaldo son solo por si ese dato
  // específico no se llegó a llenar.
  function tallerInfoForPdf() {
    const t2 = (db && db.taller) || {};
    return {
      nombre: t2.nombre || "Team Bassoco Grupo Automotor Integrado",
      direccion: t2.direccion || "",
      telefono: t2.telefono || "",
      firmante: t2.firmante || "Luis Germán García Guajardo",
      agradecimiento: t2.mensaje_agradecimiento || `¡Gracias por tu confianza en ${t2.nombre || "Team Bassoco Grupo Automotor Integrado"}!`,
    };
  }

  function rawUrl(path) {
    if (!path) return "";
    return `https://raw.githubusercontent.com/${REPO_OWNER}/${REPO_NAME}/${REPO_BRANCH}/${path}`;
  }

  function showToast(msg, type, duration) {
    const el = document.createElement("div");
    el.className = "toast " + (type || "");
    el.textContent = msg;
    document.body.appendChild(el);
    positionToasts();
    setTimeout(() => { el.remove(); positionToasts(); }, duration || 3800);
  }

  // Apila los toasts activos uno encima del otro en vez de que se encimen exactamente.
  function positionToasts() {
    const toasts = Array.from(document.querySelectorAll(".toast"));
    let bottom = 20;
    for (let i = toasts.length - 1; i >= 0; i--) {
      toasts[i].style.bottom = bottom + "px";
      bottom += (toasts[i].offsetHeight || 44) + 10;
    }
  }

  function showView(name) {
    $("view-login").style.display = name === "login" ? "block" : "none";
    $("view-dashboard").style.display = name === "dashboard" ? "block" : "none";
    $("view-board").style.display = name === "board" ? "block" : "none";
    $("view-editor").style.display = name === "editor" ? "block" : "none";
    $("btn-logout").style.display = name === "login" ? "none" : "inline-flex";
    $("btn-save").style.display = name === "editor" ? "flex" : "none";

    const active = $("view-" + name);
    if (active) {
      active.classList.remove("view-fade-in");
      void active.offsetWidth; // reinicia la animación aunque se repita la misma vista
      active.classList.add("view-fade-in");
    }
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  /* ---------------- GitHub API helpers ---------------- */

  function apiUrl(path) {
    return `https://api.github.com/repos/${cfg.owner}/${cfg.repo}/contents/${path}`;
  }

  // Buscador de archivos huérfanos: compara todo lo que hay en uploads/
  // contra todo lo que vehicles.json realmente referencia, para encontrar
  // archivos que quedaron subidos pero sin usar (por ejemplo, si el guardado
  // falló a medias, o de correcciones anteriores).
  async function fetchRepoTree() {
    const res = await fetch(`https://api.github.com/repos/${cfg.owner}/${cfg.repo}/git/trees/${encodeURIComponent(cfg.branch)}?recursive=1`, {
      headers: { "Authorization": `Bearer ${cfg.token}`, "Accept": "application/vnd.github+json" },
    });
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      const err = new Error(body.message || `Error de GitHub (${res.status})`);
      err.status = res.status;
      throw err;
    }
    const data = await res.json();
    if (data.truncated) throw new Error(t("msg_arbol_truncado"));
    return (data.tree || []).filter((n) => n.type === "blob" && n.path.startsWith("uploads/")).map((n) => n.path);
  }

  function collectAllReferencedPaths() {
    const referenced = new Set();
    const addGroup = (g) => {
      if (!g) return;
      (g.fotos || []).forEach((p) => p && referenced.add(p));
      (g.documentos || []).forEach((p) => p && referenced.add(p));
    };
    const addServicio = (s) => {
      if (!s) return;
      if (s.adjuntos) Object.values(s.adjuntos).forEach(addGroup);
      if (s.orden_recepcion && s.orden_recepcion.pdf_path) referenced.add(s.orden_recepcion.pdf_path);
      if (s.cotizacion && s.cotizacion.pdf_path) referenced.add(s.cotizacion.pdf_path);
      if (s.informe_trabajo && s.informe_trabajo.pdf_path) referenced.add(s.informe_trabajo.pdf_path);
    };
    Object.values(db.vehicles || {}).forEach((v) => {
      if (v.foto_perfil) referenced.add(v.foto_perfil);
      addGroup(v.documentos_vehiculo);
      addServicio(v.servicio_actual);
      (v.servicios || []).forEach(addServicio);
    });
    return referenced;
  }

  async function findOrphanedFiles() {
    const [allFiles, referenced] = await Promise.all([fetchRepoTree(), Promise.resolve(collectAllReferencedPaths())]);
    return allFiles.filter((p) => !referenced.has(p));
  }

  async function githubRequest(path, options) {
    const res = await fetch(apiUrl(path), {
      ...options,
      headers: {
        "Authorization": `Bearer ${cfg.token}`,
        "Accept": "application/vnd.github+json",
        ...(options && options.headers ? options.headers : {}),
      },
    });
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      const err = new Error(body.message || `Error de GitHub (${res.status})`);
      err.status = res.status;
      throw err;
    }
    return res.json();
  }

  function b64EncodeUnicode(str) {
    return btoa(unescape(encodeURIComponent(str)));
  }

  function b64DecodeUnicode(str) {
    return decodeURIComponent(escape(atob(str)));
  }

  /* ---------------- Archivos: compresión, codificación y subida ---------------- */

  function compressImage(file, maxDim, quality) {
    maxDim = maxDim || 1400;
    quality = quality || 0.68;
    return new Promise((resolve, reject) => {
      const objectUrl = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => {
        let { width, height } = img;
        if (width > maxDim || height > maxDim) {
          if (width > height) { height = Math.round((height * maxDim) / width); width = maxDim; }
          else { width = Math.round((width * maxDim) / height); height = maxDim; }
        }
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0, width, height);
        canvas.toBlob((blob) => {
          URL.revokeObjectURL(objectUrl);
          if (!blob) return reject(new Error(t("msg_no_procesar_imagen")));
          resolve(blob);
        }, "image/jpeg", quality);
      };
      img.onerror = () => { URL.revokeObjectURL(objectUrl); reject(new Error(t("msg_no_leer_imagen"))); };
      img.src = objectUrl;
    });
  }

  function blobToBase64(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result).split(",")[1] || "");
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  }

  function slugifyFilename(name) {
    return name
      .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-zA-Z0-9._-]/g, "-")
      .replace(/-+/g, "-");
  }

  function timestampSlug() {
    const d = new Date();
    const p = (n) => String(n).padStart(2, "0");
    return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
  }

  // Algunos celulares (sobre todo iPhone) guardan fotos en formato HEIC/HEIF.
  // Los navegadores (salvo Safari) no pueden mostrar ese formato en una etiqueta
  // <img>, así que si se sube tal cual (aunque se le cambie el nombre a .jpg)
  // se ve como ícono roto para casi todos menos para quien la subió. Para
  // evitarlo, las convertimos a JPG de verdad usando heic2any (se carga solo
  // si de verdad hace falta, para no pesar la página en el resto de los casos).
  let skippedPhotoNames = [];

  function looksLikeHeic(file) {
    const type = (file.type || "").toLowerCase();
    const name = (file.name || "").toLowerCase();
    return type.includes("heic") || type.includes("heif") || /\.(heic|heif)$/.test(name);
  }

  // Carga un script externo (jsPDF, heic2any) con reintentos automáticos. A
  // diferencia de antes, si un intento falla (común en datos móviles con
  // archivos de varios cientos de KB) NO se queda atorado para siempre — se
  // vuelve a intentar un par de veces antes de darse por vencido de verdad.
  function loadScriptWithRetry(src, isLoadedCheck, intentos) {
    intentos = intentos || 3;
    if (isLoadedCheck()) return Promise.resolve();
    return new Promise((resolve, reject) => {
      let intento = 0;
      function tryLoad() {
        intento++;
        const s = document.createElement("script");
        s.src = src + "?r=" + intento; // evita servir una respuesta fallida cacheada
        s.onload = () => resolve();
        s.onerror = () => {
          s.remove();
          if (intento >= intentos) {
            reject(new Error("No se pudo cargar " + src.split("/").pop() + " tras varios intentos — revisa tu conexión."));
          } else {
            setTimeout(tryLoad, 500 * intento);
          }
        };
        document.head.appendChild(s);
      }
      tryLoad();
    });
  }

  function loadHeic2any() {
    return loadScriptWithRetry("../assets/heic2any.min.js", () => !!window.heic2any);
  }

  async function convertHeicToJpeg(file) {
    await loadHeic2any();
    const result = await window.heic2any({ blob: file, toType: "image/jpeg", quality: 0.85 });
    return Array.isArray(result) ? result[0] : result;
  }

  // ---------------- Generador del informe de recepción en PDF ----------------
  // jsPDF se carga solo cuando de verdad hace falta (al enviar un informe),
  // igual que heic2any — así no pesa la carga normal del panel.
  function loadJsPdf() {
    return loadScriptWithRetry("../assets/jspdf.umd.min.js", () => !!window.jspdf);
  }

  function blobToDataUrl(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result));
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  }

  function imageDataUrlSize(dataUrl) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve({ w: img.naturalWidth, h: img.naturalHeight });
      img.onerror = reject;
      img.src = dataUrl;
    });
  }

  // Junta las fotos de "Recibido" ya guardadas (las bajamos de GitHub) y las
  // que aún no se han subido (las leemos directo del archivo local), para que
  // el informe las incluya sin importar si ya se guardaron o no.
  async function collectStageImageDataUrls(stage, svcActualForPdf, pendingForPdf) {
    const out = [];
    const saved = (svcActualForPdf.adjuntos && svcActualForPdf.adjuntos[stage] && svcActualForPdf.adjuntos[stage].fotos) || [];
    for (const path of saved) {
      try {
        const res = await fetch(rawUrl(path));
        const blob = await res.blob();
        out.push(await blobToDataUrl(blob));
      } catch (err) { /* si una foto no carga, seguimos con las demás */ }
    }
    const pending = (pendingForPdf && pendingForPdf[stage] && pendingForPdf[stage].fotos) || [];
    for (const file of pending) {
      try {
        // Igual que al subir de verdad: si es HEIC, convertirla primero — si no,
        // se usa tal cual. Así el PDF no se salta fotos de iPhone en silencio.
        const usable = looksLikeHeic(file) ? await convertHeicToJpeg(file) : file;
        out.push(await blobToDataUrl(usable));
      } catch (err) { /* seguimos */ }
    }
    return out;
  }

  async function generarInformeRecepcionPDF(vehicle, svcActualForPdf, pendingForPdf) {
    await loadJsPdf();
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ unit: "mm", format: "letter" });
    const pageW = doc.internal.pageSize.getWidth();
    const pageH = doc.internal.pageSize.getHeight();
    const marginX = 15;
    const bottomLimit = pageH - 16;
    let y = 18;

    const DARK = [20, 23, 26], GREEN = [243, 59, 49], GREY = [110, 110, 110];
    const taller = tallerInfoForPdf();

    function ensureSpace(need) {
      if (y + need > bottomLimit) { doc.addPage(); y = 18; }
    }
    function sectionTitle(txt) {
      ensureSpace(10);
      doc.setFont("helvetica", "bold"); doc.setFontSize(12); doc.setTextColor(...DARK);
      doc.text(txt, marginX, y);
      y += 3;
      doc.setDrawColor(...GREEN); doc.setLineWidth(0.4);
      doc.line(marginX, y, pageW - marginX, y);
      y += 6;
    }
    function fieldLine(label, value) {
      ensureSpace(6);
      doc.setFont("helvetica", "bold"); doc.setFontSize(9.5); doc.setTextColor(...GREY);
      doc.text(label + ":", marginX, y);
      doc.setFont("helvetica", "normal"); doc.setTextColor(...DARK);
      doc.text(String(value || "—"), marginX + 45, y);
      y += 5.5;
    }
    function paragraph(label, text) {
      ensureSpace(10);
      doc.setFont("helvetica", "bold"); doc.setFontSize(9.5); doc.setTextColor(...GREY);
      doc.text(label + ":", marginX, y);
      y += 5;
      doc.setFont("helvetica", "normal"); doc.setFontSize(9.5); doc.setTextColor(...DARK);
      const lines = doc.splitTextToSize(text, pageW - marginX * 2);
      ensureSpace(lines.length * 4.6);
      doc.text(lines, marginX, y);
      y += lines.length * 4.6 + 2;
    }

    // Encabezado
    let logoDataUrl = null;
    try {
      const logoRes = await fetch("../assets/logo-black.png");
      logoDataUrl = await blobToDataUrl(await logoRes.blob());
    } catch (err) { /* si el logo no carga, seguimos sin él */ }

    // Logo horizontal (ya incluye el nombre del taller). Si no carga,
    // se escribe el nombre en texto como respaldo.
    const logoW = 62, logoH = logoW * (249 / 1200);
    const textX = marginX;
    let textY = y + 6;
    let logoOk = false;
    if (logoDataUrl) {
      try { doc.addImage(logoDataUrl, "PNG", marginX, y - 6, logoW, logoH); logoOk = true; textY = y - 6 + logoH + 5; } catch (err) { /* seguimos sin logo si falla */ }
    }
    if (!logoOk) {
      doc.setFont("helvetica", "bold"); doc.setFontSize(16); doc.setTextColor(...DARK);
      doc.text(taller.nombre.toUpperCase(), textX, y);
    }
    doc.setFont("helvetica", "normal"); doc.setFontSize(10.5); doc.setTextColor(...GREEN);
    doc.text("Informe de Recepción del Vehículo", textX, textY);
    doc.setFontSize(8); doc.setTextColor(...GREY);
    doc.text(taller.direccion, textX, textY + 5.5);

    if (svcActualForPdf.folio) {
      doc.setFont("helvetica", "bold"); doc.setFontSize(13); doc.setTextColor(...GREEN);
      doc.text(`Folio: ${svcActualForPdf.folio}`, pageW - marginX, y, { align: "right" });
    }
    doc.setFont("helvetica", "normal"); doc.setFontSize(8); doc.setTextColor(...GREY);
    doc.text(`Generado: ${new Date().toLocaleString("es-MX")}`, pageW - marginX, y + 6, { align: "right" });

    y = Math.max(y + 16, textY + 9.5);
    doc.setDrawColor(...GREEN); doc.setLineWidth(0.7);
    doc.line(marginX, y, pageW - marginX, y);
    y += 9;

    sectionTitle("Datos del vehículo");
    fieldLine("Marca / Modelo", `${vehicle.marca || ""} ${vehicle.modelo || ""}`.trim());
    fieldLine("Placas", vehicle.placas);
    if (vehicle.numero_unidad) fieldLine("Número de unidad", vehicle.numero_unidad);
    fieldLine("Año / Color", `${vehicle.anio || "—"} · ${vehicle.color || "—"}`);
    if (vehicle.vin) fieldLine("VIN", vehicle.vin);
    fieldLine("Kilometraje", vehicle.km_actual ? `${vehicle.km_actual} km` : "—");
    if (vehicle.combustible) fieldLine("Combustible", vehicle.combustible);
    fieldLine("Cliente", vehicle.cliente_nombre);
    fieldLine("Teléfono", vehicle.cliente_telefono);
    if (vehicle.cliente_correo) fieldLine("Correo", vehicle.cliente_correo);
    if (vehicle.cliente_rfc) fieldLine("RFC", vehicle.cliente_rfc);
    if (vehicle.cliente_direccion) paragraph("Dirección", vehicle.cliente_direccion);
    y += 3;

    sectionTitle("Servicio en proceso");
    fieldLine("Tipo de servicio", svcActualForPdf.tipo);
    if (svcActualForPdf.descripcion) paragraph("Descripción", svcActualForPdf.descripcion);
    fieldLine("Técnico", svcActualForPdf.tecnico);
    if (svcActualForPdf.tiempo_entrega_aprox) paragraph("Tiempo de entrega aproximado", svcActualForPdf.tiempo_entrega_aprox);
    fieldLine("Precio", svcActualForPdf.costo ? `$${Number(svcActualForPdf.costo).toLocaleString("es-MX")}` : "—");
    fieldLine("Fecha de recepción", svcActualForPdf.fecha_inicio);
    y += 3;

    const or = svcActualForPdf.orden_recepcion || emptyOrdenRecepcion();
    const inv = or.inventario;
    sectionTitle("Hoja de recepción — Inventario del vehículo");
    doc.setFont("helvetica", "bold"); doc.setFontSize(9.5); doc.setTextColor(...DARK);
    doc.text("Exteriores", marginX, y);
    doc.text("Accesorios", marginX + (pageW - marginX * 2) / 2, y);
    y += 5.5;
    const maxRows = Math.max(INVENTARIO_EXTERIORES.length, INVENTARIO_ACCESORIOS.length);
    const colW = (pageW - marginX * 2) / 2;
    for (let i = 0; i < maxRows; i++) {
      ensureSpace(5.5);
      doc.setFont("helvetica", "normal"); doc.setFontSize(9); doc.setTextColor(...DARK);
      if (INVENTARIO_EXTERIORES[i]) {
        const [k, lk] = INVENTARIO_EXTERIORES[i];
        const val = inv.exteriores[k] === "si" ? "Sí" : "No";
        doc.text(`${t(lk)}: ${val}`, marginX, y);
      }
      if (INVENTARIO_ACCESORIOS[i]) {
        const [k, lk] = INVENTARIO_ACCESORIOS[i];
        const val = inv.accesorios[k] === "si" ? "Sí" : "No";
        doc.text(`${t(lk)}: ${val}`, marginX + colW, y);
      }
      y += 5;
    }
    y += 3;
    fieldLine("Nivel de gasolina", inv.gasolina != null ? `${inv.gasolina}%` : "—");
    if (inv.danos_notas) paragraph("Notas de daños / observaciones", inv.danos_notas);
    y += 2;

    const fotos = await collectStageImageDataUrls("recibido", svcActualForPdf, pendingForPdf);
    if (fotos.length) {
      sectionTitle("Fotos al recibir el vehículo");
      const imgW = 82, gap = 6;
      let x = marginX, rowH = 0;
      for (const dataUrl of fotos) {
        try {
          const dims = await imageDataUrlSize(dataUrl);
          const imgH = imgW * (dims.h / dims.w);
          if (x + imgW > pageW - marginX + 0.1) { x = marginX; y += rowH + gap; rowH = 0; }
          const pageBefore = doc.internal.getNumberOfPages();
          ensureSpace(imgH);
          if (doc.internal.getNumberOfPages() !== pageBefore) { x = marginX; rowH = 0; } // si saltó de página, reiniciar la fila
          doc.addImage(dataUrl, "JPEG", x, y, imgW, imgH);
          rowH = Math.max(rowH, imgH);
          x += imgW + gap;
        } catch (err) { /* si una foto falla al insertarse, seguimos con las demás */ }
      }
      y += rowH + 6;
    }

    // Firma
    ensureSpace(30);
    doc.setFont("helvetica", "normal"); doc.setFontSize(9); doc.setTextColor(...DARK);
    doc.text("Atentamente:", pageW / 2, y, { align: "center" });
    y += 3;
    let firmaDataUrl = null;
    try {
      const firmaRes = await fetch("../assets/firma.png");
      firmaDataUrl = await blobToDataUrl(await firmaRes.blob());
    } catch (err) { /* si la firma no carga, seguimos sin ella */ }
    if (firmaDataUrl) {
      const firmaW = 42, firmaH = firmaW * (376 / 912);
      try { doc.addImage(firmaDataUrl, "PNG", pageW / 2 - firmaW / 2, y, firmaW, firmaH); } catch (err) { /* seguimos sin firma si falla */ }
      y += firmaH + 2;
    } else {
      y += 10;
    }
    doc.setFont("helvetica", "bold"); doc.setFontSize(9.5);
    doc.text(taller.firmante, pageW / 2, y, { align: "center" });
    y += 4.5;
    doc.setFont("helvetica", "normal"); doc.setFontSize(8); doc.setTextColor(...GREY);
    doc.text([taller.nombre, taller.direccion, taller.telefono ? "Tel: " + taller.telefono : ""].filter(Boolean).join(" · "), pageW / 2, y, { align: "center" });
    y += 10;

    doc.setFont("helvetica", "normal"); doc.setFontSize(7.5); doc.setTextColor(...GREY);
    doc.text(`Documento generado automáticamente por el sistema NFC de ${taller.nombre}.`, marginX, pageH - 10);

    return doc.output("blob");
  }

  async function generarCotizacionPDF(vehicle, svcActualForPdf, pendingForPdf) {
    await loadJsPdf();
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ unit: "mm", format: "letter" });
    const pageW = doc.internal.pageSize.getWidth();
    const pageH = doc.internal.pageSize.getHeight();
    const marginX = 15;
    const bottomLimit = pageH - 16;
    let y = 18;

    const DARK = [20, 23, 26], GREEN = [243, 59, 49], GREY = [110, 110, 110];
    const taller = tallerInfoForPdf();

    function ensureSpace(need) {
      if (y + need > bottomLimit) { doc.addPage(); y = 18; }
    }
    function sectionTitle(txt) {
      ensureSpace(10);
      doc.setFont("helvetica", "bold"); doc.setFontSize(12); doc.setTextColor(...DARK);
      doc.text(txt, marginX, y);
      y += 3;
      doc.setDrawColor(...GREEN); doc.setLineWidth(0.4);
      doc.line(marginX, y, pageW - marginX, y);
      y += 6;
    }
    function fieldLine(label, value) {
      ensureSpace(6);
      doc.setFont("helvetica", "bold"); doc.setFontSize(9.5); doc.setTextColor(...GREY);
      doc.text(label + ":", marginX, y);
      doc.setFont("helvetica", "normal"); doc.setTextColor(...DARK);
      doc.text(String(value || "—"), marginX + 45, y);
      y += 5.5;
    }
    function paragraph(label, text) {
      ensureSpace(10);
      doc.setFont("helvetica", "bold"); doc.setFontSize(9.5); doc.setTextColor(...GREY);
      doc.text(label + ":", marginX, y);
      y += 5;
      doc.setFont("helvetica", "normal"); doc.setFontSize(9.5); doc.setTextColor(...DARK);
      const lines = doc.splitTextToSize(text, pageW - marginX * 2);
      ensureSpace(lines.length * 4.6);
      doc.text(lines, marginX, y);
      y += lines.length * 4.6 + 2;
    }

    // Encabezado (igual al del informe de recepción)
    let logoDataUrl = null;
    try {
      const logoRes = await fetch("../assets/logo-black.png");
      logoDataUrl = await blobToDataUrl(await logoRes.blob());
    } catch (err) { /* si el logo no carga, seguimos sin él */ }

    // Logo horizontal (ya incluye el nombre del taller). Si no carga,
    // se escribe el nombre en texto como respaldo.
    const logoW = 62, logoH = logoW * (249 / 1200);
    const textX = marginX;
    let textY = y + 6;
    let logoOk = false;
    if (logoDataUrl) {
      try { doc.addImage(logoDataUrl, "PNG", marginX, y - 6, logoW, logoH); logoOk = true; textY = y - 6 + logoH + 5; } catch (err) { /* seguimos sin logo si falla */ }
    }
    if (!logoOk) {
      doc.setFont("helvetica", "bold"); doc.setFontSize(16); doc.setTextColor(...DARK);
      doc.text(taller.nombre.toUpperCase(), textX, y);
    }
    doc.setFont("helvetica", "normal"); doc.setFontSize(10.5); doc.setTextColor(...GREEN);
    doc.text("Presupuesto de Servicio", textX, textY);
    doc.setFontSize(8); doc.setTextColor(...GREY);
    doc.text(taller.direccion, textX, textY + 5.5);

    if (svcActualForPdf.folio) {
      doc.setFont("helvetica", "bold"); doc.setFontSize(13); doc.setTextColor(...GREEN);
      doc.text(`Folio: ${svcActualForPdf.folio}`, pageW - marginX, y, { align: "right" });
    }
    doc.setFont("helvetica", "normal"); doc.setFontSize(8); doc.setTextColor(...GREY);
    doc.text(`Fecha: ${new Date().toLocaleDateString("es-MX", { day: "numeric", month: "long", year: "numeric" })}`, pageW - marginX, y + 6, { align: "right" });

    y = Math.max(y + 16, textY + 9.5);
    doc.setDrawColor(...GREEN); doc.setLineWidth(0.7);
    doc.line(marginX, y, pageW - marginX, y);
    y += 9;

    doc.setFont("helvetica", "bold"); doc.setFontSize(13); doc.setTextColor(...DARK);
    doc.text("PRESUPUESTO DE SERVICIO", pageW / 2, y, { align: "center" });
    y += 10;

    fieldLine("Cliente", vehicle.cliente_nombre);
    if (vehicle.cliente_rfc) fieldLine("RFC", vehicle.cliente_rfc);
    if (vehicle.cliente_correo) fieldLine("Correo", vehicle.cliente_correo);
    if (vehicle.cliente_direccion) paragraph("Dirección", vehicle.cliente_direccion);
    const vehLine = `${vehicle.marca || ""} ${vehicle.modelo || ""}`.trim() +
      (vehicle.numero_unidad ? `   Unidad: ${vehicle.numero_unidad}` : "") +
      `   Placas: ${vehicle.placas || "N/A"}`;
    fieldLine("Vehículo", vehLine);
    fieldLine("Kilometraje", vehicle.km_actual ? `${Number(vehicle.km_actual).toLocaleString("es-MX")} km` : "—");
    y += 4;

    // Tabla de conceptos
    const cot = svcActualForPdf.cotizacion || emptyCotizacion();
    sectionTitle("Descripción del trabajo");
    const colConceptoW = (pageW - marginX * 2) * 0.52;
    const colCantW = (pageW - marginX * 2) * 0.1;
    const colCostoW = (pageW - marginX * 2) * 0.19;
    const colTotalW = (pageW - marginX * 2) * 0.19;
    const rowTopY = y;
    doc.setFillColor(252, 228, 226);
    doc.rect(marginX, y - 5, pageW - marginX * 2, 7, "F");
    doc.setFont("helvetica", "bold"); doc.setFontSize(9); doc.setTextColor(...DARK);
    doc.text("Concepto", marginX + 2, y);
    doc.text("Cant", marginX + colConceptoW + colCantW / 2, y, { align: "center" });
    doc.text("Costo unitario", marginX + colConceptoW + colCantW + colCostoW / 2, y, { align: "center" });
    doc.text("Total", pageW - marginX - colTotalW / 2, y, { align: "center" });
    y += 6;
    doc.setFont("helvetica", "normal"); doc.setFontSize(9);
    (cot.items || []).forEach((item) => {
      const lines = doc.splitTextToSize(item.concepto || "—", colConceptoW - 4);
      ensureSpace(lines.length * 4.6 + 2);
      doc.text(lines, marginX + 2, y);
      const rowTotal = (Number(item.cantidad) || 0) * (Number(item.costo_unitario) || 0);
      doc.text(String(item.cantidad ?? "—"), marginX + colConceptoW + colCantW / 2, y, { align: "center" });
      doc.text(item.costo_unitario != null ? `$${Number(item.costo_unitario).toLocaleString("es-MX")}` : "—", marginX + colConceptoW + colCantW + colCostoW / 2, y, { align: "center" });
      doc.text(`$${rowTotal.toLocaleString("es-MX")}`, pageW - marginX - colTotalW / 2, y, { align: "center" });
      y += Math.max(lines.length * 4.6, 5.5) + 2;
    });
    doc.setDrawColor(200, 200, 200); doc.setLineWidth(0.2);
    doc.rect(marginX, rowTopY - 5, pageW - marginX * 2, y - rowTopY + 3);
    y += 5;

    // Totales, alineados a la derecha
    const { subtotal, iva, total } = calcCotizacionTotales(cot.items || [], cot.incluir_iva);
    const totalsX = pageW - marginX - 55;
    function totalLine(label, value, bold) {
      doc.setFont("helvetica", bold ? "bold" : "normal"); doc.setFontSize(bold ? 11 : 9.5);
      doc.setTextColor(...(bold ? GREEN : DARK));
      doc.text(label, totalsX, y);
      doc.text(`$${value.toLocaleString("es-MX", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, pageW - marginX, y, { align: "right" });
      y += bold ? 7 : 6;
    }
    ensureSpace(20);
    totalLine("Subtotal:", subtotal, false);
    if (cot.incluir_iva) totalLine("IVA (16%):", iva, false);
    doc.setDrawColor(...GREEN); doc.setLineWidth(0.5);
    doc.line(totalsX, y - 4, pageW - marginX, y - 4);
    totalLine("Total general:", total, true);
    y += 4;

    const tiempoEntregaLinea = svcActualForPdf.tiempo_entrega_aprox ? `- Tiempo estimado de entrega: ${svcActualForPdf.tiempo_entrega_aprox}` : "";
    const lineasFijas = [
      tiempoEntregaLinea,
      "- El precio incluye refacciones, materiales y mano de obra.",
      "- Presupuesto válido por 5 días a partir de la fecha de expedición.",
    ].filter(Boolean);
    const observacionesCompletas = [...lineasFijas, cot.observaciones].filter(Boolean).join("\n");
    if (observacionesCompletas) {
      sectionTitle("Observaciones");
      doc.setFont("helvetica", "normal"); doc.setFontSize(9.5); doc.setTextColor(...DARK);
      const lines = doc.splitTextToSize(observacionesCompletas, pageW - marginX * 2);
      ensureSpace(lines.length * 4.8);
      doc.text(lines, marginX, y);
      y += lines.length * 4.8 + 6;
    }

    ensureSpace(30);
    doc.setFont("helvetica", "normal"); doc.setFontSize(9); doc.setTextColor(...DARK);
    doc.text("Atentamente:", pageW / 2, y, { align: "center" });
    y += 3;

    let firmaDataUrl = null;
    try {
      const firmaRes = await fetch("../assets/firma.png");
      firmaDataUrl = await blobToDataUrl(await firmaRes.blob());
    } catch (err) { /* si la firma no carga, seguimos sin ella */ }
    if (firmaDataUrl) {
      const firmaW = 42, firmaH = firmaW * (376 / 912);
      try { doc.addImage(firmaDataUrl, "PNG", pageW / 2 - firmaW / 2, y, firmaW, firmaH); } catch (err) { /* seguimos sin firma si falla */ }
      y += firmaH + 2;
    } else {
      y += 10;
    }

    doc.setFont("helvetica", "bold"); doc.setFontSize(9.5);
    doc.text(taller.firmante, pageW / 2, y, { align: "center" });
    y += 4.5;
    doc.setFont("helvetica", "normal"); doc.setFontSize(8); doc.setTextColor(...GREY);
    doc.text([taller.nombre, taller.direccion, taller.telefono ? "Tel: " + taller.telefono : ""].filter(Boolean).join(" · "), pageW / 2, y, { align: "center" });
    y += 12;

    // Fotos: Recibido y Diagnóstico, separadas con su propio subtítulo
    const fotosRecibido = await collectStageImageDataUrls("recibido", svcActualForPdf, pendingForPdf);
    const fotosDiagnostico = await collectStageImageDataUrls("diagnostico", svcActualForPdf, pendingForPdf);

    async function drawPhotoGrid(titulo, fotos) {
      if (!fotos.length) return;
      sectionTitle(titulo);
      const imgW = 82, gap = 6;
      let x = marginX, rowH = 0;
      for (const dataUrl of fotos) {
        try {
          const dims = await imageDataUrlSize(dataUrl);
          const imgH = imgW * (dims.h / dims.w);
          if (x + imgW > pageW - marginX + 0.1) { x = marginX; y += rowH + gap; rowH = 0; }
          const pageBefore = doc.internal.getNumberOfPages();
          ensureSpace(imgH);
          if (doc.internal.getNumberOfPages() !== pageBefore) { x = marginX; rowH = 0; }
          doc.addImage(dataUrl, "JPEG", x, y, imgW, imgH);
          rowH = Math.max(rowH, imgH);
          x += imgW + gap;
        } catch (err) { /* si una foto falla al insertarse, seguimos con las demás */ }
      }
      y += rowH + 8;
    }
    await drawPhotoGrid("Fotos de recepción", fotosRecibido);
    await drawPhotoGrid("Fotos del diagnóstico", fotosDiagnostico);

    doc.setFont("helvetica", "normal"); doc.setFontSize(7.5); doc.setTextColor(...GREY);
    doc.text(`Documento generado automáticamente por el sistema NFC de ${taller.nombre}.`, marginX, pageH - 10);

    return doc.output("blob");
  }

  async function generarInformeTrabajoPDF(vehicle, svcActualForPdf, pendingForPdf) {
    await loadJsPdf();
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ unit: "mm", format: "letter" });
    const pageW = doc.internal.pageSize.getWidth();
    const pageH = doc.internal.pageSize.getHeight();
    const marginX = 15;
    const bottomLimit = pageH - 16;
    let y = 18;

    const DARK = [20, 23, 26], GREEN = [243, 59, 49], GREY = [110, 110, 110];
    const taller = tallerInfoForPdf();

    function ensureSpace(need) {
      if (y + need > bottomLimit) { doc.addPage(); y = 18; }
    }
    function sectionTitle(txt) {
      ensureSpace(10);
      doc.setFont("helvetica", "bold"); doc.setFontSize(12); doc.setTextColor(...DARK);
      doc.text(txt, marginX, y);
      y += 3;
      doc.setDrawColor(...GREEN); doc.setLineWidth(0.4);
      doc.line(marginX, y, pageW - marginX, y);
      y += 6;
    }
    function fieldLine(label, value) {
      ensureSpace(6);
      doc.setFont("helvetica", "bold"); doc.setFontSize(9.5); doc.setTextColor(...GREY);
      doc.text(label + ":", marginX, y);
      doc.setFont("helvetica", "normal"); doc.setTextColor(...DARK);
      doc.text(String(value || "—"), marginX + 45, y);
      y += 5.5;
    }
    function paragraph(label, text) {
      ensureSpace(10);
      doc.setFont("helvetica", "bold"); doc.setFontSize(9.5); doc.setTextColor(...GREY);
      doc.text(label + ":", marginX, y);
      y += 5;
      doc.setFont("helvetica", "normal"); doc.setFontSize(9.5); doc.setTextColor(...DARK);
      const lines = doc.splitTextToSize(text, pageW - marginX * 2);
      ensureSpace(lines.length * 4.6);
      doc.text(lines, marginX, y);
      y += lines.length * 4.6 + 2;
    }

    // Encabezado
    let logoDataUrl = null;
    try {
      const logoRes = await fetch("../assets/logo-black.png");
      logoDataUrl = await blobToDataUrl(await logoRes.blob());
    } catch (err) { /* si el logo no carga, seguimos sin él */ }

    // Logo horizontal (ya incluye el nombre del taller). Si no carga,
    // se escribe el nombre en texto como respaldo.
    const logoW = 62, logoH = logoW * (249 / 1200);
    const textX = marginX;
    let textY = y + 6;
    let logoOk = false;
    if (logoDataUrl) {
      try { doc.addImage(logoDataUrl, "PNG", marginX, y - 6, logoW, logoH); logoOk = true; textY = y - 6 + logoH + 5; } catch (err) { /* seguimos sin logo si falla */ }
    }
    if (!logoOk) {
      doc.setFont("helvetica", "bold"); doc.setFontSize(16); doc.setTextColor(...DARK);
      doc.text(taller.nombre.toUpperCase(), textX, y);
    }
    doc.setFont("helvetica", "normal"); doc.setFontSize(10.5); doc.setTextColor(...GREEN);
    doc.text("Informe de Trabajo", textX, textY);
    doc.setFontSize(8); doc.setTextColor(...GREY);
    doc.text(taller.direccion, textX, textY + 5.5);

    if (svcActualForPdf.folio) {
      doc.setFont("helvetica", "bold"); doc.setFontSize(13); doc.setTextColor(...GREEN);
      doc.text(`Folio: ${svcActualForPdf.folio}`, pageW - marginX, y, { align: "right" });
    }
    doc.setFont("helvetica", "normal"); doc.setFontSize(8); doc.setTextColor(...GREY);
    doc.text(`Fecha: ${new Date().toLocaleDateString("es-MX", { day: "numeric", month: "long", year: "numeric" })}`, pageW - marginX, y + 6, { align: "right" });

    y = Math.max(y + 16, textY + 9.5);
    doc.setDrawColor(...GREEN); doc.setLineWidth(0.7);
    doc.line(marginX, y, pageW - marginX, y);
    y += 9;

    doc.setFont("helvetica", "bold"); doc.setFontSize(13); doc.setTextColor(...DARK);
    doc.text("INFORME DE TRABAJO REALIZADO", pageW / 2, y, { align: "center" });
    y += 10;

    fieldLine("Cliente", vehicle.cliente_nombre);
    if (vehicle.cliente_rfc) fieldLine("RFC", vehicle.cliente_rfc);
    if (vehicle.cliente_correo) fieldLine("Correo", vehicle.cliente_correo);
    if (vehicle.cliente_direccion) paragraph("Dirección", vehicle.cliente_direccion);
    const vehLine = `${vehicle.marca || ""} ${vehicle.modelo || ""}`.trim() +
      (vehicle.numero_unidad ? `   Unidad: ${vehicle.numero_unidad}` : "") +
      `   Placas: ${vehicle.placas || "N/A"}`;
    fieldLine("Vehículo", vehLine);
    fieldLine("Kilometraje", vehicle.km_actual ? `${Number(vehicle.km_actual).toLocaleString("es-MX")} km` : "—");
    y += 4;

    sectionTitle("Trabajo realizado");
    fieldLine("Tipo de servicio", svcActualForPdf.tipo);
    if (svcActualForPdf.descripcion) paragraph("Descripción", svcActualForPdf.descripcion);
    fieldLine("Técnico", svcActualForPdf.tecnico);
    y += 3;

    // Montos: si hay una cotización con conceptos, se usa esa (más detallada);
    // si no, se usa el precio general del servicio.
    const cot = svcActualForPdf.cotizacion;
    const tieneCotizacion = cot && (cot.items || []).some((it) => (Number(it.cantidad) || 0) * (Number(it.costo_unitario) || 0) > 0);
    sectionTitle("Monto cobrado");
    if (tieneCotizacion) {
      const { subtotal, iva, total } = calcCotizacionTotales(cot.items, cot.incluir_iva);
      fieldLine("Subtotal", `$${subtotal.toLocaleString("es-MX", { minimumFractionDigits: 2 })}`);
      if (cot.incluir_iva) fieldLine("IVA (16%)", `$${iva.toLocaleString("es-MX", { minimumFractionDigits: 2 })}`);
      doc.setFont("helvetica", "bold"); doc.setFontSize(11); doc.setTextColor(...GREEN);
      doc.text("Total cobrado:", marginX, y);
      doc.text(`$${total.toLocaleString("es-MX", { minimumFractionDigits: 2 })}`, marginX + 45, y);
      y += 8;
    } else {
      fieldLine("Total cobrado", svcActualForPdf.costo ? `$${Number(svcActualForPdf.costo).toLocaleString("es-MX")}` : "—");
    }
    y += 3;

    // Fotos de todas las etapas, cada una con su propio subtítulo
    const subtitulosPorEtapa = {
      recibido: "Fotos de recepción",
      diagnostico: "Fotos del diagnóstico",
      en_proceso: "Fotos del trabajo en proceso",
      listo: "Fotos — listo para recoger",
      recogido: "Fotos de entrega",
    };
    async function drawPhotoGrid(titulo, fotos) {
      if (!fotos.length) return;
      sectionTitle(titulo);
      const imgW = 82, gap = 6;
      let x = marginX, rowH = 0;
      for (const dataUrl of fotos) {
        try {
          const dims = await imageDataUrlSize(dataUrl);
          const imgH = imgW * (dims.h / dims.w);
          if (x + imgW > pageW - marginX + 0.1) { x = marginX; y += rowH + gap; rowH = 0; }
          const pageBefore = doc.internal.getNumberOfPages();
          ensureSpace(imgH);
          if (doc.internal.getNumberOfPages() !== pageBefore) { x = marginX; rowH = 0; }
          doc.addImage(dataUrl, "JPEG", x, y, imgW, imgH);
          rowH = Math.max(rowH, imgH);
          x += imgW + gap;
        } catch (err) { /* si una foto falla al insertarse, seguimos con las demás */ }
      }
      y += rowH + 8;
    }
    for (const stage of ["recibido", "diagnostico", "en_proceso", "listo", "recogido"]) {
      const fotos = await collectStageImageDataUrls(stage, svcActualForPdf, pendingForPdf);
      await drawPhotoGrid(subtitulosPorEtapa[stage], fotos);
    }

    // Firma y agradecimiento
    ensureSpace(36);
    doc.setFont("helvetica", "normal"); doc.setFontSize(9); doc.setTextColor(...DARK);
    doc.text("Atentamente:", pageW / 2, y, { align: "center" });
    y += 3;
    let firmaDataUrl = null;
    try {
      const firmaRes = await fetch("../assets/firma.png");
      firmaDataUrl = await blobToDataUrl(await firmaRes.blob());
    } catch (err) { /* si la firma no carga, seguimos sin ella */ }
    if (firmaDataUrl) {
      const firmaW = 42, firmaH = firmaW * (376 / 912);
      try { doc.addImage(firmaDataUrl, "PNG", pageW / 2 - firmaW / 2, y, firmaW, firmaH); } catch (err) { /* seguimos sin firma si falla */ }
      y += firmaH + 2;
    } else {
      y += 10;
    }
    doc.setFont("helvetica", "bold"); doc.setFontSize(9.5);
    doc.text(taller.firmante, pageW / 2, y, { align: "center" });
    y += 4.5;
    doc.setFont("helvetica", "normal"); doc.setFontSize(8); doc.setTextColor(...GREY);
    doc.text([taller.nombre, taller.direccion, taller.telefono ? "Tel: " + taller.telefono : ""].filter(Boolean).join(" · "), pageW / 2, y, { align: "center" });
    y += 12;

    ensureSpace(16);
    doc.setFont("helvetica", "italic"); doc.setFontSize(9.5); doc.setTextColor(...GREEN);
    doc.text(taller.agradecimiento, pageW / 2, y, { align: "center" });

    doc.setFont("helvetica", "normal"); doc.setFontSize(7.5); doc.setTextColor(...GREY);
    doc.text(`Documento generado automáticamente por el sistema NFC de ${taller.nombre}.`, marginX, pageH - 10);

    return doc.output("blob");
  }

  async function compressOrSkip(file, maxDim, quality) {
    let workingFile = file;
    if (looksLikeHeic(file)) {
      try {
        showToast(t("msg_convirtiendo_heic").replace("{nombre}", file.name || "foto"));
        workingFile = await convertHeicToJpeg(file);
      } catch (err) {
        skippedPhotoNames.push(file.name || "foto");
        return null;
      }
    }
    try {
      return await compressImage(workingFile, maxDim, quality);
    } catch (err) {
      skippedPhotoNames.push(file.name || "foto");
      return null;
    }
  }

  async function runWithConcurrency(items, limit, worker) {
    let idx = 0;
    async function runner() {
      while (idx < items.length) {
        const i = idx++;
        await worker(items[i], i);
        // Pequeña pausa entre cada subida: le da margen a GitHub para terminar de
        // registrar el commit anterior antes de recibir el siguiente, evitando
        // choques por escrituras demasiado seguidas hacia el mismo repositorio.
        if (idx < items.length) await new Promise((r) => setTimeout(r, 120));
      }
    }
    const n = Math.min(limit, items.length);
    await Promise.all(Array.from({ length: n }, runner));
  }
  // NOTA IMPORTANTE: subir varios archivos AL MISMO TIEMPO (en paralelo) hacia el
  // mismo repositorio de GitHub puede disparar límites internos de GitHub para
  // escrituras simultáneas, lo cual provocaba choques falsos de "alguien más
  // guardó" incluso siendo un solo usuario. Por eso se subes uno por uno
  // (concurrencia = 1) — es un poco más lento con muchas fotos, pero mucho más
  // confiable, que es lo que de verdad importa.
  const UPLOAD_CONCURRENCY = 1;

  async function uploadBinaryFile(path, base64Content, message) {
    return githubRequest(path, {
      method: "PUT",
      body: JSON.stringify({ message, content: base64Content, branch: cfg.branch }),
    });
  }

  // Borrado real de archivos en GitHub (no solo quitar la referencia en vehicles.json).
  // La API de GitHub exige el sha vigente del archivo para poder borrarlo, así que
  // primero lo consultamos y luego mandamos el DELETE.
  let pendingDeletePaths = [];
  function queueDelete(path) {
    if (path && !pendingDeletePaths.includes(path)) pendingDeletePaths.push(path);
  }
  async function deleteFileFromRepo(path) {
    const meta = await githubRequest(path, { method: "GET" });
    await githubRequest(path, {
      method: "DELETE",
      body: JSON.stringify({ message: `Eliminar archivo — ${path}`, sha: meta.sha, branch: cfg.branch }),
    });
  }
  async function flushPendingDeletes() {
    const paths = pendingDeletePaths;
    pendingDeletePaths = [];
    for (const path of paths) {
      try { await deleteFileFromRepo(path); } catch (err) { /* si uno falla, seguimos con los demás */ }
    }
  }
  async function deleteVehicleUploadsFolder(vehicleId, onProgress) {
    let entries;
    try {
      entries = await githubRequest(`uploads/${encodeURIComponent(vehicleId)}`, { method: "GET" });
    } catch (err) {
      return { total: 0, fallidos: [] }; // no existe la carpeta (o ya está vacía) — nada que borrar
    }
    if (!Array.isArray(entries)) return { total: 0, fallidos: [] };
    const archivos = entries.filter((e) => e.type === "file");
    const fallidos = [];
    for (let i = 0; i < archivos.length; i++) {
      const entry = archivos[i];
      if (onProgress) onProgress(i + 1, archivos.length);
      try {
        await githubRequest(entry.path, {
          method: "DELETE",
          body: JSON.stringify({ message: `Eliminar archivos del vehículo ${vehicleId}`, sha: entry.sha, branch: cfg.branch }),
        });
      } catch (err) {
        fallidos.push(entry.path); // seguimos con los demás aunque uno falle, pero se reporta al final
      }
    }
    return { total: archivos.length, fallidos };
  }
  function collectServiceAttachmentPaths(s) {
    const paths = [];
    if (s.adjuntos) {
      ATTACH_STAGES.forEach((stage) => {
        const g = s.adjuntos[stage];
        if (g) { paths.push(...(g.fotos || [])); paths.push(...(g.documentos || [])); }
      });
    } else {
      paths.push(...(s.fotos || [])); paths.push(...(s.documentos || []));
    }
    if (s.orden_recepcion && s.orden_recepcion.pdf_path) paths.push(s.orden_recepcion.pdf_path);
    if (s.cotizacion && s.cotizacion.pdf_path) paths.push(s.cotizacion.pdf_path);
    if (s.informe_trabajo && s.informe_trabajo.pdf_path) paths.push(s.informe_trabajo.pdf_path);
    return paths;
  }

  // Sube adjuntos pendientes del historial (fotos/documentos de un servicio que
  // se acaba de finalizar en esta sesión), conservando la etapa de cada uno.
  async function uploadPendingAttachments(vehicle) {
    for (const service of vehicle.servicios) {
      if (!service._pendingAdjuntos) continue;
      if (!service.adjuntos) service.adjuntos = emptyPendingStruct();

      for (const stage of ATTACH_STAGES) {
        const pend = service._pendingAdjuntos[stage] || { fotos: [], documentos: [] };
        if (!service.adjuntos[stage]) service.adjuntos[stage] = { fotos: [], documentos: [] };
        const stageLabel = (ESTADOS_SERVICIO()[stage] || PAGO_INFO()).label;

        if (pend.fotos.length) showToast(`Subiendo ${pend.fotos.length} foto(s) (${stageLabel})…`);
        await runWithConcurrency(pend.fotos, UPLOAD_CONCURRENCY, async (file, i) => {
          const blob = await compressOrSkip(file);
          if (!blob) return;
          const base64 = await blobToBase64(blob);
          const filename = `${timestampSlug()}-${stage}-${i}-${slugifyFilename(file.name.replace(/\.[^.]+$/, ""))}.jpg`;
          const path = `uploads/${vehicle.id}/${filename}`;
          await uploadBinaryFile(path, base64, `Agregar foto (${stageLabel}, historial) — ${vehicle.placas || vehicle.id}`);
          service.adjuntos[stage].fotos.push(path);
          bumpUploadProgress();
        });

        if (pend.documentos.length) showToast(`Subiendo ${pend.documentos.length} documento(s) (${stageLabel})…`);
        await runWithConcurrency(pend.documentos, UPLOAD_CONCURRENCY, async (file, i) => {
          const base64 = await blobToBase64(file);
          const filename = `${timestampSlug()}-${stage}-${i}-${slugifyFilename(file.name)}`;
          const path = `uploads/${vehicle.id}/${filename}`;
          await uploadBinaryFile(path, base64, `Agregar documento (${stageLabel}, historial) — ${vehicle.placas || vehicle.id}`);
          service.adjuntos[stage].documentos.push(path);
          bumpUploadProgress();
        });
      }
      delete service._pendingAdjuntos;
    }
  }

  // Sube adjuntos pendientes del servicio EN PROCESO, separados por etapa.
  async function uploadPendingActiveServiceAttachments(vehicle) {
    const active = vehicle.servicio_actual;
    if (!active || !active._pendingAdjuntos) return;

    for (const stage of ATTACH_STAGES) {
      const pend = active._pendingAdjuntos[stage] || { fotos: [], documentos: [] };
      if (!active.adjuntos[stage]) active.adjuntos[stage] = { fotos: [], documentos: [] };
      const stageLabel = (ESTADOS_SERVICIO()[stage] || PAGO_INFO()).label;

      if (pend.fotos.length) showToast(`Subiendo ${pend.fotos.length} foto(s) (${stageLabel})…`);
      await runWithConcurrency(pend.fotos, UPLOAD_CONCURRENCY, async (file, i) => {
        const blob = await compressOrSkip(file);
        if (!blob) return;
        const base64 = await blobToBase64(blob);
        const filename = `${timestampSlug()}-${stage}-${i}-${slugifyFilename(file.name.replace(/\.[^.]+$/, ""))}.jpg`;
        const path = `uploads/${vehicle.id}/${filename}`;
        await uploadBinaryFile(path, base64, `Agregar foto (${stageLabel}) — ${vehicle.placas || vehicle.id}`);
        active.adjuntos[stage].fotos.push(path);
        bumpUploadProgress();
      });

      if (pend.documentos.length) showToast(`Subiendo ${pend.documentos.length} documento(s) (${stageLabel})…`);
      await runWithConcurrency(pend.documentos, UPLOAD_CONCURRENCY, async (file, i) => {
        const base64 = await blobToBase64(file);
        const filename = `${timestampSlug()}-${stage}-${i}-${slugifyFilename(file.name)}`;
        const path = `uploads/${vehicle.id}/${filename}`;
        await uploadBinaryFile(path, base64, `Agregar documento (${stageLabel}) — ${vehicle.placas || vehicle.id}`);
        active.adjuntos[stage].documentos.push(path);
        bumpUploadProgress();
      });
    }
    delete active._pendingAdjuntos;
  }

  // Sube la foto de perfil y los documentos generales del vehículo (no ligados a un servicio).
  async function uploadVehicleLevelAttachments(vehicle) {
    if (vehicle._pendingFotoPerfil) {
      showToast(t("msg_subiendo_foto_vehiculo"));
      const blob = await compressOrSkip(vehicle._pendingFotoPerfil, 1200, 0.8);
      if (blob) {
        const base64 = await blobToBase64(blob);
        const filename = `${timestampSlug()}-perfil.jpg`;
        const path = `uploads/${vehicle.id}/${filename}`;
        await uploadBinaryFile(path, base64, `Actualizar foto del vehículo (${vehicle.placas || vehicle.id})`);
        vehicle.foto_perfil = path;
        bumpUploadProgress();
      }
    }
    delete vehicle._pendingFotoPerfil;

    if (!vehicle.documentos_vehiculo) vehicle.documentos_vehiculo = { fotos: [], documentos: [] };
    const pend = vehicle._pendingDocumentosVehiculo || { fotos: [], documentos: [] };

    if (pend.fotos.length) showToast(`Subiendo ${pend.fotos.length} foto(s) del vehículo…`);
    await runWithConcurrency(pend.fotos, UPLOAD_CONCURRENCY, async (file, i) => {
      const blob = await compressOrSkip(file);
      if (!blob) return;
      const base64 = await blobToBase64(blob);
      const filename = `${timestampSlug()}-vdoc-${i}-${slugifyFilename(file.name.replace(/\.[^.]+$/, ""))}.jpg`;
      const path = `uploads/${vehicle.id}/${filename}`;
      await uploadBinaryFile(path, base64, `Agregar foto del vehículo (${vehicle.placas || vehicle.id})`);
      vehicle.documentos_vehiculo.fotos.push(path);
      bumpUploadProgress();
    });

    if (pend.documentos.length) showToast(`Subiendo ${pend.documentos.length} documento(s) del vehículo…`);
    await runWithConcurrency(pend.documentos, UPLOAD_CONCURRENCY, async (file, i) => {
      const base64 = await blobToBase64(file);
      const filename = `${timestampSlug()}-vdoc-${i}-${slugifyFilename(file.name)}`;
      const path = `uploads/${vehicle.id}/${filename}`;
      await uploadBinaryFile(path, base64, `Agregar documento del vehículo (${vehicle.placas || vehicle.id})`);
      vehicle.documentos_vehiculo.documentos.push(path);
      bumpUploadProgress();
    });
    delete vehicle._pendingDocumentosVehiculo;
  }

  async function loadDatabase() {
    const file = await githubRequest(`${DATA_PATH}?ref=${encodeURIComponent(cfg.branch)}`, { method: "GET", cache: "no-store" });
    dbSha = file.sha;
    const content = b64DecodeUnicode(file.content.replace(/\n/g, ""));
    db = JSON.parse(content);
    if (!db.vehicles) db.vehicles = {};
    if (!db.taller) db.taller = {};
    if (!db.folio_counter) db.folio_counter = 0;
  }

  async function saveDatabase(commitMessage) {
    const content = b64EncodeUnicode(JSON.stringify(db, null, 2));
    const result = await githubRequest(DATA_PATH, {
      method: "PUT",
      body: JSON.stringify({
        message: commitMessage,
        content: content,
        sha: dbSha,
        branch: cfg.branch,
      }),
    });
    dbSha = result.content.sha;
  }

  // Guarda con reintento automático si alguien más (otra pestaña/dispositivo) guardó justo
  // antes que nosotros — o si simplemente GitHub tardó un instante en reflejar nuestro
  // propio guardado anterior. En vez de sobrescribir a ciegas, trae lo más reciente de
  // GitHub (sin caché), vuelve a aplicar SOLO nuestro propio cambio sobre esos datos
  // frescos (con reapplyFn), y reintenta hasta 2 veces con una pequeña pausa entre cada
  // intento — así no se pierden los cambios que haya hecho la otra sesión.
  async function saveDatabaseWithRetry(commitMessage, reapplyFn) {
    reapplyFn();
    try {
      await saveDatabase(commitMessage);
      return;
    } catch (err) {
      if (err.status !== 409) throw err;
    }
    const intentos = 4;
    for (let intento = 1; intento <= intentos; intento++) {
      showToast(t("msg_conflicto_reintentando"), "");
      await new Promise((r) => setTimeout(r, 600 * intento));
      await loadDatabase();
      reapplyFn();
      try {
        await saveDatabase(commitMessage);
        showToast(t("msg_conflicto_resuelto"), "success");
        return;
      } catch (err) {
        if (err.status !== 409 || intento === intentos) throw err;
      }
    }
  }
  async function saveVehicleWithRetry(vehicle, commitMessage) {
    const folioCounterLocal = db.folio_counter || 0;
    return saveDatabaseWithRetry(commitMessage, () => {
      // Si hubo que traer datos frescos por un choque, nunca dejamos que el contador
      // de folio retroceda por debajo de lo que ya usamos localmente — así un folio
      // asignado en esta sesión nunca se vuelve a repetir en otro servicio.
      db.folio_counter = Math.max(db.folio_counter || 0, folioCounterLocal);
      db.vehicles[vehicle.id] = vehicle;
    });
  }

  /* ---------------- Login / sesión ---------------- */

  function restoreSession() {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) return false;
    try {
      cfg = JSON.parse(raw);
      return !!(cfg.owner && cfg.repo && cfg.token);
    } catch {
      return false;
    }
  }

  async function connect() {
    const owner = $("cfg-owner").value.trim();
    const repo = $("cfg-repo").value.trim();
    const branch = $("cfg-branch").value.trim() || "main";
    const token = $("cfg-token").value.trim();
    const errEl = $("login-error");
    errEl.style.display = "none";

    if (!owner || !repo || !token) {
      errEl.textContent = t("msg_completa_campos");
      errEl.style.display = "block";
      return;
    }

    cfg = { owner, repo, branch, token };
    const btn = $("btn-connect");
    btn.disabled = true;
    btn.textContent = t("msg_conectando");

    try {
      await loadDatabase();
      localStorage.setItem(SESSION_KEY, JSON.stringify(cfg));
      renderDashboard();
      showView("dashboard");
    } catch (err) {
      errEl.textContent = t("msg_no_conectar") + err.message;
      errEl.style.display = "block";
    } finally {
      btn.disabled = false;
      btn.textContent = t("btn_conectar");
    }
  }

  function logout() {
    localStorage.removeItem(SESSION_KEY);
    cfg = null;
    db = null;
    showView("login");
  }

  /* ---------------- Dashboard ---------------- */

  // Insignias de "algo pendiente" para ver de un vistazo qué vehículo
  // necesita atención sin tener que abrir cada uno.
  function vehiclePendingBadges(v) {
    const active = v.servicio_actual;
    if (!active) return [];
    const badges = [];
    if (active.orden_recepcion && active.orden_recepcion.enviado && !active.orden_recepcion.aceptado) {
      badges.push({ txt: t("pend_cliente_no_acepto"), cls: "warn" });
    }
    const cot = active.cotizacion;
    const cotTieneItems = cot && (cot.items || []).some((it) => (Number(it.cantidad) || 0) * (Number(it.costo_unitario) || 0) > 0);
    if (cotTieneItems && cot.enviado && !cot.aceptado) {
      badges.push({ txt: t("pend_cotizacion_pendiente"), cls: "warn" });
    }
    if (active.pago && active.pago.estado !== "pagado") {
      badges.push({ txt: t("pend_pago_pendiente"), cls: "warn" });
    }
    if (active.estado === "listo") {
      badges.push({ txt: t("pend_listo_para_recoger"), cls: "ok" });
    }
    return badges;
  }

  function renderDashboard(filter) {
    const list = $("vehicle-list");
    const filtroEl = $("filter-select");
    const ordenEl = $("sort-select");
    const filtroActivo = filtroEl ? filtroEl.value : "todos";
    const ordenActivo = ordenEl ? ordenEl.value : "reciente";

    let entries = Object.values(db.vehicles || {});

    // Del más reciente al más antiguo por defecto. Los vehículos nuevos ya
    // guardan su fecha de creación; los que ya existían de antes no la
    // tienen, así que para esos se respeta el orden en que aparecen en el
    // archivo (los agregados más tarde van primero entre ellos).
    entries = entries
      .map((v, i) => ({ v, i }))
      .sort((a, b) => {
        const ta = a.v.fecha_creacion ? Date.parse(a.v.fecha_creacion) : -Infinity;
        const tb = b.v.fecha_creacion ? Date.parse(b.v.fecha_creacion) : -Infinity;
        return ta !== tb ? tb - ta : b.i - a.i;
      })
      .map((e) => e.v);

    if (ordenActivo === "antiguo") entries = entries.slice().reverse();
    else if (ordenActivo === "etapa") {
      entries = entries.slice().sort((a, b) => {
        const ia = a.servicio_actual ? ORDEN_ESTADOS_SERVICIO.indexOf(a.servicio_actual.estado) : 99;
        const ib = b.servicio_actual ? ORDEN_ESTADOS_SERVICIO.indexOf(b.servicio_actual.estado) : 99;
        return ia - ib;
      });
    } else if (ordenActivo === "cliente") {
      entries = entries.slice().sort((a, b) => (a.cliente_nombre || "").localeCompare(b.cliente_nombre || ""));
    } else if (ordenActivo === "unidad") {
      entries = entries.slice().sort((a, b) => (a.numero_unidad || "").localeCompare(b.numero_unidad || "", undefined, { numeric: true }));
    } else if (ordenActivo === "deuda") {
      entries = entries.slice().sort((a, b) => {
        const da = a.servicio_actual && a.servicio_actual.pago && a.servicio_actual.pago.estado === "a_deber" ? 0 : 1;
        const db_ = b.servicio_actual && b.servicio_actual.pago && b.servicio_actual.pago.estado === "a_deber" ? 0 : 1;
        return da - db_;
      });
    }

    if (filtroActivo !== "todos") {
      entries = entries.filter((v) => {
        const active = v.servicio_actual;
        if (filtroActivo === "requiere_atencion") return vehiclePendingBadges(v).length > 0;
        if (filtroActivo === "sin_servicio") return !active;
        if (filtroActivo === "pagado") return active && active.pago && active.pago.estado === "pagado";
        if (filtroActivo === "a_deber") return active && active.pago && active.pago.estado === "a_deber";
        return active && active.estado === filtroActivo;
      });
    }

    const term = (filter || "").toLowerCase();
    const filtered = entries.filter((v) => {
      if (!term) return true;
      const camposBasicos = [v.placas, v.marca, v.modelo, v.cliente_nombre, v.id, v.numero_unidad]
        .filter(Boolean)
        .some((f) => String(f).toLowerCase().includes(term));
      if (camposBasicos) return true;
      const folios = [
        v.servicio_actual && v.servicio_actual.folio,
        ...(v.servicios || []).map((s) => s.folio),
      ].filter(Boolean);
      return folios.some((f) => String(f).toLowerCase().includes(term));
    });

    if (!filtered.length) {
      const mensajesVacioPorFiltro = {
        requiere_atencion: "msg_vacio_requiere_atencion",
        recibido: "msg_vacio_recibido",
        diagnostico: "msg_vacio_diagnostico",
        en_proceso: "msg_vacio_en_proceso",
        listo: "msg_vacio_listo",
        recogido: "msg_vacio_entregados",
        pagado: "msg_vacio_pagados",
        a_deber: "msg_vacio_a_deber",
        sin_servicio: "msg_vacio_sin_servicio",
      };
      const clave = !term && mensajesVacioPorFiltro[filtroActivo];
      list.innerHTML = `<p style="color:var(--text-faint);font-size:13px;">${esc(t(clave || "msg_no_coinciden"))}</p>`;
      return;
    }

    list.innerHTML = filtered.map((v) => {
      const active = v.servicio_actual;
      const badge = active
        ? `<span class="status-chip st-${active.estado}">${ESTADOS_SERVICIO()[active.estado].icon} ${ESTADOS_SERVICIO()[active.estado].label}</span>`
        : `<span class="tag">${esc(t("sin_servicio_activo"))}</span>`;
      const pagoInfo = active && active.pago ? PAGO_ESTADOS()[active.pago.estado] : null;
      const pagoBadge = pagoInfo ? `<span class="tag">${pagoInfo.icon} ${pagoInfo.label}</span>` : "";
      const pendientesHtml = vehiclePendingBadges(v).map((b) =>
        `<span class="tag" style="color:${b.cls === "ok" ? "var(--green-bright)" : "var(--yellow)"};">${b.cls === "ok" ? "✅" : "⚠"} ${esc(b.txt)}</span>`
      ).join("");
      const photoHtml = v.foto_perfil
        ? `<div class="attach-thumb" style="width:50px;height:50px;flex-shrink:0;"><img src="${esc(rawUrl(v.foto_perfil))}" alt="" onerror="__imgRetry(this)" onload="__imgLoaded(this)"></div>`
        : `<div class="attach-thumb" style="width:50px;height:50px;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:20px;">🚗</div>`;
      return `
      <div class="vlist-item" data-id="${v.id}" style="display:block;">
        <div style="display:flex;gap:10px;align-items:center;">
          ${photoHtml}
          <div style="flex:1;min-width:0;">
            <div class="vlist-item-title">${v.marca || ""} ${v.modelo || ""} — ${v.placas || t("sin_placa_texto")}${v.numero_unidad ? " — " + esc(t("unidad_prefix")) + " " + esc(v.numero_unidad) : ""}</div>
            <div class="vlist-item-sub">ID: ${v.id} ${v.cliente_nombre ? "· " + v.cliente_nombre : ""} · ${(v.servicios || []).length} ${esc(t("en_historial"))}</div>
          </div>
        </div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:9px;">${badge}${pagoBadge}${pendientesHtml}</div>
      </div>
    `;
    }).join("");

    list.querySelectorAll(".vlist-item").forEach((el) => {
      el.addEventListener("click", () => openEditor(el.dataset.id));
    });
  }

  /* ---------------- Tablero por etapa (gráficas de pastel) ---------------- */

  // Genera el degradado cónico (CSS) para una gráfica de pastel/dona a partir
  // de segmentos [{label, value, color}].
  function pieGradient(segments, total) {
    total = total || segments.reduce((s, x) => s + x.value, 0);
    if (!total) return `var(--surface-alt) 0deg 360deg`;
    let acc = 0;
    return segments.map((seg) => {
      const start = (acc / total) * 360;
      acc += seg.value;
      const end = (acc / total) * 360;
      return `${seg.color} ${start}deg ${end}deg`;
    }).join(", ");
  }

  function renderPieCard({ title, icon, segments, holdPct, centerLabel, centerSub, vehiculos, emptyMsg, renderVehicleRow, formatValue }) {
    const total = segments.reduce((s, x) => s + x.value, 0);
    const pct = holdPct != null ? holdPct : (total ? Math.round((segments[0].value / total) * 100) : 0);
    const gradient = pieGradient(segments, total);
    const fmt = formatValue || ((v) => String(v));
    const legendHtml = segments.map((seg) => {
      const segPct = total ? Math.round((seg.value / total) * 100) : 0;
      return `<div class="pie-legend-item"><span class="pie-dot" style="background:${seg.color}"></span>${esc(seg.label)}: <strong>${esc(fmt(seg.value))}</strong> (${segPct}%)</div>`;
    }).join("");

    const listHtml = vehiculos.length
      ? vehiculos.map(renderVehicleRow).join("")
      : `<p style="color:var(--text-faint);font-size:12px;margin:8px 0 0;">${esc(emptyMsg || t("msg_sin_vehiculos_aqui"))}</p>`;

    return `
      <div class="card pie-card">
        <div class="card-title">${icon} ${esc(title)}</div>
        <div class="pie-chart" style="background: conic-gradient(${gradient});">
          <div class="pie-chart-hole">
            <span class="pie-chart-total">${centerLabel != null ? esc(centerLabel) : pct + "%"}</span>
            ${centerSub ? `<span class="pie-chart-sub">${esc(centerSub)}</span>` : ""}
          </div>
        </div>
        <div class="pie-legend">${legendHtml}</div>
        <details class="pie-dropdown">
          <summary>${esc(t("ver_vehiculos_txt"))} (${vehiculos.length})</summary>
          <div class="pie-dropdown-list">${listHtml}</div>
        </details>
      </div>`;
  }

  function vehicleRowBasic(v) {
    return `<div class="vlist-item" data-id="${v.id}" style="margin-bottom:6px;">
      <div>
        <div class="vlist-item-title">${esc((v.marca || "") + " " + (v.modelo || ""))}</div>
        <div class="vlist-item-sub">${esc(v.placas || t("sin_placa_texto"))}${v.numero_unidad ? " · " + esc(t("unidad_prefix")) + " " + esc(v.numero_unidad) : ""}${v.cliente_nombre ? " · " + esc(v.cliente_nombre) : ""}</div>
      </div>
    </div>`;
  }

  // Junta el servicio activo (si lo hay) y todo el historial de cada vehículo en
  // una sola lista plana, para poder calcular totales del mes sin importar si el
  // servicio ya se finalizó o sigue en proceso.
  function collectAllServicios(entries) {
    const out = [];
    entries.forEach((v) => {
      if (v.servicio_actual) out.push({ ...v.servicio_actual, fecha: v.servicio_actual.fecha_inicio, vehicle: v });
      (v.servicios || []).forEach((s) => out.push({ ...s, vehicle: v }));
    });
    return out;
  }

  function servicioRowForBoard(s) {
    const v = s.vehicle;
    const montoEfectivo = efectiveCosto(s);
    const monto = montoEfectivo ? `$${montoEfectivo.toLocaleString("es-MX")}` : "";
    return `<div class="vlist-item" data-id="${v.id}" style="margin-bottom:6px;">
      <div>
        <div class="vlist-item-title">${esc((v.marca || "") + " " + (v.modelo || ""))}${s.folio ? ` · ${esc(t("folio_label"))} ${esc(s.folio)}` : ""}</div>
        <div class="vlist-item-sub">${esc(s.tipo || t("servicio_generico"))} · ${esc(s.fecha || "")}${monto ? " · " + monto : ""}</div>
      </div>
    </div>`;
  }

  function renderBoard() {
    const board = $("board");
    const entries = Object.values(db.vehicles || {});
    const activos = entries.filter((v) => v.servicio_actual);
    const sinActivo = entries.filter((v) => !v.servicio_actual);
    const totalActivos = activos.length;

    const porEtapa = { recibido: [], diagnostico: [], en_proceso: [], listo: [], recogido: [] };
    activos.forEach((v) => {
      const e = v.servicio_actual.estado;
      if (porEtapa[e]) porEtapa[e].push(v);
    });

    const GREEN = "var(--green)";
    const GREEN_BRIGHT = "var(--green-bright)";
    const AMARILLO = "var(--yellow)";
    const AZUL = "var(--blue)";
    const GRIS = "var(--text-faint)";
    const GRIS_CLARO = "rgba(255,255,255,0.14)";

    const cards = [];

    cards.push(renderPieCard({
      title: t("estado_recibido"), icon: "📥",
      segments: [
        { label: t("board_en_esta_etapa"), value: porEtapa.recibido.length, color: GREEN },
        { label: t("board_otras_etapas_activas"), value: totalActivos - porEtapa.recibido.length, color: GRIS },
      ],
      vehiculos: porEtapa.recibido,
      emptyMsg: t("board_ningun_recibido"),
      renderVehicleRow: vehicleRowBasic,
    }));

    cards.push(renderPieCard({
      title: t("estado_diagnostico"), icon: "🔍",
      segments: [
        { label: t("board_en_esta_etapa"), value: porEtapa.diagnostico.length, color: GREEN },
        { label: t("board_otras_etapas_activas"), value: totalActivos - porEtapa.diagnostico.length, color: GRIS },
      ],
      vehiculos: porEtapa.diagnostico,
      emptyMsg: t("board_ningun_diagnostico"),
      renderVehicleRow: vehicleRowBasic,
    }));

    cards.push(renderPieCard({
      title: t("estado_en_proceso"), icon: "🔧",
      segments: [
        { label: t("board_en_esta_etapa"), value: porEtapa.en_proceso.length, color: GREEN },
        { label: t("board_otras_etapas_activas"), value: totalActivos - porEtapa.en_proceso.length, color: GRIS },
      ],
      vehiculos: porEtapa.en_proceso,
      emptyMsg: t("board_ningun_en_proceso"),
      renderVehicleRow: vehicleRowBasic,
    }));

    const listoGrupo = [...porEtapa.listo, ...porEtapa.recogido];
    cards.push(renderPieCard({
      title: t("estado_listo"), icon: "✅",
      segments: [
        { label: t("board_ya_entregado"), value: porEtapa.recogido.length, color: GREEN_BRIGHT },
        { label: t("board_aun_no_entrega"), value: porEtapa.listo.length, color: GREEN },
        { label: t("board_otras_etapas"), value: totalActivos - listoGrupo.length, color: GRIS },
      ],
      holdPct: totalActivos ? Math.round((listoGrupo.length / totalActivos) * 100) : 0,
      vehiculos: listoGrupo,
      emptyMsg: t("board_ningun_listo"),
      renderVehicleRow: (v) => {
        const recogido = v.servicio_actual.estado === "recogido";
        return `<div class="vlist-item" data-id="${v.id}" style="margin-bottom:6px;">
          <div>
            <div class="vlist-item-title">${esc((v.marca || "") + " " + (v.modelo || ""))}</div>
            <div class="vlist-item-sub">${esc(v.placas || t("sin_placa_texto"))}${v.numero_unidad ? " · " + esc(t("unidad_prefix")) + " " + esc(v.numero_unidad) : ""}${v.cliente_nombre ? " · " + esc(v.cliente_nombre) : ""}</div>
          </div>
          <span class="tag">${recogido ? t("board_ya_entregado") : t("board_aun_no_entrega")}</span>
        </div>`;
      },
    }));

    cards.push(renderPieCard({
      title: t("sin_servicio_activo"), icon: "🏁",
      segments: [
        { label: t("sin_servicio_activo"), value: sinActivo.length, color: GREEN },
        { label: t("board_con_servicio_activo"), value: activos.length, color: GRIS },
      ],
      vehiculos: sinActivo,
      emptyMsg: t("board_todos_tienen_activo"),
      renderVehicleRow: vehicleRowBasic,
    }));

    // Servicios del mes e ingresos cobrados del mes (activos + historial juntos)
    const mesActual = todayISO().slice(0, 7);
    const todosServicios = collectAllServicios(entries);
    const serviciosMes = todosServicios.filter((s) => s.fecha && s.fecha.startsWith(mesActual));
    const mesPagados = serviciosMes.filter((s) => s.pago && s.pago.estado === "pagado");
    const mesADeber = serviciosMes.filter((s) => s.pago && s.pago.estado === "a_deber");
    const mesNoPagados = serviciosMes.filter((s) => !s.pago || s.pago.estado === "no_pagado");

    cards.push(renderPieCard({
      title: t("board_servicios_mes_titulo"), icon: "📈",
      segments: [
        { label: t("pago_pagado"), value: mesPagados.length, color: GREEN_BRIGHT },
        { label: t("pago_a_deber"), value: mesADeber.length, color: AMARILLO },
        { label: t("pago_no_pagado"), value: mesNoPagados.length, color: AZUL },
      ],
      centerLabel: String(serviciosMes.length),
      centerSub: t("board_servicios_mes_sub"),
      vehiculos: serviciosMes,
      emptyMsg: t("board_sin_servicios_mes"),
      renderVehicleRow: servicioRowForBoard,
    }));

    const cobradoEfectivo = mesPagados.filter((s) => s.pago.metodo === "efectivo").reduce((sum, s) => sum + efectiveCosto(s), 0);
    const cobradoTransferencia = mesPagados.filter((s) => s.pago.metodo === "transferencia").reduce((sum, s) => sum + efectiveCosto(s), 0);
    const cobradoSinMetodo = mesPagados.filter((s) => !s.pago.metodo).reduce((sum, s) => sum + efectiveCosto(s), 0);
    const totalCobradoMes = cobradoEfectivo + cobradoTransferencia + cobradoSinMetodo;

    cards.push(renderPieCard({
      title: t("board_ingresos_mes_titulo"), icon: "💰",
      segments: [
        { label: t("metodo_efectivo"), value: cobradoEfectivo, color: GREEN_BRIGHT },
        { label: t("metodo_transferencia"), value: cobradoTransferencia, color: AZUL },
        { label: t("sin_especificar"), value: cobradoSinMetodo, color: GRIS },
      ],
      centerLabel: `$${totalCobradoMes.toLocaleString("es-MX")}`,
      centerSub: t("board_ingresos_mes_sub"),
      vehiculos: mesPagados,
      emptyMsg: t("board_sin_ingresos_mes"),
      renderVehicleRow: servicioRowForBoard,
      formatValue: (v) => `$${Number(v).toLocaleString("es-MX")}`,
    }));

    // Resumen numérico rápido, antes de las gráficas — para el trabajo del
    // día a día, "3 recibidos, 2 en diagnóstico..." dice más rápido que leer
    // porcentajes en una dona.
    const pendienteCobro = activos
      .filter((v) => v.servicio_actual.pago && v.servicio_actual.pago.estado !== "pagado")
      .reduce((sum, v) => sum + Math.max(0, efectiveCosto(v.servicio_actual) - (Number(v.servicio_actual.pago.monto_pagado) || 0)), 0);
    const resumenItems = [
      { n: porEtapa.recibido.length, label: t("resumen_recibidos") },
      { n: porEtapa.diagnostico.length, label: t("resumen_diagnostico") },
      { n: porEtapa.en_proceso.length, label: t("resumen_en_proceso") },
      { n: porEtapa.listo.length, label: t("resumen_listos") },
    ];
    const resumenHtml = `
      <div class="card" style="display:flex;flex-wrap:wrap;gap:14px;justify-content:space-between;">
        ${resumenItems.map((it) => `
          <div style="text-align:center;flex:1;min-width:64px;">
            <div style="font-size:22px;font-weight:800;color:var(--green-bright);">${it.n}</div>
            <div style="font-size:10.5px;color:var(--text-faint);">${esc(it.label)}</div>
          </div>`).join("")}
        ${pendienteCobro > 0 ? `
          <div style="text-align:center;flex:1;min-width:110px;">
            <div style="font-size:20px;font-weight:800;color:var(--yellow);">$${pendienteCobro.toLocaleString("es-MX")}</div>
            <div style="font-size:10.5px;color:var(--text-faint);">${esc(t("resumen_pendiente_cobro"))}</div>
          </div>` : ""}
      </div>`;

    board.innerHTML = resumenHtml + cards.join("");

    board.querySelectorAll(".vlist-item[data-id]").forEach((el) => {
      el.addEventListener("click", () => openEditor(el.dataset.id));
    });
  }

  /* ---------------- Botones de contacto rápido (llamar / WhatsApp) ---------------- */

  function updateClientContactLinks() {
    const telRaw = ($("f-cliente-tel").value || "").trim();
    const nombre = $("f-cliente-nombre").value.trim();
    const placas = $("f-placas").value.trim();
    let digits = telRaw.replace(/\D/g, "");

    const callBtn = $("btn-call-client");
    const waBtn = $("btn-whatsapp-client");

    if (!digits) {
      callBtn.href = "tel:";
      waBtn.href = "https://wa.me/";
      callBtn.setAttribute("aria-disabled", "true");
      waBtn.setAttribute("aria-disabled", "true");
      return;
    }
    callBtn.removeAttribute("aria-disabled");
    waBtn.removeAttribute("aria-disabled");

    callBtn.href = "tel:" + digits;

    let waDigits = digits;
    if (waDigits.length === 10) waDigits = "52" + waDigits;
    const tallerNombre = (db && db.taller && db.taller.nombre) || "el taller";
    const msg = `Hola ${nombre || ""}, te contactamos de ${tallerNombre} sobre tu vehículo${placas ? " (placas " + placas + ")" : ""}.`
      .replace(/\s+/g, " ").trim();
    waBtn.href = `https://wa.me/${waDigits}?text=${encodeURIComponent(msg)}`;
  }

  $("f-cliente-tel").addEventListener("input", updateClientContactLinks);
  $("f-cliente-nombre").addEventListener("input", updateClientContactLinks);
  $("f-placas").addEventListener("input", updateClientContactLinks);

  /* ---------------- Mensaje de WhatsApp al marcar "listo para recoger" ---------------- */

  function buildWhatsAppListoLink({ nombre, telefono, marca, modelo, placas, numero_unidad, costo }) {
    let phone = (telefono || "").replace(/\D/g, "");
    if (!phone) return null;
    if (phone.length === 10) phone = "52" + phone;
    const tallerNombre = (db && db.taller && db.taller.nombre) || "el taller";
    const costoTxt = costo ? `$${Number(costo).toLocaleString("es-MX", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : "un monto por confirmar";
    const unidadTxt = numero_unidad ? ` (Unidad ${numero_unidad})` : "";
    const msg = `Hola ${nombre || ""}, tu vehículo ${marca || ""} ${modelo || ""} (placas ${placas || "N/A"})${unidadTxt} ya está listo para recoger en ${tallerNombre}. El total a pagar es ${costoTxt}. Te esperamos!`
      .replace(/\s+/g, " ").trim();
    return `https://wa.me/${phone}?text=${encodeURIComponent(msg)}`;
  }

  // Muestra un enlace REAL de WhatsApp para que el usuario lo toque directamente.
  // (window.open()/confirm() se bloquean en muchos navegadores móviles si no
  // hay un clic directo del usuario justo antes; un <a href> siempre funciona.)
  function showWhatsAppPrompt(nombre, links, titulo) {
    closeWhatsAppPrompt();
    const overlay = document.createElement("div");
    overlay.id = "wa-prompt-overlay";
    overlay.className = "wa-prompt-overlay";
    const validLinks = (links || []).filter((l) => l && l.href);
    const buttonsHtml = validLinks.length
      ? validLinks.map((l) => `<a class="btn wa-prompt-link" href="${l.href}" rel="noopener">${esc(t("enviar_whatsapp_btn"))}${validLinks.length > 1 ? " · " + esc(l.label) : ""}</a>`).join("")
      : `<span style="color:var(--text-faint);font-size:12.5px;">${esc(t("wa_sin_telefono"))}</span>`;
    overlay.innerHTML = `
      <div class="card wa-prompt-card">
        <div class="card-title">${esc(titulo || t("wa_prompt_titulo"))}</div>
        <p style="font-size:13.5px;color:var(--text-dim);margin:0 0 16px;">${esc(t("wa_prompt_pre"))} <strong style="color:var(--text);">${esc(nombre || t("cliente_label"))}</strong> ${esc(t("wa_prompt_post"))}</p>
        <div class="actions-row" style="flex-wrap:wrap;">
          ${buttonsHtml}
          <button class="btn btn-outline" id="wa-prompt-dismiss">${esc(t("cerrar_btn"))}</button>
        </div>
      </div>`;
    document.body.appendChild(overlay);
    $("wa-prompt-dismiss").addEventListener("click", closeWhatsAppPrompt);
    if (validLinks.length === 1) {
      // Con un solo teléfono, se cierra solo tras enviarlo (como antes).
      overlay.querySelectorAll(".wa-prompt-link").forEach((el) => el.addEventListener("click", () => setTimeout(closeWhatsAppPrompt, 250)));
    }
    // Con dos teléfonos, se queda abierto para poder enviarle a ambos — se cierra
    // solo con el botón "Cerrar".
    overlay.addEventListener("click", (e) => { if (e.target === overlay) closeWhatsAppPrompt(); });
  }

  function closeOrphanFinder() {
    const el = document.getElementById("orphan-finder-overlay");
    if (el) el.remove();
  }

  function renderOrphanFinderModal(orphans) {
    closeOrphanFinder();
    const overlay = document.createElement("div");
    overlay.id = "orphan-finder-overlay";
    overlay.className = "wa-prompt-overlay";
    const cuerpoHtml = orphans.length
      ? `
        <div class="actions-row" style="margin-bottom:10px;">
          <button class="btn btn-outline btn-sm" id="orphan-select-all">${esc(t("orphan_seleccionar_todos"))}</button>
        </div>
        <div style="max-height:340px;overflow-y:auto;border-radius:10px;background:rgba(255,255,255,0.03);padding:6px 10px;margin-bottom:14px;">
          ${orphans.map((p, i) => `
            <label style="display:flex;align-items:center;gap:8px;padding:7px 2px;border-bottom:1px solid rgba(255,255,255,0.05);font-size:12px;">
              <input type="checkbox" class="orphan-checkbox" data-path="${esc(p)}">
              <span style="word-break:break-all;color:var(--text-dim);">${esc(p)}</span>
            </label>`).join("")}
        </div>
        <div class="actions-row">
          <button class="btn btn-danger btn-sm" id="orphan-delete-selected">${esc(t("orphan_borrar_seleccionados"))}</button>
          <button class="btn btn-outline btn-sm" id="orphan-finder-dismiss">${esc(t("cerrar_btn"))}</button>
        </div>`
      : `
        <p style="color:var(--text-dim);font-size:13px;">${esc(t("orphan_ninguno"))}</p>
        <div class="actions-row"><button class="btn btn-outline btn-sm" id="orphan-finder-dismiss">${esc(t("cerrar_btn"))}</button></div>`;
    overlay.innerHTML = `
      <div class="card wa-prompt-card" style="max-width:480px;">
        <div class="card-title">${esc(t("orphan_titulo"))} ${orphans.length ? `(${orphans.length})` : ""}</div>
        <p style="font-size:12px;color:var(--text-faint);margin:0 0 12px;">${esc(t("orphan_desc"))}</p>
        ${cuerpoHtml}
      </div>`;
    document.body.appendChild(overlay);
    $("orphan-finder-dismiss") && $("orphan-finder-dismiss").addEventListener("click", closeOrphanFinder);
    overlay.addEventListener("click", (e) => { if (e.target === overlay) closeOrphanFinder(); });
    if (orphans.length) {
      $("orphan-select-all").addEventListener("click", () => {
        overlay.querySelectorAll(".orphan-checkbox").forEach((cb) => { cb.checked = true; });
      });
      $("orphan-delete-selected").addEventListener("click", async () => {
        const seleccionados = Array.from(overlay.querySelectorAll(".orphan-checkbox:checked")).map((cb) => cb.dataset.path);
        if (!seleccionados.length) { showToast(t("orphan_ninguno_seleccionado"), "error"); return; }
        if (!confirm(t("orphan_confirmar_borrado").replace("{n}", seleccionados.length))) return;
        const btn = $("orphan-delete-selected");
        btn.disabled = true;
        btn.textContent = t("guardando_btn");
        let borrados = 0;
        for (const path of seleccionados) {
          try { await deleteFileFromRepo(path); borrados++; } catch (err) { /* seguimos con los demás */ }
        }
        showToast(t("orphan_borrados_ok").replace("{n}", borrados), "success");
        const restantes = orphans.filter((p) => !seleccionados.includes(p));
        renderOrphanFinderModal(restantes);
      });
    }
  }

  async function onBuscarHuerfanosClick() {
    const btn = $("btn-buscar-huerfanos");
    const originalLabel = btn.textContent;
    btn.disabled = true;
    btn.textContent = t("orphan_buscando");
    try {
      const orphans = await findOrphanedFiles();
      renderOrphanFinderModal(orphans);
    } catch (err) {
      showToast(t("msg_error_guardar") + err.message, "error");
    } finally {
      btn.disabled = false;
      btn.textContent = originalLabel;
    }
  }

  function closeWhatsAppPrompt() {
    const el = document.getElementById("wa-prompt-overlay");
    if (el) el.remove();
  }

  function offerWhatsAppListo(datos) {
    const links = [
      { href: buildWhatsAppListoLink({ ...datos, telefono: datos.telefono }), label: "Tel. 1" },
      { href: datos.telefono2 ? buildWhatsAppListoLink({ ...datos, telefono: datos.telefono2 }) : null, label: "Tel. 2" },
    ];
    showWhatsAppPrompt(datos.nombre, links);
  }

  const TRACK_BASE_URL = "https://blaze151.github.io/taller-bassoco/";

  function buildWhatsAppOrdenLink({ nombre, telefono, marca, modelo, placas, numero_unidad, id, pdfUrl }) {
    let phone = (telefono || "").replace(/\D/g, "");
    if (!phone) return null;
    if (phone.length === 10) phone = "52" + phone;
    const trackUrl = id ? `${TRACK_BASE_URL}?v=${encodeURIComponent(id)}` : TRACK_BASE_URL;
    const unidadTxt = numero_unidad ? ` (Unidad ${numero_unidad})` : "";
    const msg = t("msg_orden_wa")
      .replace("{nombre}", nombre || "")
      .replace("{marca}", marca || "")
      .replace("{modelo}", modelo || "")
      .replace("{placas}", placas || "N/A")
      .replace("{unidad}", unidadTxt)
      .replace("{pdf}", pdfUrl || "")
      .replace("{link}", trackUrl)
      .replace(/\s+/g, " ").trim();
    return `https://wa.me/${phone}?text=${encodeURIComponent(msg)}`;
  }

  function offerWhatsAppOrden(datos) {
    const links = [
      { href: buildWhatsAppOrdenLink({ ...datos, telefono: datos.telefono }), label: "Tel. 1" },
      { href: datos.telefono2 ? buildWhatsAppOrdenLink({ ...datos, telefono: datos.telefono2 }) : null, label: "Tel. 2" },
    ];
    showWhatsAppPrompt(datos.nombre, links, t("wa_prompt_titulo_orden"));
  }

  function buildWhatsAppCotizacionLink({ nombre, telefono, marca, modelo, placas, numero_unidad, id, pdfUrl }) {
    let phone = (telefono || "").replace(/\D/g, "");
    if (!phone) return null;
    if (phone.length === 10) phone = "52" + phone;
    const unidadTxt = numero_unidad ? ` (Unidad ${numero_unidad})` : "";
    const msg = t("msg_cotizacion_wa")
      .replace("{nombre}", nombre || "")
      .replace("{marca}", marca || "")
      .replace("{modelo}", modelo || "")
      .replace("{placas}", placas || "N/A")
      .replace("{unidad}", unidadTxt)
      .replace("{pdf}", pdfUrl || "")
      .replace(/\s+/g, " ").trim();
    return `https://wa.me/${phone}?text=${encodeURIComponent(msg)}`;
  }

  function offerWhatsAppCotizacion(datos) {
    const links = [
      { href: buildWhatsAppCotizacionLink({ ...datos, telefono: datos.telefono }), label: "Tel. 1" },
      { href: datos.telefono2 ? buildWhatsAppCotizacionLink({ ...datos, telefono: datos.telefono2 }) : null, label: "Tel. 2" },
    ];
    showWhatsAppPrompt(datos.nombre, links, t("wa_prompt_titulo_cotizacion"));
  }

  function buildWhatsAppInformeTrabajoLink({ nombre, telefono, marca, modelo, placas, numero_unidad, pdfUrl }) {
    let phone = (telefono || "").replace(/\D/g, "");
    if (!phone) return null;
    if (phone.length === 10) phone = "52" + phone;
    const unidadTxt = numero_unidad ? ` (Unidad ${numero_unidad})` : "";
    const msg = t("msg_informe_trabajo_wa")
      .replace("{nombre}", nombre || "")
      .replace("{marca}", marca || "")
      .replace("{modelo}", modelo || "")
      .replace("{placas}", placas || "N/A")
      .replace("{unidad}", unidadTxt)
      .replace("{pdf}", pdfUrl || "")
      .replace("{agradecimiento}", tallerInfoForPdf().agradecimiento)
      .replace(/\s+/g, " ").trim();
    return `https://wa.me/${phone}?text=${encodeURIComponent(msg)}`;
  }

  function offerWhatsAppInformeTrabajo(datos) {
    const links = [
      { href: buildWhatsAppInformeTrabajoLink({ ...datos, telefono: datos.telefono }), label: "Tel. 1" },
      { href: datos.telefono2 ? buildWhatsAppInformeTrabajoLink({ ...datos, telefono: datos.telefono2 }) : null, label: "Tel. 2" },
    ];
    showWhatsAppPrompt(datos.nombre, links, t("wa_prompt_titulo_informe_trabajo"));
  }

  function buildHistoricalEntryFromActive(active, pending) {
    pending = pending || emptyPendingStruct();
    return {
      fecha: todayISO(),
      folio: active.folio,
      tipo: active.tipo,
      descripcion: active.descripcion,
      nota_interna: active.nota_interna,
      km: active.km,
      costo: active.costo,
      tecnico: active.tecnico,
      tiempo_entrega_aprox: active.tiempo_entrega_aprox,
      fecha_inicio: active.fecha_inicio,
      pago: active.pago ? { estado: active.pago.estado, metodo: active.pago.metodo } : null,
      orden_recepcion: active.orden_recepcion ? JSON.parse(JSON.stringify(active.orden_recepcion)) : null,
      cotizacion: active.cotizacion ? JSON.parse(JSON.stringify(active.cotizacion)) : null,
      informe_trabajo: active.informe_trabajo ? JSON.parse(JSON.stringify(active.informe_trabajo)) : null,
      fechas_etapa: active.fechas_etapa ? JSON.parse(JSON.stringify(active.fechas_etapa)) : null,
      adjuntos: JSON.parse(JSON.stringify(active.adjuntos || emptyPendingStruct())),
      _pendingAdjuntos: pending,
    };
  }

  /* ---------------- Editor de vehículo ---------------- */

  function clearEditorForm() {
    ["f-id", "f-placas", "f-numero-unidad", "f-marca", "f-modelo", "f-anio", "f-version", "f-color", "f-combustible",
     "f-vin", "f-km", "f-cliente-nombre", "f-cliente-tel", "f-cliente-tel-2", "f-cliente-correo", "f-cliente-rfc", "f-cliente-direccion", "f-aceite-tipo", "f-aceite-cap",
     "f-llantas", "f-bateria", "f-filtro-aire", "f-filtro-aceite"
    ].forEach((id) => { $(id).value = ""; });
  }

  // Directorio simple de clientes: junta nombre/teléfono ya capturados en otros
  // vehículos, para sugerirlos como autocompletar al dar de alta uno nuevo.
  function buildClientDirectory() {
    const byNombre = new Map();
    const byTel = new Map();
    Object.values(db.vehicles || {}).forEach((v) => {
      const nombre = (v.cliente_nombre || "").trim();
      const tel = (v.cliente_telefono || "").trim();
      if (nombre && !byNombre.has(nombre)) byNombre.set(nombre, tel);
      if (tel && !byTel.has(tel)) byTel.set(tel, nombre);
    });
    return { byNombre, byTel };
  }

  function renderClientDatalists() {
    const dir = buildClientDirectory();
    const dlNombre = $("clientes-nombres");
    const dlTel = $("clientes-telefonos");
    if (dlNombre) dlNombre.innerHTML = Array.from(dir.byNombre.keys()).map((n) => `<option value="${esc(n)}"></option>`).join("");
    if (dlTel) dlTel.innerHTML = Array.from(dir.byTel.keys()).map((tel) => `<option value="${esc(tel)}"></option>`).join("");
  }

  // Junta los nombres de técnico ya usados antes (servicio activo e
  // historial, de todos los vehículos) para sugerirlos al escribir — evita
  // que "Sergio", "Ing. Sergio" y "sergio" terminen siendo 3 técnicos
  // distintos en las estadísticas por simples variantes de escritura.
  function renderTecnicosDatalist() {
    const dl = $("tecnicos-list");
    if (!dl) return;
    const nombres = new Set();
    Object.values(db.vehicles || {}).forEach((v) => {
      if (v.servicio_actual && v.servicio_actual.tecnico) nombres.add(v.servicio_actual.tecnico.trim());
      (v.servicios || []).forEach((s) => { if (s.tecnico) nombres.add(s.tecnico.trim()); });
    });
    dl.innerHTML = Array.from(nombres).filter(Boolean).sort().map((n) => `<option value="${esc(n)}"></option>`).join("");
  }

  function wireClientAutocomplete() {
    const nombreEl = $("f-cliente-nombre");
    const telEl = $("f-cliente-tel");
    if (!nombreEl || !telEl) return;
    nombreEl.addEventListener("input", () => {
      const match = buildClientDirectory().byNombre.get(nombreEl.value.trim());
      if (match && !telEl.value.trim()) telEl.value = match;
    });
    telEl.addEventListener("input", () => {
      const match = buildClientDirectory().byTel.get(telEl.value.trim());
      if (match && !nombreEl.value.trim()) nombreEl.value = match;
    });
  }

  async function openEditor(id) {
    isNewVehicle = !id;
    currentVehicleId = id || null;

    // Si hay un borrador local (algo que quedó sin guardar, de este
    // vehículo o de una alta nueva), se ofrece qué hacer con él antes de
    // cargar la versión de GitHub.
    let vehicleOverride = null;
    let borradorRecuperado = false;
    const draft = leerBorradorLocal(id);
    if (draft && draft.vehicle) {
      const fechaBorrador = new Date(draft.savedAt).toLocaleString("es-MX", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
      const decision = await preguntarQueHacerConBorrador(fechaBorrador);
      if (decision === "recuperar") {
        vehicleOverride = draft.vehicle;
        borradorRecuperado = true;
        borrarBorradorLocal(id);
      } else if (decision === "descartar") {
        borrarBorradorLocal(id);
      }
      // "mantener": no se toca el borrador, se sigue de largo con los datos normales
    }

    toolPanelOpen = {};
    // Si se había quitado una foto/documento en OTRO vehículo y no se guardó,
    // ese borrado pendiente no debe arrastrarse a este vehículo distinto —
    // si no, al guardar aquí se borraría un archivo que nunca se confirmó.
    pendingDeletePaths = [];
    // Si se acaba de recuperar un borrador, sigue habiendo cambios sin
    // guardar de verdad (solo está en memoria, no en GitHub) — no hay que
    // dar a entender que ya quedó guardado.
    hasUnsavedChanges = borradorRecuperado;
    lastSavedAt = null;
    updateUnsavedIndicator();
    clearEditorForm();
    renderClientDatalists();
    renderTecnicosDatalist();

    const v = vehicleOverride || (id ? db.vehicles[id] : {});
    const ficha = (v && v.ficha_tecnica) || {};

    // Para un vehículo nuevo se sugiere un ID aleatorio (no consecutivo/fácil
    // de adivinar como X1, X2...) — el admin puede escribir el que quiera
    // encima, esto es solo para que lo normal sea uno difícil de adivinar.
    $("f-id").value = v.id || "";
    $("f-id").disabled = !isNewVehicle; // no permitir cambiar el ID de un vehículo existente
    $("f-placas").value = v.placas || "";
    $("f-numero-unidad").value = v.numero_unidad || "";
    $("f-marca").value = v.marca || "";
    $("f-modelo").value = v.modelo || "";
    $("f-anio").value = v.anio || "";
    $("f-version").value = v.version || "";
    $("f-color").value = v.color || "";
    $("f-combustible").value = v.combustible || "";
    $("f-vin").value = v.vin || "";
    $("f-km").value = v.km_actual || "";
    $("f-cliente-nombre").value = v.cliente_nombre || "";
    $("f-cliente-tel").value = v.cliente_telefono || "";
    $("f-cliente-tel-2").value = v.cliente_telefono_2 || "";
    $("f-cliente-correo").value = v.cliente_correo || "";
    $("f-cliente-rfc").value = v.cliente_rfc || "";
    $("f-cliente-direccion").value = v.cliente_direccion || "";
    updateClientContactLinks();

    $("f-aceite-tipo").value = ficha.aceite_tipo || "";
    $("f-aceite-cap").value = ficha.aceite_capacidad || "";
    $("f-llantas").value = ficha.presion_llantas || "";
    $("f-bateria").value = ficha.bateria || "";
    $("f-filtro-aire").value = ficha.filtro_aire || "";
    $("f-filtro-aceite").value = ficha.filtro_aceite || "";

    pendingServices = (v && v.servicios) ? v.servicios.slice() : [];
    svcActual = (v && v.servicio_actual) ? JSON.parse(JSON.stringify(v.servicio_actual)) : null;
    if (svcActual) {
      if (!svcActual.pago) svcActual.pago = { estado: "no_pagado", metodo: null };
      if (!svcActual.adjuntos) svcActual.adjuntos = emptyPendingStruct();
      if (!svcActual.adjuntos.pago) svcActual.adjuntos.pago = { fotos: [], documentos: [] };
      if (!svcActual.adjuntos.recogido) svcActual.adjuntos.recogido = { fotos: [], documentos: [] };
    }
    svcActualEstadoOriginal = svcActual ? svcActual.estado : null;
    svcActualPending = emptyPendingStruct();

    // Si el vehículo ya trae datos en la Hoja de recepción o la Cotización,
    // el panel se abre solo — así nunca da la impresión de que se perdieron.
    if (svcActual) {
      const or = svcActual.orden_recepcion;
      const orInv = or && or.inventario;
      const orHasData = or && (or.enviado || or.aceptado ||
        (orInv && Object.values(orInv.exteriores || {}).some((val) => val === "si")) ||
        (orInv && Object.values(orInv.accesorios || {}).some((val) => val === "si")) ||
        (orInv && (orInv.danos_notas || "").trim()));
      if (orHasData) toolPanelOpen.recibido = true;

      const cot = svcActual.cotizacion;
      const cotHasData = cot && (cot.enviado ||
        (cot.items || []).some((it) => (it.concepto || "").trim() || (Number(it.costo_unitario) || 0) > 0));
      if (cotHasData) toolPanelOpen.diagnostico = true;

      if (svcActual.informe_trabajo && svcActual.informe_trabajo.enviado) toolPanelOpen.recogido = true;
    }

    currentFotoPerfil = (v && v.foto_perfil) || null;
    vFotoPerfilPending = null;
    vFotoPerfilRemoved = false;
    currentDocumentosVehiculo = (v && v.documentos_vehiculo) ? JSON.parse(JSON.stringify(v.documentos_vehiculo)) : { fotos: [], documentos: [] };
    vDocsPending = { fotos: [], documentos: [] };

    renderServicesList();
    renderActiveServiceCard();
    renderVehiclePhotoPreview();
    renderVehicleDocsPreview();

    $("btn-delete").style.display = isNewVehicle ? "none" : "inline-flex";
    $("btn-copiar-enlace").style.display = isNewVehicle ? "none" : "inline-flex";
    showView("editor");
  }

  /* ---------------- Foto de perfil del vehículo ---------------- */

  function renderVehiclePhotoPreview() {
    const el = $("vehicle-photo-preview");
    if (vFotoPerfilPending) {
      const objUrl = URL.createObjectURL(vFotoPerfilPending);
      el.innerHTML = `<div class="vehicle-photo attach-thumb-remove" data-lightbox-group="${JSON.stringify([objUrl]).replace(/"/g, "&quot;")}" data-lightbox-index="0" style="width:110px;height:110px;"><img src="${objUrl}" alt=""><button type="button" id="btn-vphoto-remove" title="${esc(t('quitar_btn'))}">×</button></div>`;
    } else if (!vFotoPerfilRemoved && currentFotoPerfil) {
      el.innerHTML = `<div class="vehicle-photo attach-thumb-remove" data-lightbox-group="${JSON.stringify([rawUrl(currentFotoPerfil)]).replace(/"/g, "&quot;")}" data-lightbox-index="0" style="width:110px;height:110px;"><img src="${esc(rawUrl(currentFotoPerfil))}" alt="" onerror="__imgRetry(this)" onload="__imgLoaded(this)"><button type="button" id="btn-vphoto-remove" title="${esc(t('quitar_btn'))}">×</button></div>`;
    } else {
      el.innerHTML = `<div class="vehicle-photo" style="width:110px;height:110px;"><div class="vehicle-photo-placeholder">🚗</div></div>`;
    }
    const rmBtn = $("btn-vphoto-remove");
    if (rmBtn) {
      rmBtn.addEventListener("click", () => {
        vFotoPerfilPending = null;
        vFotoPerfilRemoved = true;
        renderVehiclePhotoPreview();
      });
    }
  }

  /* ---------------- Documentos generales del vehículo ---------------- */

  function renderVehicleDocsPreview() {
    const fotosEl = $("vdoc-fotos-preview");
    let fotosHtml = "";
    const vdocGroup = JSON.stringify(currentDocumentosVehiculo.fotos.map(rawUrl)).replace(/"/g, "&quot;");
    currentDocumentosVehiculo.fotos.forEach((path, i) => {
      fotosHtml += `<div class="attach-thumb attach-thumb-remove" data-lightbox-group="${vdocGroup}" data-lightbox-index="${i}"><img src="${esc(rawUrl(path))}" alt="" onerror="__imgRetry(this)" onload="__imgLoaded(this)"><button type="button" data-vdoc-remove-saved-foto="${i}" title="${esc(t('quitar_btn'))}">×</button></div>`;
    });
    vDocsPending.fotos.forEach((file, i) => {
      fotosHtml += `<div class="attach-thumb pending attach-thumb-remove"><img src="${URL.createObjectURL(file)}" alt=""><button type="button" data-vdoc-remove-pending-foto="${i}" title="${esc(t('quitar_btn'))}">×</button></div>`;
    });
    fotosEl.innerHTML = fotosHtml;

    const docsEl = $("vdoc-docs-preview");
    let docsHtml = "";
    currentDocumentosVehiculo.documentos.forEach((path, i) => {
      const name = decodeURIComponent(path.split("/").pop());
      docsHtml += `<span class="doc-chip">📄 ${esc(name)} <button type="button" class="doc-remove" data-vdoc-remove-saved-doc="${i}" title="${esc(t('quitar_btn'))}">×</button></span>`;
    });
    vDocsPending.documentos.forEach((file, i) => {
      docsHtml += `<span class="doc-chip pending">📄 ${esc(file.name)} <button type="button" class="doc-remove" data-vdoc-remove-pending-doc="${i}" title="${esc(t('quitar_btn'))}">×</button></span>`;
    });
    docsEl.innerHTML = docsHtml;

    fotosEl.querySelectorAll("[data-vdoc-remove-saved-foto]").forEach((b) => b.addEventListener("click", () => {
      const idx = Number(b.dataset.vdocRemoveSavedFoto);
      queueDelete(currentDocumentosVehiculo.fotos[idx]);
      currentDocumentosVehiculo.fotos.splice(idx, 1);
      renderVehicleDocsPreview();
    }));
    fotosEl.querySelectorAll("[data-vdoc-remove-pending-foto]").forEach((b) => b.addEventListener("click", () => {
      vDocsPending.fotos.splice(Number(b.dataset.vdocRemovePendingFoto), 1);
      renderVehicleDocsPreview();
    }));
    docsEl.querySelectorAll("[data-vdoc-remove-saved-doc]").forEach((b) => b.addEventListener("click", () => {
      const idx = Number(b.dataset.vdocRemoveSavedDoc);
      queueDelete(currentDocumentosVehiculo.documentos[idx]);
      currentDocumentosVehiculo.documentos.splice(idx, 1);
      renderVehicleDocsPreview();
    }));
    docsEl.querySelectorAll("[data-vdoc-remove-pending-doc]").forEach((b) => b.addEventListener("click", () => {
      vDocsPending.documentos.splice(Number(b.dataset.vdocRemovePendingDoc), 1);
      renderVehicleDocsPreview();
    }));
  }

  /* ---------------- Historial (solo lectura + quitar) ---------------- */

  function renderOrdenRecepcionResumenAdmin(or) {
    if (!or) return "";
    const inv = or.inventario || {};
    const faltantes = [];
    INVENTARIO_EXTERIORES.forEach(([k, lk]) => { if (inv.exteriores && inv.exteriores[k] === "no") faltantes.push(t(lk)); });
    INVENTARIO_ACCESORIOS.forEach(([k, lk]) => { if (inv.accesorios && inv.accesorios[k] === "no") faltantes.push(t(lk)); });
    const hayContenido = inv.gasolina != null || faltantes.length || inv.danos_notas || or.enviado;
    if (!hayContenido) return "";
    const estadoTxt = or.aceptado
      ? `${esc(t("orden_estado_aceptado"))} ${formatFechaCorta(or.fecha_aceptado)}`
      : or.enviado ? `${esc(t("orden_estado_pendiente"))} ${formatFechaCorta(or.fecha_envio)}` : "";
    return `
      <details class="card-details" style="margin-top:10px;">
        <summary class="card-title" style="font-size:11px;">${esc(t("orden_recepcion_titulo"))}</summary>
        <div class="card-details-body" style="font-size:11.5px;color:var(--text-dim);">
          ${estadoTxt ? `<div style="margin-bottom:6px;color:${or.aceptado ? "var(--green-bright)" : "var(--yellow)"};">${estadoTxt}</div>` : ""}
          ${inv.gasolina != null ? `<div style="margin-bottom:4px;">${esc(t("nivel_gasolina_label"))}: <strong>${inv.gasolina}%</strong></div>` : ""}
          ${faltantes.length ? `<div style="margin-bottom:4px;">${esc(t("orden_faltantes_label"))}: ${faltantes.map(esc).join(", ")}</div>` : ""}
          ${inv.danos_notas ? `<div>${esc(t("danos_notas_label"))}: ${esc(inv.danos_notas)}</div>` : ""}
          ${or.pdf_path ? `<div style="margin-top:6px;"><a href="${esc(rawUrl(or.pdf_path))}" target="_blank" rel="noopener">${esc(t("ver_pdf_enviado"))}</a></div>` : ""}
        </div>
      </details>`;
  }

  function renderHistoryAttachmentsDetail(s) {
    let stagesHtml = "";
    ATTACH_STAGES.forEach((stage) => {
      const saved = (s.adjuntos && s.adjuntos[stage]) || { fotos: [], documentos: [] };
      if (!saved.fotos.length && !saved.documentos.length) return;
      const info = ESTADOS_SERVICIO()[stage] || PAGO_INFO();
      const savedGroup = JSON.stringify(saved.fotos.map(rawUrl)).replace(/"/g, "&quot;");
      const fotosHtml = saved.fotos.map((path, i) => `<div class="attach-thumb" data-lightbox-group="${savedGroup}" data-lightbox-index="${i}"><img src="${esc(rawUrl(path))}" alt="" onerror="__imgRetry(this)" onload="__imgLoaded(this)"></div>`).join("");
      const docsHtml = saved.documentos.map((path) => {
        const name = decodeURIComponent(path.split("/").pop());
        return `<a class="doc-chip" href="${esc(rawUrl(path))}" target="_blank" rel="noopener">📄 ${esc(name)}</a>`;
      }).join("");
      stagesHtml += `
        <div style="margin-top:8px;">
          <div style="font-size:10.5px;color:var(--text-faint);text-transform:uppercase;letter-spacing:.05em;margin-bottom:4px;">${info.icon} ${info.label}</div>
          ${fotosHtml ? `<div class="attach-gallery">${fotosHtml}</div>` : ""}
          ${docsHtml}
        </div>`;
    });

    // Compatibilidad con registros antiguos guardados como galería única (sin etapas)
    let legacyHtml = "";
    if (!s.adjuntos && ((s.fotos && s.fotos.length) || (s.documentos && s.documentos.length))) {
      const legacyGroup = JSON.stringify((s.fotos || []).map(rawUrl)).replace(/"/g, "&quot;");
      const fotosHtml = (s.fotos || []).map((path, i) => `<div class="attach-thumb" data-lightbox-group="${legacyGroup}" data-lightbox-index="${i}"><img src="${esc(rawUrl(path))}" alt="" onerror="__imgRetry(this)" onload="__imgLoaded(this)"></div>`).join("");
      const docsHtml = (s.documentos || []).map((path) => {
        const name = decodeURIComponent(path.split("/").pop());
        return `<a class="doc-chip" href="${esc(rawUrl(path))}" target="_blank" rel="noopener">📄 ${esc(name)}</a>`;
      }).join("");
      legacyHtml = `${fotosHtml ? `<div class="attach-gallery">${fotosHtml}</div>` : ""}${docsHtml}`;
    }

    if (!stagesHtml && !legacyHtml) return "";
    return `<details style="margin-top:8px;"><summary style="cursor:pointer;font-size:11.5px;color:var(--text-dim);">${esc(t("ver_fotos_por_etapa"))}</summary>${stagesHtml}${legacyHtml}</details>`;
  }

  function renderServicesList() {
    const list = $("services-list");
    const sorted = pendingServices.slice().sort((a, b) => (a.fecha < b.fecha ? 1 : -1));
    if (!sorted.length) {
      list.innerHTML = `<p style="color:var(--text-faint);font-size:13px;">${esc(t("sin_servicios_finalizados"))}</p>`;
      return;
    }
    list.innerHTML = sorted.map((s, i) => {
      let nFotos = (s.fotos || []).length;
      let nDocs = (s.documentos || []).length;
      ATTACH_STAGES.forEach((stage) => {
        nFotos += ((s.adjuntos && s.adjuntos[stage] && s.adjuntos[stage].fotos) || []).length;
        nFotos += ((s._pendingAdjuntos && s._pendingAdjuntos[stage] && s._pendingAdjuntos[stage].fotos) || []).length;
        nDocs += ((s.adjuntos && s.adjuntos[stage] && s.adjuntos[stage].documentos) || []).length;
        nDocs += ((s._pendingAdjuntos && s._pendingAdjuntos[stage] && s._pendingAdjuntos[stage].documentos) || []).length;
      });
      const chips = [];
      if (nFotos) chips.push(`<span class="tag">📷 ${nFotos}</span>`);
      if (nDocs) chips.push(`<span class="tag">📄 ${nDocs}</span>`);
      const pagoInfo = s.pago ? PAGO_ESTADOS()[s.pago.estado] : null;
      const pagoEstadoOpts = ["no_pagado", "pagado", "a_deber"].map((k) => {
        const info = PAGO_ESTADOS()[k];
        return `<option value="${k}" ${s.pago && s.pago.estado === k ? "selected" : ""}>${info.icon} ${info.label}</option>`;
      }).join("");
      const metodoActual = s.pago && s.pago.metodo;
      const metodoOpts = `
        <option value="" ${!metodoActual ? "selected" : ""}>${esc(t("sin_especificar"))}</option>
        <option value="efectivo" ${metodoActual === "efectivo" ? "selected" : ""}>💵 ${esc(t("metodo_efectivo"))}</option>
        <option value="transferencia" ${metodoActual === "transferencia" ? "selected" : ""}>🏦 ${esc(t("metodo_transferencia"))}</option>
      `;
      return `
      <div class="vlist-item" style="cursor:default;display:block;">
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <div>
            <div class="vlist-item-title">${s.tipo || t("servicio_generico")} — ${s.fecha || ""}${s.folio ? ` <span style="color:var(--green-bright);font-weight:400;">· ${esc(t("folio_label"))} ${esc(s.folio)}</span>` : ""}</div>
            <div class="vlist-item-sub">${s.km ? s.km + " km · " : ""}${s.tecnico || ""}${efectiveCosto(s) ? " · $" + efectiveCosto(s).toLocaleString("es-MX") : ""} ${chips.join(" ")}</div>
          </div>
          <button class="btn btn-outline btn-sm" data-remove="${i}">${esc(t("quitar_btn"))}</button>
        </div>
        <div class="grid-2" style="margin-top:10px;">
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" style="font-size:10px;" data-i18n="estado_pago_label">Estado de pago</label>
            <select data-pago-estado-hist="${i}">${pagoEstadoOpts}</select>
          </div>
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" style="font-size:10px;" data-i18n="metodo_pago_label">Método de pago</label>
            <select data-pago-metodo-hist="${i}">${metodoOpts}</select>
          </div>
        </div>
        ${renderOrdenRecepcionResumenAdmin(s.orden_recepcion)}
        ${renderHistoryAttachmentsDetail(s)}
      </div>
    `;
    }).join("");

    list.querySelectorAll("[data-pago-estado-hist]").forEach((sel) => {
      sel.addEventListener("change", () => {
        const target = sorted[Number(sel.dataset.pagoEstadoHist)];
        if (!target.pago) target.pago = { estado: "no_pagado", metodo: null };
        target.pago.estado = sel.value;
      });
    });
    list.querySelectorAll("[data-pago-metodo-hist]").forEach((sel) => {
      sel.addEventListener("change", () => {
        const target = sorted[Number(sel.dataset.pagoMetodoHist)];
        if (!target.pago) target.pago = { estado: "no_pagado", metodo: null };
        target.pago.metodo = sel.value || null;
      });
    });
    list.querySelectorAll("[data-remove]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const sortedIdx = Number(btn.dataset.remove);
        const target = sorted[sortedIdx];
        collectServiceAttachmentPaths(target).forEach(queueDelete);
        pendingServices = pendingServices.filter((s) => s !== target);
        renderServicesList();
      });
    });
  }

  /* ---------------- Servicio en proceso ---------------- */

  function renderStageBlock(stage, infoOverride) {
    const info = infoOverride || ESTADOS_SERVICIO()[stage];
    const saved = (svcActual.adjuntos[stage]) || { fotos: [], documentos: [] };
    const pending = svcActualPending[stage];
    const prevDetails = document.getElementById(`stage-details-${stage}`);
    const wasOpen = prevDetails ? prevDetails.open : false;

    let fotosHtml = "";
    const activeGroup = JSON.stringify((saved.fotos || []).map(rawUrl)).replace(/"/g, "&quot;");
    (saved.fotos || []).forEach((path, i) => {
      fotosHtml += `<div class="attach-thumb attach-thumb-remove" data-lightbox-group="${activeGroup}" data-lightbox-index="${i}"><img src="${esc(rawUrl(path))}" alt="" onerror="__imgRetry(this)" onload="__imgLoaded(this)"><button type="button" data-remove-saved-foto="${stage}:${i}" title="${esc(t('quitar_btn'))}">×</button></div>`;
    });
    pending.fotos.forEach((file, i) => {
      fotosHtml += `<div class="attach-thumb pending attach-thumb-remove"><img src="${URL.createObjectURL(file)}" alt=""><button type="button" data-remove-pending-foto="${stage}:${i}" title="${esc(t('quitar_btn'))}">×</button></div>`;
    });

    let docsHtml = "";
    (saved.documentos || []).forEach((path, i) => {
      const name = decodeURIComponent(path.split("/").pop());
      docsHtml += `<span class="doc-chip">📄 ${esc(name)} <button type="button" class="doc-remove" data-remove-saved-doc="${stage}:${i}" title="${esc(t('quitar_btn'))}">×</button></span>`;
    });
    pending.documentos.forEach((file, i) => {
      docsHtml += `<span class="doc-chip pending">📄 ${esc(file.name)} <button type="button" class="doc-remove" data-remove-pending-doc="${stage}:${i}" title="${esc(t('quitar_btn'))}">×</button></span>`;
    });

    const toolKey = stage === "recibido" ? "recibido" : (stage === "diagnostico" ? "diagnostico" : (stage === "recogido" ? "recogido" : null));
    const toolIsOpen = toolKey ? !!toolPanelOpen[toolKey] : false;
    let toolButtonHtml = "";
    let toolPanelHtml = "";
    let toolSummaryHtml = "";
    if (stage === "recibido") {
      toolButtonHtml = `<button type="button" class="btn btn-sm ${toolIsOpen ? "btn-tool-active" : "btn-outline"}" data-toggle-tool="recibido">${esc(t("orden_recepcion_titulo"))}</button>`;
      if (toolIsOpen) toolPanelHtml = `<div class="tool-panel">${renderOrdenRecepcionSection()}</div>`;
    } else if (stage === "diagnostico") {
      toolButtonHtml = `<button type="button" class="btn btn-sm ${toolIsOpen ? "btn-tool-active" : "btn-outline"}" data-toggle-tool="diagnostico">${esc(t("cotizacion_titulo"))}</button>`;
      if (toolIsOpen) toolPanelHtml = `<div class="tool-panel">${renderCotizacionSection()}</div>`;
      // Resumen de montos siempre visible en esta etapa, sin tener que abrir la cotización.
      const cotResumen = svcActual.cotizacion || emptyCotizacion();
      const totalesResumen = calcCotizacionTotales(cotResumen.items, cotResumen.incluir_iva);
      if (totalesResumen.subtotal > 0) {
        toolSummaryHtml = `
          <div class="diag-money-summary">
            <div><span>${esc(t("cotiz_subtotal"))}</span><span>$${totalesResumen.subtotal.toLocaleString("es-MX", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span></div>
            ${cotResumen.incluir_iva ? `<div><span>${esc(t("cotiz_iva"))}</span><span>$${totalesResumen.iva.toLocaleString("es-MX", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span></div>` : ""}
            <div class="diag-money-total"><span>${esc(t("cotiz_total_general"))}</span><span>$${totalesResumen.total.toLocaleString("es-MX", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span></div>
          </div>`;
      }
    } else if (stage === "recogido") {
      toolButtonHtml = `<button type="button" class="btn btn-sm ${toolIsOpen ? "btn-tool-active" : "btn-outline"}" data-toggle-tool="recogido">${esc(t("informe_trabajo_titulo"))}</button>`;
      if (toolIsOpen) toolPanelHtml = `<div class="tool-panel">${renderInformeTrabajoSection()}</div>`;
    }

    return `
      <details class="card-details" id="stage-details-${stage}" style="margin-top:14px;" ${wasOpen ? "open" : ""}>
        <summary class="card-title">${info.icon} ${info.label} (${(saved.fotos||[]).length + pending.fotos.length + (saved.documentos||[]).length + pending.documentos.length})</summary>
        <div class="card-details-body">
          <div class="attach-input-row">
            <button type="button" class="btn btn-outline btn-sm" data-stage-camera="${stage}">${esc(t("tomar_foto"))}</button>
            <button type="button" class="btn btn-outline btn-sm" data-stage-gallery="${stage}">${esc(t("fototeca_btn"))}</button>
            <button type="button" class="btn btn-outline btn-sm" data-stage-pdf="${stage}">${esc(t("pdf_btn"))}</button>
            ${toolButtonHtml}
            <input type="file" id="as-cam-${stage}" data-stage="${stage}" data-kind="foto" accept="image/*" capture="environment" style="display:none;">
            <input type="file" id="as-gal-${stage}" data-stage="${stage}" data-kind="foto" accept="image/*" multiple style="display:none;">
            <input type="file" id="as-pdf-${stage}" data-stage="${stage}" data-kind="pdf" accept="application/pdf" multiple style="display:none;">
          </div>
          ${toolSummaryHtml}
          <div class="attach-gallery">${fotosHtml}</div>
          <div>${docsHtml}</div>
          ${toolPanelHtml}
        </div>
      </details>`;
  }

  function renderInventarioToggle(key, labelKey, value, prefix) {
    const checked = value === "si";
    return `
      <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:8px;">
        <label style="font-size:11.5px;color:var(--text-dim);flex:1;">${esc(t(labelKey))}</label>
        <label class="inv-toggle">
          <input type="checkbox" data-inv="${prefix}:${key}" ${checked ? "checked" : ""}>
          <span class="pill"><span class="txt-no">${esc(t("inv_no"))}</span><span class="txt-si">${esc(t("inv_si"))}</span></span>
        </label>
      </div>`;
  }

  function fuelGaugeColor(pct) {
    if (pct <= 25) return "var(--danger, #b3504f)";
    if (pct <= 74) return "#c99a1f";
    return "var(--green-bright)";
  }

  function renderFuelGauge(pct) {
    pct = Math.max(0, Math.min(100, Number(pct) || 0));
    return `
      <div class="fuel-gauge" data-fuel-current="${pct}">
        <div class="fuel-track" id="or-fuel-track">
          <div class="fuel-fill" style="width:${pct}%;background:${fuelGaugeColor(pct)};"></div>
        </div>
        <div class="fuel-ticks"><span>0%</span><span>25%</span><span>50%</span><span>75%</span><span>100%</span></div>
        <div class="fuel-value-label">${pct}%</div>
      </div>`;
  }

  function calcCotizacionTotales(items, incluirIva) {
    const subtotal = items.reduce((sum, it) => sum + (Number(it.cantidad) || 0) * (Number(it.costo_unitario) || 0), 0);
    const iva = incluirIva ? subtotal * 0.16 : 0;
    return { subtotal, iva, total: subtotal + iva };
  }

  // El monto real de un servicio (activo o del historial): si tiene una
  // Cotización con conceptos cargados, ese es el monto verdadero (con IVA
  // incluido si aplica) — el campo "Precio" suelto se queda vacío en cuanto
  // se usa la cotización, así que NUNCA hay que sumar/mostrar "costo" solo
  // sin antes checar esto, o los reportes de ingresos salen mal.
  function efectiveCosto(servicio) {
    const cot = servicio && servicio.cotizacion;
    const tieneCotizacion = cot && (cot.items || []).some((it) => (Number(it.cantidad) || 0) * (Number(it.costo_unitario) || 0) > 0);
    if (tieneCotizacion) return calcCotizacionTotales(cot.items, cot.incluir_iva).total;
    return servicio ? Number(servicio.costo) || 0 : 0;
  }

  function renderInformeTrabajoSection() {
    const inf = svcActual.informe_trabajo || emptyInformeTrabajo();
    return `
        <div class="tool-panel-title">${esc(t("informe_trabajo_titulo"))}</div>
        <p style="color:var(--text-faint);font-size:11.5px;margin-top:-6px;">${esc(t("informe_trabajo_desc"))}</p>
        <div style="font-size:11.5px;color:${inf.enviado ? "var(--green-bright)" : "var(--text-faint)"};margin-bottom:10px;">
          ${inf.enviado ? `${esc(t("informe_trabajo_estado_enviado"))} ${formatFechaCorta(inf.fecha_envio)}` : esc(t("informe_trabajo_estado_no_enviado"))}
          ${inf.pdf_path ? ` · <a href="${esc(rawUrl(inf.pdf_path))}" target="_blank" rel="noopener">${esc(t("ver_pdf_enviado"))}</a>` : ""}
        </div>
        <div class="actions-row">
          <button class="btn btn-outline btn-sm" id="btn-enviar-informe-trabajo" type="button">${esc(t("btn_enviar_informe_trabajo"))}</button>
        </div>`;
  }

  function renderCotizacionSection() {
    const cot = svcActual.cotizacion || emptyCotizacion();
    const { subtotal, iva, total } = calcCotizacionTotales(cot.items, cot.incluir_iva);
    const itemsHtml = cot.items.map((item, i) => {
      const rowTotal = (Number(item.cantidad) || 0) * (Number(item.costo_unitario) || 0);
      return `
        <div class="cotiz-item-row" data-cotiz-row="${i}">
          <input type="text" class="cotiz-concepto" placeholder="${esc(t("cotiz_concepto_placeholder"))}" value="${esc(item.concepto || "")}">
          <div class="cotiz-item-nums">
            <input type="number" class="cotiz-cantidad" min="0" step="1" placeholder="${esc(t("cotiz_cant_label"))}" value="${item.cantidad ?? 1}">
            <input type="number" class="cotiz-costo" min="0" step="0.01" placeholder="${esc(t("cotiz_costo_unitario_label"))}" value="${item.costo_unitario ?? ""}">
            <span class="cotiz-item-total">$${rowTotal.toLocaleString("es-MX", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
            ${cot.items.length > 1 ? `<button type="button" class="cotiz-remove-item" data-remove-cotiz-item="${i}" title="${esc(t('quitar_btn'))}">×</button>` : ""}
          </div>
        </div>`;
    }).join("");

    return `
        <div class="tool-panel-title">${esc(t("cotizacion_titulo"))}</div>
        <p style="color:var(--text-faint);font-size:11.5px;margin-top:-6px;">${esc(t("cotizacion_desc"))}</p>
        <div id="cotiz-items-list">${itemsHtml}</div>
        <div class="actions-row" style="margin-top:6px;">
          <button class="btn btn-outline btn-sm" id="btn-add-cotiz-item" type="button">${esc(t("cotiz_agregar_concepto"))}</button>
        </div>
        <label style="display:flex;align-items:center;gap:8px;margin-top:14px;font-size:12.5px;color:var(--text-dim);">
          <input type="checkbox" id="cotiz-incluir-iva" ${cot.incluir_iva ? "checked" : ""}>
          ${esc(t("cotiz_incluir_iva"))}
        </label>
        <div class="cotiz-totales">
          <div><span>${esc(t("cotiz_subtotal"))}</span><span id="cotiz-subtotal-display">$${subtotal.toLocaleString("es-MX", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span></div>
          <div><span>${esc(t("cotiz_iva"))}</span><span id="cotiz-iva-display">$${iva.toLocaleString("es-MX", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span></div>
          <div class="cotiz-total-general"><span>${esc(t("cotiz_total_general"))}</span><span id="cotiz-total-display">$${total.toLocaleString("es-MX", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span></div>
        </div>
        <div class="field" style="margin-top:12px;">
          <div class="field-label">${esc(t("cotiz_tiempo_entrega_auto_label"))}</div>
          <div class="field-value">${svcActual.tiempo_entrega_aprox ? esc(svcActual.tiempo_entrega_aprox) : `<span style="color:var(--text-faint);">${esc(t("cotiz_tiempo_entrega_sin_registrar"))}</span>`}</div>
        </div>
        <div class="form-group" style="margin-top:12px;">
          <label class="form-label">${esc(t("cotiz_observaciones_label"))}</label>
          <textarea id="cotiz-observaciones" placeholder="${esc(t("cotiz_observaciones_placeholder"))}">${esc(cot.observaciones || "")}</textarea>
        </div>
        <div style="font-size:11.5px;color:${cot.enviado ? "var(--green-bright)" : "var(--text-faint)"};margin-bottom:10px;">
          ${cot.enviado ? `${esc(t("cotiz_estado_enviada"))} ${formatFechaCorta(cot.fecha_envio)}` : esc(t("cotiz_estado_no_enviada"))}
          ${cot.pdf_path ? ` · <a href="${esc(rawUrl(cot.pdf_path))}" target="_blank" rel="noopener">${esc(t("ver_pdf_enviado"))}</a>` : ""}
        </div>
        <div class="actions-row">
          <button class="btn btn-outline btn-sm" id="btn-enviar-cotizacion" type="button">${esc(t("btn_enviar_cotizacion"))}</button>
        </div>
        <label class="accept-toggle">
          <input type="checkbox" id="cotiz-aceptada" ${cot.aceptado ? "checked" : ""}>
          <span class="accept-toggle-track">
            <span class="accept-toggle-dot"></span>
            <span class="accept-toggle-txt-off">${esc(t("cliente_acepto_cotizacion_check"))}</span>
            <span class="accept-toggle-txt-on">${esc(t("cliente_ya_acepto_cotizacion_txt"))}</span>
          </span>
        </label>`;
  }

  function renderOrdenRecepcionSection() {
    const or = svcActual.orden_recepcion || emptyOrdenRecepcion();
    const inv = or.inventario || emptyOrdenRecepcion().inventario;
    const estadoTxt = or.aceptado
      ? `${esc(t("orden_estado_aceptado"))} ${formatFechaCorta(or.fecha_aceptado)}`
      : or.enviado
        ? `${esc(t("orden_estado_pendiente"))} ${formatFechaCorta(or.fecha_envio)}`
        : esc(t("orden_estado_no_enviado"));
    const estadoColor = or.aceptado ? "var(--green-bright)" : (or.enviado ? "var(--yellow)" : "var(--text-faint)");
    return `
        <div class="tool-panel-title">${esc(t("orden_recepcion_titulo"))}</div>
        <p style="color:var(--text-faint);font-size:11.5px;margin-top:-6px;">${esc(t("orden_recepcion_desc"))}</p>
        <div class="grid-2">
          <div>
            <div class="form-label" style="margin-bottom:6px;">${esc(t("inventario_exteriores"))}</div>
            ${INVENTARIO_EXTERIORES.map(([k, lk]) => renderInventarioToggle(k, lk, inv.exteriores[k], "ext")).join("")}
          </div>
          <div>
            <div class="form-label" style="margin-bottom:6px;">${esc(t("inventario_accesorios"))}</div>
            ${INVENTARIO_ACCESORIOS.map(([k, lk]) => renderInventarioToggle(k, lk, inv.accesorios[k], "acc")).join("")}
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">${esc(t("nivel_gasolina_label"))}</label>
          ${renderFuelGauge(inv.gasolina)}
        </div>
        <div class="form-group">
          <label class="form-label">${esc(t("danos_notas_label"))}</label>
          <textarea id="or-danos">${esc(inv.danos_notas || "")}</textarea>
        </div>
        <div style="font-size:11.5px;color:${estadoColor};margin-bottom:10px;">${estadoTxt}${or.pdf_path ? ` · <a href="${esc(rawUrl(or.pdf_path))}" target="_blank" rel="noopener">${esc(t("ver_pdf_enviado"))}</a>` : ""}</div>
        <div class="actions-row">
          <button class="btn btn-outline btn-sm" id="btn-enviar-orden" type="button">${esc(t("btn_enviar_aceptacion"))}</button>
        </div>
        <label class="accept-toggle">
          <input type="checkbox" id="or-aceptado" ${or.aceptado ? "checked" : ""}>
          <span class="accept-toggle-track">
            <span class="accept-toggle-dot"></span>
            <span class="accept-toggle-txt-off">${esc(t("cliente_acepto_check"))}</span>
            <span class="accept-toggle-txt-on">${esc(t("cliente_ya_acepto_txt"))}</span>
          </span>
        </label>`;
  }

  function renderActiveServiceCard() {
    const container = $("active-service-container");

    if (!svcActual) {
      container.innerHTML = `
        <p style="color:var(--text-faint);font-size:13px;">${esc(t("no_hay_servicio_proceso"))}</p>
        <button class="btn btn-block" id="btn-start-service">${esc(t("iniciar_servicio_btn"))}</button>
      `;
      return;
    }

    container.innerHTML = `
      ${svcActual.folio ? `<div style="font-family:'JetBrains Mono',monospace;font-size:12px;color:var(--green-bright);margin-bottom:10px;">${esc(t("folio_label"))}: <strong>${esc(svcActual.folio)}</strong></div>` : ""}
      <div class="form-group">
        <label class="form-label">${esc(t("etapa_actual_label"))}</label>
        <select id="as-estado">
          ${ORDEN_ESTADOS_SERVICIO.map((k) => `<option value="${k}" ${k === svcActual.estado ? "selected" : ""}>${ESTADOS_SERVICIO()[k].icon} ${ESTADOS_SERVICIO()[k].label}</option>`).join("")}
        </select>
      </div>
      <div class="grid-2">
        <div class="form-group">
          <label class="form-label">${esc(t("tipo_servicio_label"))}</label>
          <input type="text" id="as-tipo" value="${esc(svcActual.tipo || "")}">
          <select id="as-plantilla" style="margin-top:6px;font-size:11.5px;">
            <option value="">${esc(t("plantilla_elegir"))}</option>
            ${Object.keys(SERVICE_TEMPLATES).map((k) => `<option value="${esc(k)}">${esc(k)}</option>`).join("")}
          </select>
        </div>
        <div class="form-group"><label class="form-label">${esc(t("kilometraje_label"))}</label><input type="number" id="as-km" value="${svcActual.km ?? ""}"></div>
        <div class="form-group"><label class="form-label">${esc(t("costo_estimado_label"))}</label><input type="number" id="as-costo" value="${svcActual.costo ?? ""}"></div>
        <div class="form-group"><label class="form-label">${esc(t("tecnico_label"))}</label><input type="text" id="as-tecnico" list="tecnicos-list" value="${esc(svcActual.tecnico || "")}"></div>
        <div class="form-group"><label class="form-label">${esc(t("tiempo_entrega_label"))}</label><input type="text" id="as-tiempo-entrega" placeholder="${esc(t("tiempo_entrega_placeholder"))}" value="${esc(svcActual.tiempo_entrega_aprox || "")}"></div>
      </div>
      <div class="form-group">
        <label class="form-label">${esc(t("descripcion_label"))}</label>
        <textarea id="as-desc">${esc(svcActual.descripcion || "")}</textarea>
        <p style="font-size:10.5px;color:var(--text-faint);margin:3px 0 0;">${esc(t("descripcion_visible_hint"))}</p>
      </div>
      <div class="form-group">
        <label class="form-label">${esc(t("nota_interna_label"))}</label>
        <textarea id="as-nota-interna" style="border-color:rgba(232,201,74,0.25);">${esc(svcActual.nota_interna || "")}</textarea>
        <p style="font-size:10.5px;color:var(--yellow);margin:3px 0 0;">${esc(t("nota_interna_hint"))}</p>
      </div>
      <div style="font-size:11px;color:var(--text-faint);margin-bottom:4px;">
        ${esc(t("iniciado_txt"))}: ${formatFechaCorta(svcActual.fecha_inicio)} · ${esc(t("actualizado_txt"))}: ${formatFechaCorta(svcActual.actualizado)}
      </div>
      ${renderCronologiaEtapas()}

      ${ORDEN_ESTADOS_SERVICIO.map((stage) => renderStageBlock(stage)).join("")}

      <div style="margin-top:18px;padding-top:14px;border-top:1px solid rgba(255,255,255,0.06);">
        <div class="card-title">${esc(t("pago_titulo"))}</div>
        <div class="grid-2">
          <div class="form-group">
            <label class="form-label">${esc(t("estado_pago_label"))}</label>
            <select id="as-pago-estado">
              ${Object.keys(PAGO_ESTADOS()).map((k) => `<option value="${k}" ${k === svcActual.pago.estado ? "selected" : ""}>${PAGO_ESTADOS()[k].icon} ${PAGO_ESTADOS()[k].label}</option>`).join("")}
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">${esc(t("metodo_pago_label"))}</label>
            <select id="as-pago-metodo">
              <option value="" ${!svcActual.pago.metodo ? "selected" : ""}>${esc(t("sin_especificar"))}</option>
              <option value="efectivo" ${svcActual.pago.metodo === "efectivo" ? "selected" : ""}>💵 ${esc(t("metodo_efectivo"))}</option>
              <option value="transferencia" ${svcActual.pago.metodo === "transferencia" ? "selected" : ""}>🏦 ${esc(t("metodo_transferencia"))}</option>
            </select>
          </div>
        </div>
        ${svcActual.pago.estado === "a_deber" ? `
        <div class="grid-2">
          <div class="form-group"><label class="form-label">${esc(t("monto_pagado_label"))}</label><input type="number" min="0" id="as-pago-monto-pagado" value="${svcActual.pago.monto_pagado ?? ""}"></div>
          <div class="form-group"><label class="form-label">${esc(t("saldo_pendiente_label"))}</label><input type="number" min="0" id="as-pago-saldo-pendiente" value="${Math.max(0, efectiveCosto(svcActual) - (Number(svcActual.pago.monto_pagado) || 0)).toFixed(2)}" readonly style="opacity:0.75;"></div>
        </div>` : ""}
        ${renderStageBlock("pago", PAGO_INFO())}
      </div>

      <div class="actions-row" style="margin-top:16px;">
        <button class="btn" id="btn-finalize-service">${esc(t("marcar_finalizado_btn"))}</button>
        <button class="btn btn-outline btn-danger" id="btn-cancel-service">${esc(t("cancelar_servicio_btn"))}</button>
      </div>
    `;
  }

  function readActiveServiceFieldsFromDom() {
    if (!svcActual) return;
    svcActual.tipo = $("as-tipo").value.trim();
    svcActual.descripcion = $("as-desc").value.trim();
    if ($("as-nota-interna")) svcActual.nota_interna = $("as-nota-interna").value.trim();
    svcActual.km = $("as-km").value ? Number($("as-km").value) : null;
    svcActual.costo = $("as-costo").value ? Number($("as-costo").value) : null;
    svcActual.tecnico = $("as-tecnico").value.trim();
    svcActual.tiempo_entrega_aprox = $("as-tiempo-entrega").value.trim();
    if (!svcActual.pago) svcActual.pago = { estado: "no_pagado", metodo: null };
    if ($("as-pago-estado")) svcActual.pago.estado = $("as-pago-estado").value;
    if ($("as-pago-metodo")) svcActual.pago.metodo = $("as-pago-metodo").value || null;
    if ($("as-pago-monto-pagado")) svcActual.pago.monto_pagado = $("as-pago-monto-pagado").value ? Math.max(0, Number($("as-pago-monto-pagado").value)) : null;
    if ($("as-pago-saldo-pendiente")) svcActual.pago.saldo_pendiente = Math.max(0, efectiveCosto(svcActual) - (Number(svcActual.pago.monto_pagado) || 0));
    if (!svcActual.orden_recepcion) svcActual.orden_recepcion = emptyOrdenRecepcion();
    const or = svcActual.orden_recepcion;
    document.querySelectorAll("#active-service-container [data-inv]").forEach((sel) => {
      const [group, key] = sel.dataset.inv.split(":");
      const target = group === "ext" ? or.inventario.exteriores : or.inventario.accesorios;
      target[key] = sel.checked ? "si" : "no";
    });
    const fuelEl = document.querySelector("#active-service-container .fuel-gauge");
    if (fuelEl) or.inventario.gasolina = Number(fuelEl.dataset.fuelCurrent) || 0;
    if ($("or-danos")) or.inventario.danos_notas = $("or-danos").value.trim();
    if (!svcActual.cotizacion) svcActual.cotizacion = emptyCotizacion();
    const cot = svcActual.cotizacion;
    const rows = document.querySelectorAll("#cotiz-items-list .cotiz-item-row");
    if (rows.length) {
      cot.items = Array.from(rows).map((r) => ({
        concepto: r.querySelector(".cotiz-concepto").value.trim(),
        cantidad: r.querySelector(".cotiz-cantidad").value ? Number(r.querySelector(".cotiz-cantidad").value) : 0,
        costo_unitario: r.querySelector(".cotiz-costo").value ? Number(r.querySelector(".cotiz-costo").value) : null,
      }));
    }
    if ($("cotiz-incluir-iva")) cot.incluir_iva = $("cotiz-incluir-iva").checked;
    if ($("cotiz-observaciones")) cot.observaciones = $("cotiz-observaciones").value.trim();
    const nuevoEstado = $("as-estado").value;
    if (nuevoEstado !== svcActualEstadoOriginal) {
      svcActual.actualizado = todayISO();
      svcActualEstadoOriginal = nuevoEstado;
      marcarFechaEtapa(nuevoEstado);
    }
    svcActual.estado = nuevoEstado;
  }

  function onStartServiceClick() {
    const today = todayISO();
    svcActual = {
      id: "svc_" + Date.now(),
      folio: siguienteFolio(),
      tipo: "", descripcion: "", nota_interna: "", km: null, costo: null, tecnico: "",
      fecha_inicio: today, estado: "recibido", actualizado: today,
      fechas_etapa: { recibido: new Date().toISOString() },
      pago: { estado: "no_pagado", metodo: null },
      orden_recepcion: emptyOrdenRecepcion(),
      cotizacion: emptyCotizacion(),
      informe_trabajo: emptyInformeTrabajo(),
      adjuntos: {
        recibido: { fotos: [], documentos: [] },
        diagnostico: { fotos: [], documentos: [] },
        en_proceso: { fotos: [], documentos: [] },
        listo: { fotos: [], documentos: [] },
        recogido: { fotos: [], documentos: [] },
        pago: { fotos: [], documentos: [] },
      },
    };
    svcActualEstadoOriginal = "recibido";
    svcActualPending = emptyPendingStruct();
    renderActiveServiceCard();
  }

  function onCancelServiceClick() {
    if (!svcActual) return;
    if (!confirm(t("confirm_cancelar_servicio"))) return;
    if (svcActual.adjuntos) collectServiceAttachmentPaths(svcActual).forEach(queueDelete);
    svcActual = null;
    svcActualPending = emptyPendingStruct();
    renderActiveServiceCard();
  }

  async function onFinalizeServiceClick() {
    if (!svcActual) return;
    readActiveServiceFieldsFromDom();
    if (!svcActual.tipo) {
      showToast(t("msg_indica_tipo_servicio"), "error");
      return;
    }
    // Resumen de lo que falta antes de finalizar, para no cerrar por error
    // un servicio incompleto (sin bloquearlo — el admin puede tener sus
    // razones para finalizar así de todas formas).
    const pendientes = [];
    if (svcActual.estado !== "recogido") pendientes.push(t("resumen_no_entregado"));
    if (svcActual.pago.estado !== "pagado") pendientes.push(t("resumen_pago_pendiente"));
    if (!svcActual.informe_trabajo || !svcActual.informe_trabajo.enviado) pendientes.push(t("resumen_informe_no_enviado"));
    if (svcActual.cotizacion && (svcActual.cotizacion.items || []).some((it) => (Number(it.cantidad) || 0) * (Number(it.costo_unitario) || 0) > 0) && !svcActual.cotizacion.aceptado) {
      pendientes.push(t("resumen_cotizacion_no_aceptada"));
    }
    const mensaje = pendientes.length
      ? t("confirm_finalizar_incompleto").replace("{lista}", pendientes.map((p) => `⚠️ ${p}`).join("\n"))
      : t("confirm_finalizar_servicio");
    if (!confirm(mensaje)) return;

    const svcActualRespaldo = svcActual;
    const svcActualPendingRespaldo = svcActualPending;
    pendingServices.unshift(buildHistoricalEntryFromActive(svcActual, svcActualPending));
    svcActual = null;
    svcActualPending = emptyPendingStruct();

    renderServicesList();
    renderActiveServiceCard();
    // Se guarda solo al finalizar — ya no hace falta acordarse de presionar
    // "Guardar cambios en GitHub" aparte.
    const guardadoOk = await saveVehicle();
    if (!guardadoOk) {
      // El guardado falló — se revierte el estado local. Si no, la pantalla
      // diría "sin servicio activo" aunque en GitHub nunca quedó finalizado,
      // y el admin no tendría forma de saber que hace falta reintentar.
      pendingServices.shift();
      svcActual = svcActualRespaldo;
      svcActualPending = svcActualPendingRespaldo;
      renderServicesList();
      renderActiveServiceCard();
      showToast(t("msg_finalizar_no_guardado"), "error", 8000);
    }
  }

  /* Delegación de eventos dentro del contenedor del servicio activo */
  // Recalcula los totales de la cotización en vivo, mientras se escribe —
  // sin volver a dibujar toda la tarjeta (para no perder el foco del campo).
  function formatMXN(n) { return "$" + n.toLocaleString("es-MX", { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
  $("active-service-container").addEventListener("input", (e) => {
    const tgt = e.target;
    if (tgt.id === "as-pago-monto-pagado") {
      const saldoEl = $("as-pago-saldo-pendiente");
      if (saldoEl) saldoEl.value = Math.max(0, efectiveCosto(svcActual) - (Number(tgt.value) || 0)).toFixed(2);
      return;
    }
    if (!tgt.classList.contains("cotiz-cantidad") && !tgt.classList.contains("cotiz-costo")) return;
    const row = tgt.closest(".cotiz-item-row");
    const cant = Number(row.querySelector(".cotiz-cantidad").value) || 0;
    const costo = Number(row.querySelector(".cotiz-costo").value) || 0;
    row.querySelector(".cotiz-item-total").textContent = formatMXN(cant * costo);

    let subtotal = 0;
    document.querySelectorAll("#cotiz-items-list .cotiz-item-row").forEach((r) => {
      const c = Number(r.querySelector(".cotiz-cantidad").value) || 0;
      const co = Number(r.querySelector(".cotiz-costo").value) || 0;
      subtotal += c * co;
    });
    const incluirIva = $("cotiz-incluir-iva") ? $("cotiz-incluir-iva").checked : true;
    const iva = incluirIva ? subtotal * 0.16 : 0;
    $("cotiz-subtotal-display").textContent = formatMXN(subtotal);
    $("cotiz-iva-display").textContent = formatMXN(iva);
    $("cotiz-total-display").textContent = formatMXN(subtotal + iva);
  });

  $("active-service-container").addEventListener("click", (e) => {
    if (e.target.id === "btn-start-service") return onStartServiceClick();

    const toggleToolBtn = e.target.closest("[data-toggle-tool]");
    if (toggleToolBtn) {
      readActiveServiceFieldsFromDom();
      const key = toggleToolBtn.dataset.toggleTool;
      toolPanelOpen[key] = !toolPanelOpen[key];
      renderActiveServiceCard();
      return;
    }
    if (e.target.id === "btn-finalize-service") return onFinalizeServiceClick();
    if (e.target.id === "btn-cancel-service") return onCancelServiceClick();

    if (e.target.id === "btn-add-cotiz-item") {
      readActiveServiceFieldsFromDom();
      svcActual.cotizacion.items.push({ concepto: "", cantidad: 1, costo_unitario: null });
      renderActiveServiceCard();
      return;
    }
    const removeCotizItem = e.target.closest("[data-remove-cotiz-item]");
    if (removeCotizItem) {
      readActiveServiceFieldsFromDom();
      svcActual.cotizacion.items.splice(Number(removeCotizItem.dataset.removeCotizItem), 1);
      renderActiveServiceCard();
      return;
    }
    if (e.target.id === "btn-enviar-cotizacion") {
      readActiveServiceFieldsFromDom();
      const { subtotal } = calcCotizacionTotales(svcActual.cotizacion.items, svcActual.cotizacion.incluir_iva);
      if (subtotal <= 0) {
        showToast(t("msg_indica_al_menos_un_concepto"), "error");
        return;
      }
      const vehicleId = $("f-id").value.trim();
      const vehicleSnap = {
        id: vehicleId,
        placas: $("f-placas").value.trim(),
        numero_unidad: $("f-numero-unidad").value.trim(),
        marca: $("f-marca").value.trim(),
        modelo: $("f-modelo").value.trim(),
        anio: $("f-anio").value.trim(),
        color: $("f-color").value.trim(),
        combustible: $("f-combustible").value.trim(),
        vin: $("f-vin").value.trim(),
        km_actual: $("f-km").value.trim(),
        cliente_nombre: $("f-cliente-nombre").value.trim(),
        cliente_telefono: $("f-cliente-tel").value.trim(),
        cliente_telefono_2: $("f-cliente-tel-2").value.trim(),
        cliente_correo: $("f-cliente-correo").value.trim(),
        cliente_rfc: $("f-cliente-rfc").value.trim().toUpperCase(),
        cliente_direccion: $("f-cliente-direccion").value.trim(),
      };
      const btn = e.target;
      const originalLabel = btn.textContent;
      btn.disabled = true;
      (async () => {
        try {
          btn.textContent = t("btn_generando_pdf");
          const pdfBlob = await generarCotizacionPDF(vehicleSnap, svcActual, svcActualPending);
          btn.textContent = t("btn_subiendo_pdf");
          const base64 = await blobToBase64(pdfBlob);
          const path = `uploads/${vehicleId}/${timestampSlug()}-cotizacion.pdf`;
          await uploadBinaryFile(path, base64, `Cotización — ${vehicleSnap.placas || vehicleId}`);

          svcActual.cotizacion.enviado = true;
          svcActual.cotizacion.fecha_envio = todayISO();
          svcActual.cotizacion.pdf_path = path;
          renderActiveServiceCard();
          btn.textContent = t("guardando_btn");
          const guardadoOk = await saveVehicle();
          // El PDF ya se subió — pero si el registro no se guardó, no tiene
          // caso ofrecer mandarlo: el cliente vería "enviado" en algo que en
          // realidad no quedó registrado. saveVehicle() ya avisó del error.
          if (!guardadoOk) return;

          offerWhatsAppCotizacion({
            nombre: vehicleSnap.cliente_nombre,
            telefono: vehicleSnap.cliente_telefono,
            telefono2: vehicleSnap.cliente_telefono_2,
            marca: vehicleSnap.marca,
            modelo: vehicleSnap.modelo,
            placas: vehicleSnap.placas,
            numero_unidad: vehicleSnap.numero_unidad,
            id: vehicleId,
            pdfUrl: rawUrl(path),
          });
        } catch (err) {
          showToast(t("msg_error_informe_pdf") + err.message, "error", 8000);
        } finally {
          btn.disabled = false;
          btn.textContent = originalLabel;
        }
      })();
      return;
    }
    if (e.target.id === "btn-enviar-informe-trabajo") {
      readActiveServiceFieldsFromDom();
      const vehicleId = $("f-id").value.trim();
      const vehicleSnap = {
        id: vehicleId,
        placas: $("f-placas").value.trim(),
        numero_unidad: $("f-numero-unidad").value.trim(),
        marca: $("f-marca").value.trim(),
        modelo: $("f-modelo").value.trim(),
        anio: $("f-anio").value.trim(),
        color: $("f-color").value.trim(),
        combustible: $("f-combustible").value.trim(),
        vin: $("f-vin").value.trim(),
        km_actual: $("f-km").value.trim(),
        cliente_nombre: $("f-cliente-nombre").value.trim(),
        cliente_telefono: $("f-cliente-tel").value.trim(),
        cliente_telefono_2: $("f-cliente-tel-2").value.trim(),
        cliente_correo: $("f-cliente-correo").value.trim(),
        cliente_rfc: $("f-cliente-rfc").value.trim().toUpperCase(),
        cliente_direccion: $("f-cliente-direccion").value.trim(),
      };
      const btn = e.target;
      const originalLabel = btn.textContent;
      btn.disabled = true;
      (async () => {
        try {
          btn.textContent = t("btn_generando_pdf");
          const pdfBlob = await generarInformeTrabajoPDF(vehicleSnap, svcActual, svcActualPending);
          btn.textContent = t("btn_subiendo_pdf");
          const base64 = await blobToBase64(pdfBlob);
          const path = `uploads/${vehicleId}/${timestampSlug()}-informe-trabajo.pdf`;
          await uploadBinaryFile(path, base64, `Informe de trabajo — ${vehicleSnap.placas || vehicleId}`);

          if (!svcActual.informe_trabajo) svcActual.informe_trabajo = emptyInformeTrabajo();
          svcActual.informe_trabajo.enviado = true;
          svcActual.informe_trabajo.fecha_envio = todayISO();
          svcActual.informe_trabajo.pdf_path = path;
          renderActiveServiceCard();
          btn.textContent = t("guardando_btn");
          const guardadoOk = await saveVehicle();
          if (!guardadoOk) return;

          offerWhatsAppInformeTrabajo({
            nombre: vehicleSnap.cliente_nombre,
            telefono: vehicleSnap.cliente_telefono,
            telefono2: vehicleSnap.cliente_telefono_2,
            marca: vehicleSnap.marca,
            modelo: vehicleSnap.modelo,
            placas: vehicleSnap.placas,
            numero_unidad: vehicleSnap.numero_unidad,
            id: vehicleId,
            pdfUrl: rawUrl(path),
          });
        } catch (err) {
          showToast(t("msg_error_informe_pdf") + err.message, "error", 8000);
        } finally {
          btn.disabled = false;
          btn.textContent = originalLabel;
        }
      })();
      return;
    }
    if (e.target.id === "btn-enviar-orden") {
      readActiveServiceFieldsFromDom();
      const vehicleId = $("f-id").value.trim();
      const vehicleSnap = {
        id: vehicleId,
        placas: $("f-placas").value.trim(),
        numero_unidad: $("f-numero-unidad").value.trim(),
        marca: $("f-marca").value.trim(),
        modelo: $("f-modelo").value.trim(),
        anio: $("f-anio").value.trim(),
        color: $("f-color").value.trim(),
        combustible: $("f-combustible").value.trim(),
        vin: $("f-vin").value.trim(),
        km_actual: $("f-km").value.trim(),
        cliente_nombre: $("f-cliente-nombre").value.trim(),
        cliente_telefono: $("f-cliente-tel").value.trim(),
        cliente_telefono_2: $("f-cliente-tel-2").value.trim(),
        cliente_correo: $("f-cliente-correo").value.trim(),
        cliente_rfc: $("f-cliente-rfc").value.trim().toUpperCase(),
        cliente_direccion: $("f-cliente-direccion").value.trim(),
      };
      const btn = e.target;
      const originalLabel = btn.textContent;
      btn.disabled = true;
      (async () => {
        try {
          btn.textContent = t("btn_generando_pdf");
          const pdfBlob = await generarInformeRecepcionPDF(vehicleSnap, svcActual, svcActualPending);
          btn.textContent = t("btn_subiendo_pdf");
          const base64 = await blobToBase64(pdfBlob);
          const path = `uploads/${vehicleId}/${timestampSlug()}-informe-recepcion.pdf`;
          await uploadBinaryFile(path, base64, `Informe de recepción — ${vehicleSnap.placas || vehicleId}`);

          svcActual.orden_recepcion.enviado = true;
          svcActual.orden_recepcion.fecha_envio = todayISO();
          svcActual.orden_recepcion.pdf_path = path;
          // Con solo enviarle la hoja de recepción al cliente, el servicio
          // ya avanza a Diagnóstico — ya no hace falta el paso aparte de
          // marcar "Cliente aceptó" para que la etapa se mueva.
          if (svcActual.estado === "recibido") {
            svcActual.estado = "diagnostico";
            svcActualEstadoOriginal = "diagnostico";
            svcActual.actualizado = todayISO();
            marcarFechaEtapa("diagnostico");
          }
          renderActiveServiceCard();
          btn.textContent = t("guardando_btn");
          const guardadoOk = await saveVehicle();
          // El PDF ya se subió — pero si el registro no se guardó, no tiene
          // caso ofrecer mandarlo: el cliente vería "enviado" en algo que en
          // realidad no quedó registrado. saveVehicle() ya avisó del error.
          if (!guardadoOk) return;

          offerWhatsAppOrden({
            nombre: vehicleSnap.cliente_nombre,
            telefono: vehicleSnap.cliente_telefono,
            telefono2: vehicleSnap.cliente_telefono_2,
            marca: vehicleSnap.marca,
            modelo: vehicleSnap.modelo,
            placas: vehicleSnap.placas,
            numero_unidad: vehicleSnap.numero_unidad,
            id: vehicleId,
            pdfUrl: rawUrl(path),
          });
        } catch (err) {
          showToast(t("msg_error_informe_pdf") + err.message, "error", 8000);
        } finally {
          btn.disabled = false;
          btn.textContent = originalLabel;
        }
      })();
      return;
    }

    const fuelTrack = e.target.closest(".fuel-track");
    if (fuelTrack) {
      const rect = fuelTrack.getBoundingClientRect();
      const ratio = (e.clientX - rect.left) / rect.width;
      let pct = Math.round((ratio * 100) / 25) * 25;
      pct = Math.max(0, Math.min(100, pct));
      readActiveServiceFieldsFromDom();
      svcActual.orden_recepcion.inventario.gasolina = pct;
      renderActiveServiceCard();
      hasUnsavedChanges = true;
      return;
    }

    const cam = e.target.closest("[data-stage-camera]");
    if (cam) { $(`as-cam-${cam.dataset.stageCamera}`).click(); return; }
    const gal = e.target.closest("[data-stage-gallery]");
    if (gal) { $(`as-gal-${gal.dataset.stageGallery}`).click(); return; }
    const pdf = e.target.closest("[data-stage-pdf]");
    if (pdf) { $(`as-pdf-${pdf.dataset.stagePdf}`).click(); return; }

    const rmSavedFoto = e.target.closest("[data-remove-saved-foto]");
    if (rmSavedFoto) {
      const [stage, idx] = rmSavedFoto.dataset.removeSavedFoto.split(":");
      readActiveServiceFieldsFromDom();
      queueDelete(svcActual.adjuntos[stage].fotos[Number(idx)]);
      svcActual.adjuntos[stage].fotos.splice(Number(idx), 1);
      renderActiveServiceCard();
      return;
    }
    const rmPendingFoto = e.target.closest("[data-remove-pending-foto]");
    if (rmPendingFoto) {
      const [stage, idx] = rmPendingFoto.dataset.removePendingFoto.split(":");
      readActiveServiceFieldsFromDom();
      svcActualPending[stage].fotos.splice(Number(idx), 1);
      renderActiveServiceCard();
      return;
    }
    const rmSavedDoc = e.target.closest("[data-remove-saved-doc]");
    if (rmSavedDoc) {
      const [stage, idx] = rmSavedDoc.dataset.removeSavedDoc.split(":");
      readActiveServiceFieldsFromDom();
      queueDelete(svcActual.adjuntos[stage].documentos[Number(idx)]);
      svcActual.adjuntos[stage].documentos.splice(Number(idx), 1);
      renderActiveServiceCard();
      return;
    }
    const rmPendingDoc = e.target.closest("[data-remove-pending-doc]");
    if (rmPendingDoc) {
      const [stage, idx] = rmPendingDoc.dataset.removePendingDoc.split(":");
      readActiveServiceFieldsFromDom();
      svcActualPending[stage].documentos.splice(Number(idx), 1);
      renderActiveServiceCard();
      return;
    }
  });

  $("active-service-container").addEventListener("change", async (e) => {
    const tgt = e.target;

    if (tgt.id === "as-plantilla") {
      if (tgt.value) aplicarPlantillaServicio(tgt.value);
      return;
    }

    if (tgt.id === "as-pago-estado") {
      if (tgt.value === "pagado" && !$("as-pago-metodo").value) {
        showToast(t("msg_metodo_pago_obligatorio"), "error");
        tgt.value = svcActual.pago.estado;
        return;
      }
      const montoActual = efectiveCosto(svcActual);
      if (tgt.value === "pagado" && !montoActual) {
        if (!confirm(t("confirm_pagar_sin_monto"))) {
          tgt.value = svcActual.pago.estado;
          return;
        }
      }
      readActiveServiceFieldsFromDom();
      renderActiveServiceCard();
      return;
    }
    if (tgt.id === "as-pago-metodo" && svcActual.pago.estado === "pagado" && !tgt.value) {
      showToast(t("msg_metodo_pago_obligatorio"), "error");
      tgt.value = svcActual.pago.metodo || "";
      return;
    }

    if (tgt.id === "cotiz-incluir-iva") {
      let subtotal = 0;
      document.querySelectorAll("#cotiz-items-list .cotiz-item-row").forEach((r) => {
        const c = Number(r.querySelector(".cotiz-cantidad").value) || 0;
        const co = Number(r.querySelector(".cotiz-costo").value) || 0;
        subtotal += c * co;
      });
      const iva = tgt.checked ? subtotal * 0.16 : 0;
      $("cotiz-iva-display").textContent = formatMXN(iva);
      $("cotiz-total-display").textContent = formatMXN(subtotal + iva);
      return;
    }

    if (tgt.id === "as-estado") {
      const prevEstado = svcActual.estado;
      if (ORDEN_ESTADOS_SERVICIO.indexOf(tgt.value) < ORDEN_ESTADOS_SERVICIO.indexOf(prevEstado)) {
        if (!confirm(t("confirm_retroceder_etapa"))) {
          tgt.value = prevEstado;
          return;
        }
      }
      readActiveServiceFieldsFromDom();
      // Cualquier cambio manual de etapa se guarda solo — antes solo pasaba
      // al llegar a "Listo", lo que hacía inconsistente el resto de los
      // cambios de etapa (parecía que unos "cuentan" y otros no).
      if (tgt.value !== prevEstado) marcarFechaEtapa(tgt.value);
      renderActiveServiceCard();
      if (tgt.value !== prevEstado) {
        const montoAviso = efectiveCosto(svcActual);
        const guardadoOk = await saveVehicle();
        if (!guardadoOk) return;
        if (tgt.value === "listo") {
          offerWhatsAppListo({
            nombre: $("f-cliente-nombre").value.trim(),
            telefono: $("f-cliente-tel").value.trim(),
            telefono2: $("f-cliente-tel-2").value.trim(),
            marca: $("f-marca").value.trim(),
            modelo: $("f-modelo").value.trim(),
            placas: $("f-placas").value.trim(),
            numero_unidad: $("f-numero-unidad").value.trim(),
            costo: montoAviso,
          });
        }
      }
      return;
    }

    if (tgt.id === "or-aceptado") {
      readActiveServiceFieldsFromDom();
      svcActual.orden_recepcion.aceptado = tgt.checked;
      svcActual.orden_recepcion.fecha_aceptado = tgt.checked ? todayISO() : null;
      if (tgt.checked && svcActual.estado === "recibido") {
        svcActual.estado = "diagnostico";
        svcActualEstadoOriginal = "diagnostico";
        svcActual.actualizado = todayISO();
        marcarFechaEtapa("diagnostico");
        showToast(t("msg_paso_a_diagnostico"), "success");
        renderActiveServiceCard();
        await saveVehicle();
        return;
      }
      renderActiveServiceCard();
      return;
    }
    if (tgt.id === "cotiz-aceptada") {
      readActiveServiceFieldsFromDom();
      if (!svcActual.cotizacion) svcActual.cotizacion = emptyCotizacion();
      svcActual.cotizacion.aceptado = tgt.checked;
      svcActual.cotizacion.fecha_aceptado = tgt.checked ? todayISO() : null;
      if (tgt.checked && svcActual.estado === "diagnostico") {
        svcActual.estado = "en_proceso";
        svcActualEstadoOriginal = "en_proceso";
        svcActual.actualizado = todayISO();
        marcarFechaEtapa("en_proceso");
        showToast(t("msg_paso_a_en_proceso_cotiz"), "success");
        renderActiveServiceCard();
        await saveVehicle();
        return;
      }
      renderActiveServiceCard();
      return;
    }
    if (!(tgt.tagName === "INPUT" && tgt.type === "file")) return;
    const stage = tgt.dataset.stage;
    const kind = tgt.dataset.kind;
    readActiveServiceFieldsFromDom();

    if (kind === "foto") {
      Array.from(tgt.files).forEach((f) => {
        if (f.type.startsWith("image/")) svcActualPending[stage].fotos.push(f);
      });
    } else if (kind === "pdf") {
      Array.from(tgt.files).forEach((f) => {
        if (f.type !== "application/pdf") { showToast(`${f.name} no es un PDF, se omitió`, "error"); return; }
        if (f.size > MAX_PDF_MB * 1024 * 1024) { showToast(`${f.name} pesa más de ${MAX_PDF_MB} MB, se omitió`, "error"); return; }
        svcActualPending[stage].documentos.push(f);
      });
    }
    tgt.value = "";
    renderActiveServiceCard();
  });

  /* ---------------- Eventos: foto de perfil y documentos del vehículo ---------------- */

  $("btn-vphoto-camera").addEventListener("click", () => $("vphoto-camera-input").click());
  $("btn-vphoto-gallery").addEventListener("click", () => $("vphoto-gallery-input").click());
  ["vphoto-camera-input", "vphoto-gallery-input"].forEach((id) => {
    $(id).addEventListener("change", (e) => {
      const file = e.target.files[0];
      if (file && file.type.startsWith("image/")) {
        vFotoPerfilPending = file;
        vFotoPerfilRemoved = false;
        renderVehiclePhotoPreview();
      }
      e.target.value = "";
    });
  });

  $("btn-vdoc-camera").addEventListener("click", () => $("vdoc-camera-input").click());
  $("btn-vdoc-gallery").addEventListener("click", () => $("vdoc-gallery-input").click());
  $("btn-vdoc-pdf").addEventListener("click", () => $("vdoc-pdf-input").click());
  ["vdoc-camera-input", "vdoc-gallery-input"].forEach((id) => {
    $(id).addEventListener("change", (e) => {
      Array.from(e.target.files).forEach((f) => {
        if (f.type.startsWith("image/")) vDocsPending.fotos.push(f);
      });
      e.target.value = "";
      renderVehicleDocsPreview();
    });
  });
  $("vdoc-pdf-input").addEventListener("change", (e) => {
    Array.from(e.target.files).forEach((f) => {
      if (f.type !== "application/pdf") { showToast(`${f.name} no es un PDF, se omitió`, "error"); return; }
      if (f.size > MAX_PDF_MB * 1024 * 1024) { showToast(`${f.name} pesa más de ${MAX_PDF_MB} MB, se omitió`, "error"); return; }
      vDocsPending.documentos.push(f);
    });
    e.target.value = "";
    renderVehicleDocsPreview();
  });

  /* ---------------- Guardar / eliminar vehículo ---------------- */

  function buildVehicleFromForm() {
    const id = $("f-id").value.trim();
    if (!id) throw new Error(t("msg_id_nfc_obligatorio"));

    let servicioActualToSave = null;
    if (svcActual) {
      readActiveServiceFieldsFromDom();
      servicioActualToSave = {
        id: svcActual.id,
        folio: svcActual.folio,
        tipo: svcActual.tipo,
        descripcion: svcActual.descripcion,
        nota_interna: svcActual.nota_interna,
        km: svcActual.km,
        costo: svcActual.costo,
        tecnico: svcActual.tecnico,
        tiempo_entrega_aprox: svcActual.tiempo_entrega_aprox,
        fecha_inicio: svcActual.fecha_inicio,
        estado: svcActual.estado,
        actualizado: svcActual.actualizado,
        pago: svcActual.pago,
        orden_recepcion: svcActual.orden_recepcion,
        cotizacion: svcActual.cotizacion,
        informe_trabajo: svcActual.informe_trabajo,
        fechas_etapa: svcActual.fechas_etapa,
        adjuntos: svcActual.adjuntos,
        _pendingAdjuntos: svcActualPending,
      };
    }

    const vehiculoExistente = db.vehicles && db.vehicles[id];
    return {
      id,
      fecha_creacion: (vehiculoExistente && vehiculoExistente.fecha_creacion) || new Date().toISOString(),
      foto_perfil: (() => {
        if (vFotoPerfilRemoved && currentFotoPerfil) queueDelete(currentFotoPerfil);
        return vFotoPerfilRemoved ? null : currentFotoPerfil;
      })(),
      _pendingFotoPerfil: vFotoPerfilPending,
      documentos_vehiculo: {
        fotos: currentDocumentosVehiculo.fotos.slice(),
        documentos: currentDocumentosVehiculo.documentos.slice(),
      },
      _pendingDocumentosVehiculo: vDocsPending,
      placas: $("f-placas").value.trim(),
      numero_unidad: $("f-numero-unidad").value.trim(),
      marca: $("f-marca").value.trim(),
      modelo: $("f-modelo").value.trim(),
      anio: $("f-anio").value ? Number($("f-anio").value) : null,
      version: $("f-version").value.trim(),
      color: $("f-color").value.trim(),
      combustible: $("f-combustible").value.trim(),
      vin: $("f-vin").value.trim(),
      km_actual: $("f-km").value ? Number($("f-km").value) : null,
      cliente_nombre: $("f-cliente-nombre").value.trim(),
      cliente_telefono: $("f-cliente-tel").value.trim(),
      cliente_telefono_2: $("f-cliente-tel-2").value.trim(),
      cliente_correo: $("f-cliente-correo").value.trim(),
      cliente_rfc: $("f-cliente-rfc").value.trim().toUpperCase(),
      cliente_direccion: $("f-cliente-direccion").value.trim(),
      ficha_tecnica: {
        aceite_tipo: $("f-aceite-tipo").value.trim(),
        aceite_capacidad: $("f-aceite-cap").value.trim(),
        presion_llantas: $("f-llantas").value.trim(),
        bateria: $("f-bateria").value.trim(),
        filtro_aire: $("f-filtro-aire").value.trim(),
        filtro_aceite: $("f-filtro-aceite").value.trim(),
      },
      servicio_actual: servicioActualToSave,
      servicios: pendingServices,
    };
  }

  async function saveVehicle() {
    let vehicle;
    try {
      vehicle = buildVehicleFromForm();
    } catch (err) {
      showToast(err.message, "error");
      return false;
    }
    // Se guarda una "foto" del contador de ediciones justo con lo que se va
    // a mandar a GitHub — si el admin edita algo MÁS mientras esto sube, al
    // terminar no hay que decir "todo guardado", porque ese cambio nuevo se
    // quedó fuera de este envío.
    const edicionesAlEmpezar = contadorDeEdiciones;
    const eraVehiculoNuevo = isNewVehicle;

    if (isNewVehicle && db.vehicles[vehicle.id]) {
      showToast(t("msg_ya_existe_id"), "error");
      return false;
    }
    if (currentVehicleId && currentVehicleId !== vehicle.id) {
      delete db.vehicles[currentVehicleId];
    }

    const btn = $("btn-save");
    btn.disabled = true;
    btn.textContent = t("guardando_btn");
    setEditorControlsBusy(true);
    uploadProgress = { done: 0, total: countPendingUploads(vehicle) };
    const hadNewPhoto = !!vehicle._pendingFotoPerfil;
    skippedPhotoNames = [];
    let uploadsSucceeded = false;
    try {
      // Estas 3 se corren una tras otra a propósito: cada archivo subido es
      // un commit por separado a la misma rama, y GitHub puede rechazar
      // commits casi simultáneos contra la misma rama con un choque falso
      // (el mismo problema, ya resuelto una vez, que costó mucho diagnosticar
      // antes en este proyecto) — aquí se prioriza confiabilidad sobre
      // velocidad, igual que en la subida de fotos dentro de cada etapa.
      await uploadPendingAttachments(vehicle);
      await uploadPendingActiveServiceAttachments(vehicle);
      await uploadVehicleLevelAttachments(vehicle);

      // Las fotos/documentos YA se subieron a GitHub en este punto, aunque
      // el guardado del JSON de abajo llegue a fallar. Se sincroniza el
      // estado "actual" con lo recién subido y se limpia lo "pendiente" del
      // vehículo AQUÍ MISMO — así, si el JSON falla y el admin vuelve a
      // presionar Guardar, no se suben otra vez los mismos archivos (lo cual
      // dejaría huérfano el primer intento, ya subido pero sin usar).
      currentFotoPerfil = vehicle.foto_perfil || null;
      currentDocumentosVehiculo = vehicle.documentos_vehiculo
        ? JSON.parse(JSON.stringify(vehicle.documentos_vehiculo))
        : { fotos: [], documentos: [] };
      vFotoPerfilPending = null;
      vDocsPending = { fotos: [], documentos: [] };
      uploadsSucceeded = true;

      db.vehicles[vehicle.id] = vehicle;
      const msg = isNewVehicle
        ? `Agregar vehículo ${vehicle.placas || vehicle.id}`
        : `Actualizar vehículo ${vehicle.placas || vehicle.id}`;
      await saveVehicleWithRetry(vehicle, msg);
      await flushPendingDeletes();
      showToast(t("msg_cambios_guardados"), "success");
      if (hadNewPhoto && !skippedPhotoNames.length) showToast(t("msg_foto_puede_tardar"), "", 6500);
      if (skippedPhotoNames.length) {
        showToast(t("msg_fotos_heic_omitidas").replace("{n}", skippedPhotoNames.length).replace("{nombres}", skippedPhotoNames.join(", ")), "error", 12000);
      }
      btn.classList.add("btn-success-flash");
      btn.innerHTML = '<span class="check-pop">✓</span> Guardado';
      lastSavedAt = Date.now();
      if (contadorDeEdiciones === edicionesAlEmpezar) {
        hasUnsavedChanges = false;
      } else {
        // Se editó algo MIENTRAS se guardaba — ese cambio no se incluyó en
        // este envío, así que sigue habiendo algo pendiente de verdad.
        showToast(t("msg_edito_durante_guardado"), "", 6000);
      }
      updateUnsavedIndicator();
      // Un vehículo nuevo guarda su borrador bajo "draft_new" (todavía no
      // tenía ID propio en ese momento) — hay que borrar esa misma clave,
      // no "draft_<id>", o el borrador viejo reaparecería la próxima vez
      // que se dé de alta otro vehículo nuevo.
      borrarBorradorLocal(eraVehiculoNuevo ? null : vehicle.id);
      await new Promise((r) => setTimeout(r, 550));
      currentVehicleId = vehicle.id;
      isNewVehicle = false;
      // Ya NO regresa sola al tablero — se queda en el editor, para no
      // interrumpir lo que el admin esté haciendo (ej. a punto de mandar un
      // WhatsApp) justo después de guardar.
      renderDashboard($("search-box").value);
      return true;
    } catch (err) {
      if (err.status === 409) {
        showToast(t("msg_conflicto_persistente"), "error", 9000);
      } else if (uploadsSucceeded) {
        // Las fotos/documentos ya quedaron subidas en GitHub — solo falló
        // guardar el registro. No hace falta volver a elegir fotos, nada más
        // presionar Guardar otra vez.
        showToast(t("msg_error_solo_json"), "error", 10000);
      } else {
        showToast(t("msg_error_guardar") + err.message, "error");
      }
      return false;
    } finally {
      btn.disabled = false;
      btn.classList.remove("btn-success-flash");
      btn.textContent = "💾";
      setEditorControlsBusy(false);
    }
  }

  async function deleteVehicle() {
    if (!currentVehicleId) return;
    if (!confirm(t("confirm_eliminar_vehiculo"))) return;

    const vehicleIdToClean = currentVehicleId;
    const btn = $("btn-delete");
    btn.disabled = true;
    const originalLabel = btn.textContent;
    try {
      btn.textContent = t("eliminando_registro_btn");
      await saveDatabaseWithRetry(`Eliminar vehículo ${currentVehicleId}`, () => { delete db.vehicles[vehicleIdToClean]; });

      // Se espera a que los archivos de verdad terminen de borrarse (antes
      // corría en segundo plano y el admin nunca sabía si algo había
      // fallado) — se muestra el progreso real, archivo por archivo.
      const resultado = await deleteVehicleUploadsFolder(vehicleIdToClean, (actual, total) => {
        btn.textContent = t("eliminando_archivos_btn").replace("{actual}", actual).replace("{total}", total);
      });

      if (resultado.fallidos.length) {
        showToast(t("msg_vehiculo_eliminado_parcial").replace("{n}", resultado.fallidos.length), "error", 10000);
      } else if (resultado.total > 0) {
        showToast(t("msg_vehiculo_eliminado_completo").replace("{n}", resultado.total), "success");
      } else {
        showToast(t("msg_vehiculo_eliminado"), "success");
      }
      renderDashboard($("search-box").value);
      showView("dashboard");
    } catch (err) {
      if (err.status === 409) {
        showToast(t("msg_conflicto_persistente"), "error", 9000);
      } else {
        showToast(t("msg_error_eliminar") + err.message, "error");
      }
    } finally {
      btn.disabled = false;
      btn.textContent = originalLabel;
    }
  }

  /* ---------------- Eventos generales ---------------- */

  $("btn-connect").addEventListener("click", connect);
  $("btn-logout").addEventListener("click", logout);
  $("btn-back").addEventListener("click", () => {
    if (hasUnsavedChanges && !confirm(t("confirm_salir_sin_guardar"))) return;
    showView("dashboard");
  });
  $("btn-save-and-back").addEventListener("click", async () => {
    const guardadoOk = await saveVehicle();
    // Si se editó algo MIENTRAS se guardaba, saveVehicle() puede regresar
    // true (lo que se mandó sí se guardó) pero hasUnsavedChanges se queda en
    // true a propósito (ese cambio nuevo no se incluyó) — en ese caso no hay
    // que salir, o ese cambio se perdería de vista sin avisar.
    if (guardadoOk && !hasUnsavedChanges) showView("dashboard");
  });

  // Marca cambios sin guardar con cualquier interacción dentro del editor,
  // y avisa antes de cerrar la pestaña/recargar si hay algo sin guardar.
  $("view-editor").addEventListener("input", () => { hasUnsavedChanges = true; contadorDeEdiciones++; updateUnsavedIndicator(); });
  $("view-editor").addEventListener("change", () => { hasUnsavedChanges = true; contadorDeEdiciones++; updateUnsavedIndicator(); });
  // Varias acciones (quitar foto, cancelar servicio, quitar concepto de
  // cotización, mover el marcador de gasolina) cambian datos con un CLIC en
  // vez de un campo de texto — esos nunca disparan "input" ni "change", así
  // que sin esto el aviso de salir sin guardar no se activaba para ellas.
  // Se marca en cualquier clic dentro del editor (salvo abrir/cerrar un
  // desplegable) para no tener que acordarse de cada botón nuevo que se
  // agregue después.
  // Botones que NO cambian ningún dato — no deben marcar "cambios sin
  // guardar" solo por tocarlos (copiar el enlace, volver, abrir/cerrar un
  // panel-herramienta, o el propio botón de guardar).
  const BOTONES_SIN_CAMBIOS = new Set(["btn-back", "btn-copiar-enlace", "btn-save-visible", "btn-save", "btn-save-and-back"]);
  $("view-editor").addEventListener("click", (e) => {
    const btn = e.target.closest("button");
    if (btn && (BOTONES_SIN_CAMBIOS.has(btn.id) || btn.hasAttribute("data-toggle-tool"))) return;
    if (btn || e.target.closest(".fuel-track")) { hasUnsavedChanges = true; contadorDeEdiciones++; updateUnsavedIndicator(); }
  });
  $("btn-save-visible").addEventListener("click", () => saveVehicle());
  $("btn-copiar-enlace").addEventListener("click", async () => {
    if (!currentVehicleId) return;
    const url = `${TRACK_BASE_URL}?v=${encodeURIComponent(currentVehicleId)}`;
    try {
      await navigator.clipboard.writeText(url);
      showToast(t("msg_enlace_copiado"), "success");
    } catch (err) {
      showToast(url, "", 8000); // si el navegador bloquea el portapapeles, al menos se muestra el enlace
    }
  });
  window.addEventListener("beforeunload", (e) => {
    if (!hasUnsavedChanges) return;
    e.preventDefault();
    e.returnValue = "";
  });
  $("btn-new-vehicle").addEventListener("click", () => openEditor(null));
  $("btn-view-board").addEventListener("click", () => { renderBoard(); showView("board"); });
  $("btn-board-back").addEventListener("click", () => { renderDashboard($("search-box").value); showView("dashboard"); });
  $("btn-save").addEventListener("click", saveVehicle);
  $("btn-delete").addEventListener("click", deleteVehicle);
  draftIntervalId = setInterval(() => { guardarBorradorLocal(); updateUnsavedIndicator(); }, 12000);

  $("search-box").addEventListener("input", (e) => renderDashboard(e.target.value));
  // Recuerda el filtro y el orden elegidos entre sesiones, para no tener
  // que volver a seleccionarlos cada vez que se recarga la página.
  try {
    const filtroGuardado = localStorage.getItem("dash_filtro");
    const ordenGuardado = localStorage.getItem("dash_orden");
    if (filtroGuardado) $("filter-select").value = filtroGuardado;
    if (ordenGuardado) $("sort-select").value = ordenGuardado;
  } catch (err) { /* localStorage puede no estar disponible — no es crítico */ }
  $("filter-select").addEventListener("change", (e) => {
    try { localStorage.setItem("dash_filtro", e.target.value); } catch (err) {}
    renderDashboard($("search-box").value);
  });
  $("sort-select").addEventListener("change", (e) => {
    try { localStorage.setItem("dash_orden", e.target.value); } catch (err) {}
    renderDashboard($("search-box").value);
  });

  /* ---------------- Botón "Volver arriba" ---------------- */

  const scrollTopBtn = document.getElementById("scroll-top-btn");
  if (scrollTopBtn) {
    window.addEventListener("scroll", () => {
      scrollTopBtn.classList.toggle("visible", window.scrollY > 420);
    });
    scrollTopBtn.addEventListener("click", () => {
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  }

  /* ---------------- Init ---------------- */

  (async function init() {
    initLightbox();
    wireClientAutocomplete();
    $("cfg-owner").value = DEFAULT_OWNER;
    $("cfg-repo").value = DEFAULT_REPO;
    $("cfg-branch").value = DEFAULT_BRANCH;

    if (restoreSession()) {
      try {
        await loadDatabase();
        renderDashboard();
        showView("dashboard");
        return;
      } catch (err) {
        localStorage.removeItem(SESSION_KEY);
      }
    }
    showView("login");
  })();
})();
